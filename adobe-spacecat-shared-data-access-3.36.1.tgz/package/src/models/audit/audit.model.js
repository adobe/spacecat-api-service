/*
 * Copyright 2024 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import {
  isArray,
  isObject,
  isBoolean,
  isNumber,
} from '@adobe/spacecat-shared-utils';

import { ValidationError } from '../../errors/index.js';
import BaseModel from '../base/base.model.js';

/**
 * Audit - A class representing an Audit entity.
 * Provides methods to access and manipulate Audit-specific data.
 *
 * @class Audit
 * @extends BaseModel
 */
class Audit extends BaseModel {
  static ENTITY_NAME = 'Audit';

  static AUDIT_TYPES = {
    APEX: 'apex',
    CWV: 'cwv',
    LHS_MOBILE: 'lhs-mobile',
    LHS_DESKTOP: 'lhs-desktop',
    404: '404',
    SITEMAP: 'sitemap',
    CANONICAL: 'canonical',
    REDIRECT_CHAINS: 'redirect-chains',
    BROKEN_BACKLINKS: 'broken-backlinks',
    BROKEN_INTERNAL_LINKS: 'broken-internal-links',
    CONTENT_FRAGMENT_UNUSED: 'content-fragment-unused',
    CONTENT_FRAGMENT_UNUSED_AUTO_FIX: 'content-fragment-unused-auto-fix',
    EXPERIMENTATION: 'experimentation',
    CONVERSION: 'conversion',
    ORGANIC_KEYWORDS: 'organic-keywords',
    ORGANIC_TRAFFIC: 'organic-traffic',
    EXPERIMENTATION_ESS_DAILY: 'experimentation-ess-daily',
    EXPERIMENTATION_ESS_MONTHLY: 'experimentation-ess-monthly',
    EXPERIMENTATION_OPPORTUNITIES: 'experimentation-opportunities',
    META_TAGS: 'meta-tags',
    LLM_ERROR_PAGES: 'llm-error-pages',
    COSTS: 'costs',
    STRUCTURED_DATA: 'structured-data',
    RELATED_URLS: 'related-urls',
    STRUCTURED_DATA_AUTO_SUGGEST: 'structured-data-auto-suggest',
    FORMS_OPPORTUNITIES: 'forms-opportunities',
    SITE_DETECTION: 'site-detection',
    ALT_TEXT: 'alt-text',
    ACCESSIBILITY: 'accessibility',
    SECURITY_CSP: 'security-csp',
    SECURITY_VULNERABILITIES: 'security-vulnerabilities',
    SECURITY_PERMISSIONS: 'security-permissions',
    SECURITY_REDUNDANT: 'security-permissions-redundant',
    PAID: 'paid',
    HREFLANG: 'hreflang',
    HEADINGS: 'headings',
    PAID_TRAFFIC_ANALYSIS_WEEKLY: 'paid-traffic-analysis-weekly',
    PAID_TRAFFIC_ANALYSIS_MONTHLY: 'paid-traffic-analysis-monthly',
    READABILITY: 'readability',
    PRERENDER: 'prerender',
    PRODUCT_METATAGS: 'product-metatags',
    PRODUCT_METATAGS_AUTO_SUGGEST: 'product-metatags-auto-suggest',
    PRODUCT_METATAGS_AUTO_FIX: 'product-metatags-auto-fix',
    SUMMARIZATION: 'summarization',
    PAGE_TYPE_DETECTION: 'page-type-detection',
    FAQS: 'faqs',
    CDN_LOGS_ANALYSIS: 'cdn-logs-analysis',
    CDN_LOGS_REPORT: 'cdn-logs-report',
    LLMO_REFERRAL_TRAFFIC: 'llmo-referral-traffic',
    PAGE_INTENT: 'page-intent',
    NO_CTA_ABOVE_THE_FOLD: 'no-cta-above-the-fold',
    TOC: 'toc',
    WIKIPEDIA_ANALYSIS: 'wikipedia-analysis',
    REDDIT_ANALYSIS: 'reddit-analysis',
    YOUTUBE_ANALYSIS: 'youtube-analysis',
    CITED_ANALYSIS: 'cited-analysis',
    COMMERCE_PRODUCT_ENRICHMENTS: 'commerce-product-enrichments',
    COMMERCE_PRODUCT_ENRICHMENTS_YEARLY: 'commerce-product-enrichments-yearly',
    COMMERCE_PRODUCT_PAGE_ENRICHMENT: 'commerce-product-page-enrichment',
    COMMERCE_PRODUCT_CATALOG_ENRICHMENT: 'commerce-product-catalog-enrichment',
    CWV_TRENDS_AUDIT: 'cwv-trends-audit',
    OFFSITE_BRAND_PRESENCE: 'offsite-brand-presence',
  };

  static AUDIT_TYPE_PROPERTIES = {
    [Audit.AUDIT_TYPES.LHS_DESKTOP]: ['performance', 'seo', 'accessibility', 'best-practices'],
    [Audit.AUDIT_TYPES.LHS_MOBILE]: ['performance', 'seo', 'accessibility', 'best-practices'],
  };

  static AUDIT_CONFIG = {
    TYPES: Audit.AUDIT_TYPES,
    PROPERTIES: Audit.AUDIT_TYPE_PROPERTIES,
  };

  /**
   * The destinations for the audit steps. Used with AuditBuilder to determine the destination
   * an audit step should trigger.
   * @type {{CONTENT_SCRAPER: string, IMPORT_WORKER: string}}
   */
  static AUDIT_STEP_DESTINATIONS = {
    CONTENT_SCRAPER: 'content-scraper',
    IMPORT_WORKER: 'import-worker',
    SCRAPE_CLIENT: 'scrape-client',
  };

  /**
   * The configurations for the audit step destinations. Used with AuditBuilder to configure
   * the destination queue URL and payload formatting.
   * @type {{
   *   [Audit.AUDIT_STEP_DESTINATIONS.CONTENT_SCRAPER]: {
   *     getQueueUrl: function,
   *     formatPayload: function
   *   },
   *   [Audit.AUDIT_STEP_DESTINATIONS.IMPORT_WORKER]: {
   *     getQueueUrl: function,
   *     formatPayload: function
   *   },
   *   [Audit.AUDIT_STEP_DESTINATIONS.SCRAPE_CLIENT]: {
   *   formatPayload: function
   * }}}
   */
  static AUDIT_STEP_DESTINATION_CONFIGS = {
    [Audit.AUDIT_STEP_DESTINATIONS.IMPORT_WORKER]: {
      getQueueUrl: (context) => context.env?.IMPORT_WORKER_QUEUE_URL,
      /**
       * Formats the payload for the import worker queue.
       * @param {object} stepResult - The result of the audit step.
       * @param {string} stepResult.type - The import type to trigger.
       * @param {string} stepResult.siteId - The site ID for which the import is triggered.
       * @param {string} [stepResult.pageUrl] - The page URL for which the import is triggered.
       * @param {string} [stepResult.startDate] - The start date for the import (optional).
       * @param {string} [stepResult.endDate] - The end date for the import (optional).
       * @param {object[]}[ stepResult.urlConfigs] - The list of URL configs for which the import is
       * triggered.
       * @param {object} auditContext - The audit context.
       * @param {object} auditContext.next - The next audit step to run.
       * @param {string} auditContext.auditId - The audit ID.
       * @param {string} auditContext.auditType - The audit type.
       * @param {string} auditContext.fullAuditRef - The full audit reference.
       * @param {string} auditContext.<string> - Optional. Any additional context properties
       * as needed by the audit type.
       *
       * @returns {object} - The formatted payload.
       */
      formatPayload: (stepResult, auditContext) => ({
        type: stepResult.type,
        siteId: stepResult.siteId,
        pageUrl: stepResult.pageUrl,
        startDate: stepResult.startDate,
        endDate: stepResult.endDate,
        urlConfigs: stepResult.urlConfigs,
        allowCache: isBoolean(stepResult.allowCache) ? stepResult.allowCache : true,
        auditContext,
      }),
    },
    [Audit.AUDIT_STEP_DESTINATIONS.CONTENT_SCRAPER]: {
      getQueueUrl: (context) => context.env?.CONTENT_SCRAPER_QUEUE_URL,
      /**
       * Formats the payload for the content scraper queue.
       * @param {object} stepResult - The result of the audit step.
       * @param {object[]} stepResult.urls - The list of URLs to scrape.
       * @param {string} stepResult.urls[].url - The URL to scrape.
       * @param {string} stepResult.siteId - The site ID. Will be used as the job ID.
       * @param {string} stepResult.options - The options for the scraper.
       * @param {string} stepResult.processingType - The scraping processing type to trigger.
       * @param {object} auditContext - The audit context.
       * @param {object} context - The context object.
       * @param {object} auditContext.next - The next audit step to run.
       * @param {string} auditContext.auditId - The audit ID.
       * @param {string} auditContext.auditType - The audit type.
       * @param {string} auditContext.fullAuditRef - The full audit reference.
       *
       * @returns {object} - The formatted payload.
       */
      formatPayload: (stepResult, auditContext, context) => ({
        urls: stepResult.urls,
        jobId: stepResult.siteId,
        processingType: stepResult.processingType || 'default',
        skipMessage: false,
        allowCache: isBoolean(stepResult.allowCache) ? stepResult.allowCache : true,
        options: stepResult.options || {},
        completionQueueUrl: stepResult.completionQueueUrl || context.env?.AUDIT_JOBS_QUEUE_URL,
        auditContext,
      }),
    },
    [Audit.AUDIT_STEP_DESTINATIONS.SCRAPE_CLIENT]: {
      /**
       *
       * @param stepResult - The result of the audit step.
       * @param auditContext - The audit context.
       * @param context - The context object.
       * @returns {object} - The formatted payload for the scrape client.
       */
      formatPayload: (stepResult, auditContext, context) => {
        const payload = {
          urls: stepResult.urls.map((urlObj) => urlObj.url),
          processingType: stepResult.processingType || 'default',
          options: stepResult.options || {},
          maxScrapeAge: isNumber(stepResult.maxScrapeAge) ? stepResult.maxScrapeAge : 24,
          metaData: {
            auditData: {
              siteId: stepResult.siteId,
              completionQueueUrl:
                stepResult.completionQueueUrl || context.env?.AUDIT_JOBS_QUEUE_URL || '',
              auditContext,
            },
          },
        };

        // Propagate traceId for cross-worker tracing continuity
        // This allows the scrape client to maintain the same trace across multiple workers
        if (context.traceId) {
          payload.traceId = context.traceId;
        }

        return payload;
      },
    },
  };

  /**
   * Validates if the auditResult contains the required properties for the given audit type.
   * @param {object} auditResult - The audit result to validate.
   * @param {string} auditType - The type of the audit.
   * @returns {boolean} - True if valid, false otherwise.
   */
  static validateAuditResult = (auditResult, auditType) => {
    if (!isObject(auditResult) && !isArray(auditResult)) {
      throw new ValidationError('Audit result must be an object or array');
    }

    if (isObject(auditResult.runtimeError)) {
      return true;
    }

    if ((
      auditType === Audit.AUDIT_CONFIG.TYPES.LHS_MOBILE
        || auditType === Audit.AUDIT_CONFIG.TYPES.LHS_DESKTOP
    )
      && !isObject(auditResult.scores)) {
      throw new ValidationError(`Missing scores property for audit type '${auditType}'`);
    }

    const expectedProperties = Audit.AUDIT_CONFIG.PROPERTIES[auditType];

    if (expectedProperties) {
      for (const prop of expectedProperties) {
        if (!(prop in auditResult.scores)) {
          throw new ValidationError(`Missing expected property '${prop}' for audit type '${auditType}'`);
        }
      }
    }

    return true;
  };

  getScores() {
    return this.getAuditResult()?.scores;
  }
}

export default Audit;
