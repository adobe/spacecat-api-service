/*
 * Copyright 2026 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import BaseCollection from '../base/base.collection.js';

/**
 * PlgOnboardingCollection - A collection class responsible for managing
 * PlgOnboarding entities.
 *
 * Note: allByStatus and allByBaseURL return cross-tenant results
 * intended for internal/admin use only.
 *
 * @class PlgOnboardingCollection
 * @extends BaseCollection
 */
class PlgOnboardingCollection extends BaseCollection {
  static COLLECTION_NAME = 'PlgOnboardingCollection';
}

export default PlgOnboardingCollection;
