/*
 * Copyright 2024 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import type {
  BaseCollection, BaseModel, Site, Project, Entitlement, OrganizationIdentityProvider, TrialUser,
} from '../index';

export interface Organization extends BaseModel {
  getConfig(): object;
  getFulfillableItems(): object;
  getImsOrgId(): string;
  getName(): string;
  getSites(): Promise<Site[]>;
  getProjects(): Promise<Project[]>;
  getEntitlements(): Promise<Entitlement[]>;
  getOrganizationIdentityProviders(): Promise<OrganizationIdentityProvider[]>;
  getTrialUsers(): Promise<TrialUser[]>;
  setConfig(config: object): Organization;
  setFulfillableItems(fulfillableItems: object): Organization;
  setImsOrgId(imsOrgId: string): Organization;
  setName(name: string): Organization;
}

export interface OrganizationCollection extends BaseCollection<Organization> {
  allByImsOrgId(imsOrgId: string): Promise<Organization[]>;
  findByImsOrgId(imsOrgId: string): Promise<Organization | null>;
}
