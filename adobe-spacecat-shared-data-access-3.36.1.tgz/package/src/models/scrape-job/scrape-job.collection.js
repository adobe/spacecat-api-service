/*
 * Copyright 2025 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import { isIsoDate } from '@adobe/spacecat-shared-utils';

import { ValidationError } from '../../errors/index.js';
import BaseCollection from '../base/base.collection.js';

/**
 * ScrapeJobCollection - A collection class responsible for managing ScrapeJob entities.
 * Extends the BaseCollection to provide specific methods for interacting with ScrapeJob records.
 *
 * @class ScrapeJobCollection
 * @extends BaseCollection
 */
class ScrapeJobCollection extends BaseCollection {
  static COLLECTION_NAME = 'ScrapeJobCollection';

  async allByDateRange(startDate, endDate) {
    if (!isIsoDate(startDate)) {
      throw new ValidationError(`Invalid start date: ${startDate}`);
    }

    if (!isIsoDate(endDate)) {
      throw new ValidationError(`Invalid end date: ${endDate}`);
    }

    return this.all({}, {
      between: {
        attribute: 'startedAt',
        start: startDate,
        end: endDate,
      },
    });
  }

  async allByBaseURLAndProcessingTypeAndOptEnableJavascriptAndOptHideConsentBanner(
    baseURL,
    processingType,
    optEnableJavascript,
    optHideConsentBanner,
    options = {},
  ) {
    const keys = {
      baseURL,
      processingType,
      optEnableJavascript,
      optHideConsentBanner,
    };

    return this.allByIndexKeys(keys, options);
  }

  async findByBaseURLAndProcessingTypeAndOptEnableJavascriptAndOptHideConsentBanner(
    baseURL,
    processingType,
    optEnableJavascript,
    optHideConsentBanner,
    options = {},
  ) {
    const jobs = await this
      .allByBaseURLAndProcessingTypeAndOptEnableJavascriptAndOptHideConsentBanner(
        baseURL,
        processingType,
        optEnableJavascript,
        optHideConsentBanner,
        { ...options, limit: options.limit || 1 },
      );
    if (Array.isArray(jobs)) {
      return jobs[0] || null;
    }
    return jobs || null;
  }
}

export default ScrapeJobCollection;
