## [@adobe/spacecat-shared-data-access-v3.36.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.36.0...@adobe/spacecat-shared-data-access-v3.36.1) (2026-04-01)

### Bug Fixes

* add isCodeChangeAvailable and patchContent to form accessibility schema ([#1373](https://github.com/adobe/spacecat-shared/issues/1373)) ([065bf56](https://github.com/adobe/spacecat-shared/commit/065bf561ba83f13d4c377f5ab4d7441ec0c15360))

## [@adobe/spacecat-shared-data-access-v3.36.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.35.0...@adobe/spacecat-shared-data-access-v3.36.0) (2026-04-01)

### Features

* add PLG tier to entitlement model and bump mysticat types  ([#1487](https://github.com/adobe/spacecat-shared/issues/1487)) ([7f9c6fc](https://github.com/adobe/spacecat-shared/commit/7f9c6fcb6d3672269081176ebf643151fb512e99))

## [@adobe/spacecat-shared-data-access-v3.35.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.34.0...@adobe/spacecat-shared-data-access-v3.35.0) (2026-03-31)

### Features

* redirectsQueued step renamed ([#1489](https://github.com/adobe/spacecat-shared/issues/1489)) ([d4eb54f](https://github.com/adobe/spacecat-shared/commit/d4eb54ff4c7636b904f41881cbb0c0ef6a2a3da4))

## [@adobe/spacecat-shared-data-access-v3.34.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.33.1...@adobe/spacecat-shared-data-access-v3.34.0) (2026-03-31)

### Features

* adds revoke suggestion grants ([#1465](https://github.com/adobe/spacecat-shared/issues/1465)) ([8081661](https://github.com/adobe/spacecat-shared/commit/80816616d26a9b49b764b15d934881456f7ff656))

## [@adobe/spacecat-shared-data-access-v3.33.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.33.0...@adobe/spacecat-shared-data-access-v3.33.1) (2026-03-31)

### Bug Fixes

* modifying the audit name max length ([#1485](https://github.com/adobe/spacecat-shared/issues/1485)) ([013528f](https://github.com/adobe/spacecat-shared/commit/013528fb486933a02395df0c461a3df1993c1ab1))

## [@adobe/spacecat-shared-data-access-v3.33.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.32.1...@adobe/spacecat-shared-data-access-v3.33.0) (2026-03-30)

### Features

* add onboard config and opportunity maps ([#1464](https://github.com/adobe/spacecat-shared/issues/1464)) ([9bd59f5](https://github.com/adobe/spacecat-shared/commit/9bd59f5e2b05f3fd29ea7568daf0e369bd4d2535))

## [@adobe/spacecat-shared-data-access-v3.32.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.32.0...@adobe/spacecat-shared-data-access-v3.32.1) (2026-03-28)

### Bug Fixes

* **deps:** update external fixes ([#1477](https://github.com/adobe/spacecat-shared/issues/1477)) ([67bdd1a](https://github.com/adobe/spacecat-shared/commit/67bdd1a2c497bed088bc1e54ae22e60c171308d1))

## [@adobe/spacecat-shared-data-access-v3.32.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.31.1...@adobe/spacecat-shared-data-access-v3.32.0) (2026-03-27)

### Features

* Added redirectsQueued to plg onboarding schema ([#1473](https://github.com/adobe/spacecat-shared/issues/1473)) ([a7c5258](https://github.com/adobe/spacecat-shared/commit/a7c5258afd97df232b874f5e0763ad4236419e39))

## [@adobe/spacecat-shared-data-access-v3.31.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.31.0...@adobe/spacecat-shared-data-access-v3.31.1) (2026-03-26)

### Bug Fixes

* **AGENTCOM-441:** update required fields from commerce config ([#1470](https://github.com/adobe/spacecat-shared/issues/1470)) ([5e89146](https://github.com/adobe/spacecat-shared/commit/5e89146110896cfcbcce9e80e743564ff8bb989b))

## [@adobe/spacecat-shared-data-access-v3.31.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.30.0...@adobe/spacecat-shared-data-access-v3.31.0) (2026-03-25)

### Features

* Added cwv-trends-audit import type ([#1434](https://github.com/adobe/spacecat-shared/issues/1434)) ([eab9653](https://github.com/adobe/spacecat-shared/commit/eab9653a367208f0cf9691fbf186ffabb9307fea))

## [@adobe/spacecat-shared-data-access-v3.30.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.29.0...@adobe/spacecat-shared-data-access-v3.30.0) (2026-03-25)

### Features

* **data-access:** add allByEnrollmentProductCode to SiteCollection ([#1455](https://github.com/adobe/spacecat-shared/issues/1455)) ([0225791](https://github.com/adobe/spacecat-shared/commit/02257915bbf5aa2e15e1320bbcdfa27b236c44b8))

## [@adobe/spacecat-shared-data-access-v3.29.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.28.0...@adobe/spacecat-shared-data-access-v3.29.0) (2026-03-23)

### Features

* **page-citability:** add UPDATED_BY_PRERENDER and UPDATED_BY_PAGE_CITABILITY constants ([#1460](https://github.com/adobe/spacecat-shared/issues/1460)) ([dcdf2b0](https://github.com/adobe/spacecat-shared/commit/dcdf2b0af9b9426631e9363949027a267ce7d015))

## [@adobe/spacecat-shared-data-access-v3.28.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.27.1...@adobe/spacecat-shared-data-access-v3.28.0) (2026-03-23)

### Features

* add commerceLlmoConfig to site configuration schema ([#1459](https://github.com/adobe/spacecat-shared/issues/1459)) ([8dd4bbf](https://github.com/adobe/spacecat-shared/commit/8dd4bbfda08343b37852d627c8528016358115c9))

## [@adobe/spacecat-shared-data-access-v3.27.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.27.0...@adobe/spacecat-shared-data-access-v3.27.1) (2026-03-21)

### Bug Fixes

* **deps:** update external fixes ([#1456](https://github.com/adobe/spacecat-shared/issues/1456)) ([b4654ec](https://github.com/adobe/spacecat-shared/commit/b4654ec88780f540f608fd8588182da805f2e6e2))

## [@adobe/spacecat-shared-data-access-v3.27.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.26.0...@adobe/spacecat-shared-data-access-v3.27.0) (2026-03-20)

### Features

* add countryCodeIgnoreList to site llmo config ([#1447](https://github.com/adobe/spacecat-shared/issues/1447)) ([6d824f8](https://github.com/adobe/spacecat-shared/commit/6d824f855aeadf623776a31e305270ae15fa1be2))

## [@adobe/spacecat-shared-data-access-v3.26.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.25.0...@adobe/spacecat-shared-data-access-v3.26.0) (2026-03-19)

### Features

* add access control helpers for cross-org delegation (Option 2a) ([#1453](https://github.com/adobe/spacecat-shared/issues/1453)) ([960623e](https://github.com/adobe/spacecat-shared/commit/960623ea9e77e849be8b0a5bd7ee047309377cef)), closes [adobe/spacecat-auth-service#503](https://github.com/adobe/spacecat-auth-service/issues/503) [#1448](https://github.com/adobe/spacecat-shared/issues/1448)

## [@adobe/spacecat-shared-data-access-v3.25.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.24.0...@adobe/spacecat-shared-data-access-v3.25.0) (2026-03-19)

### Features

* cross-org delegation entity models and AuthInfo extensions ([#1448](https://github.com/adobe/spacecat-shared/issues/1448)) ([b0cb091](https://github.com/adobe/spacecat-shared/commit/b0cb091432f15eb304e20263c0a18ec794d93bb9))

## [@adobe/spacecat-shared-data-access-v3.24.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.23.0...@adobe/spacecat-shared-data-access-v3.24.0) (2026-03-19)

### Features

* SITES-40623 - token system in Spacecat ([#1414](https://github.com/adobe/spacecat-shared/issues/1414)) ([9c540ba](https://github.com/adobe/spacecat-shared/commit/9c540babf47984e15737bde509b54df9b5233c54))

## [@adobe/spacecat-shared-data-access-v3.23.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.22.0...@adobe/spacecat-shared-data-access-v3.23.0) (2026-03-18)

### Features

* add cited-analsys as audit types ([#1444](https://github.com/adobe/spacecat-shared/issues/1444)) ([c87bf2e](https://github.com/adobe/spacecat-shared/commit/c87bf2e0d3ad77589fa44a1f9b9638ce0deaab53))

## [@adobe/spacecat-shared-data-access-v3.22.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.21.0...@adobe/spacecat-shared-data-access-v3.22.0) (2026-03-17)

### Features

* support boolean and timestamp for edgeOptimizeConfig.enabled ([#1441](https://github.com/adobe/spacecat-shared/issues/1441)) ([2fb173d](https://github.com/adobe/spacecat-shared/commit/2fb173da507df98c0a64977f90181ec501492c88))

## [@adobe/spacecat-shared-data-access-v3.21.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.20.1...@adobe/spacecat-shared-data-access-v3.21.0) (2026-03-16)

### Features

* **CWV:** add jiraLink to CWV suggestion schema and fix metric validation ([#1425](https://github.com/adobe/spacecat-shared/issues/1425)) ([d0429e0](https://github.com/adobe/spacecat-shared/commit/d0429e0e1b09348f31d5bfd21675b560bfb004e8))

## [@adobe/spacecat-shared-data-access-v3.20.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.20.0...@adobe/spacecat-shared-data-access-v3.20.1) (2026-03-13)

### Bug Fixes

* **data-access:** supabase/postgrest-js major dependency bump to v2 ([#1439](https://github.com/adobe/spacecat-shared/issues/1439)) ([29ca15b](https://github.com/adobe/spacecat-shared/commit/29ca15b7e23c95af43a14536e6e4917d423ec71e))

## [@adobe/spacecat-shared-data-access-v3.20.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.19.0...@adobe/spacecat-shared-data-access-v3.20.0) (2026-03-13)

### Features

* add OFFSITE_BRAND_PRESENCE audit type ([#1437](https://github.com/adobe/spacecat-shared/issues/1437)) ([5ffe54e](https://github.com/adobe/spacecat-shared/commit/5ffe54e740a4645b881c905fb6f1c2d2c47e556e))

## [@adobe/spacecat-shared-data-access-v3.19.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.18.0...@adobe/spacecat-shared-data-access-v3.19.0) (2026-03-13)

### Features

* **data-access:** add PRE_ONBOARDING status to PlgOnboarding entity ([#1433](https://github.com/adobe/spacecat-shared/issues/1433)) ([69b35d7](https://github.com/adobe/spacecat-shared/commit/69b35d77c5f0b2c67ed153227f60198527e530d4))

## [@adobe/spacecat-shared-data-access-v3.18.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.17.0...@adobe/spacecat-shared-data-access-v3.18.0) (2026-03-12)

### Features

* **data-access:** add saveMany() to BaseCollection for chunked bulk upsert ([#1428](https://github.com/adobe/spacecat-shared/issues/1428)) ([802bfec](https://github.com/adobe/spacecat-shared/commit/802bfecb21981e577fc1e72b38c24002edcd8bb1))

## [@adobe/spacecat-shared-data-access-v3.17.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.16.0...@adobe/spacecat-shared-data-access-v3.17.0) (2026-03-12)

### Features

* **data-access:** add cross-tenant query documentation for PlgOnboarding ([#1432](https://github.com/adobe/spacecat-shared/issues/1432)) ([d16c1ea](https://github.com/adobe/spacecat-shared/commit/d16c1ea95dff54ce801cd80e4177c3de853886c5))

## [@adobe/spacecat-shared-data-access-v3.16.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.15.1...@adobe/spacecat-shared-data-access-v3.16.0) (2026-03-12)

### Features

* Added cwv-trends-daily import type ([#1375](https://github.com/adobe/spacecat-shared/issues/1375)) ([14148bb](https://github.com/adobe/spacecat-shared/commit/14148bbcdebc330ad0e4fea2534779c14f3ab30d))

## [@adobe/spacecat-shared-data-access-v3.15.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.15.0...@adobe/spacecat-shared-data-access-v3.15.1) (2026-03-11)

### Bug Fixes

* update SentimentTopic types and add urls integration test assertion ([#1427](https://github.com/adobe/spacecat-shared/issues/1427)) ([486305f](https://github.com/adobe/spacecat-shared/commit/486305fb92577ab3e63f2e5f32fa0e828709eb82))

## [@adobe/spacecat-shared-data-access-v3.15.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.14.0...@adobe/spacecat-shared-data-access-v3.15.0) (2026-03-11)

### Features

* enable urls persistence in PostgreSQL for SentimentTopic ([#1426](https://github.com/adobe/spacecat-shared/issues/1426)) ([6f439b5](https://github.com/adobe/spacecat-shared/commit/6f439b56e5f5ae3989c3fd0f142537c09f1fa4c1))

## [@adobe/spacecat-shared-data-access-v3.14.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.13.0...@adobe/spacecat-shared-data-access-v3.14.0) (2026-03-10)

### Features

* enable HTTP connection reuse for PostgrestClient and VaultClient ([#1423](https://github.com/adobe/spacecat-shared/issues/1423)) ([ff92207](https://github.com/adobe/spacecat-shared/commit/ff922075a7e4d035c663d33b8b16ebe1c4dce2c6))

## [@adobe/spacecat-shared-data-access-v3.13.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.12.1...@adobe/spacecat-shared-data-access-v3.13.0) (2026-03-10)

### Features

* add related-urls audit type ([#1422](https://github.com/adobe/spacecat-shared/issues/1422)) ([3826f3f](https://github.com/adobe/spacecat-shared/commit/3826f3f6fbb030314f825d8523352c329f3c0fcf))

## [@adobe/spacecat-shared-data-access-v3.12.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.12.0...@adobe/spacecat-shared-data-access-v3.12.1) (2026-03-10)

### Bug Fixes

* add orderby to entitlement org query  ([#1415](https://github.com/adobe/spacecat-shared/issues/1415)) ([6a38d39](https://github.com/adobe/spacecat-shared/commit/6a38d39dbbe55c078a65fb8de213bac28156beda))

## [@adobe/spacecat-shared-data-access-v3.12.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.11.0...@adobe/spacecat-shared-data-access-v3.12.0) (2026-03-10)

### Features

* **data-access:** restructure SentimentTopic - move subPrompts into … ([#1419](https://github.com/adobe/spacecat-shared/issues/1419)) ([1b8a73e](https://github.com/adobe/spacecat-shared/commit/1b8a73edfa1f897a7490319c187b10ccd157800a))

## [@adobe/spacecat-shared-data-access-v3.11.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.10.1...@adobe/spacecat-shared-data-access-v3.11.0) (2026-03-09)

### Features

* add offsite-handler types ([#1408](https://github.com/adobe/spacecat-shared/issues/1408)) ([e8fb96a](https://github.com/adobe/spacecat-shared/commit/e8fb96a0fbf714f1e6bba4910724c085f4adc847))

## [@adobe/spacecat-shared-data-access-v3.10.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.10.0...@adobe/spacecat-shared-data-access-v3.10.1) (2026-03-07)

### Bug Fixes

* **deps:** update external fixes ([#1410](https://github.com/adobe/spacecat-shared/issues/1410)) ([e5b5634](https://github.com/adobe/spacecat-shared/commit/e5b5634f788a8f440ef49218c0b2fa1ccb42fb8a))

## [@adobe/spacecat-shared-data-access-v3.10.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.9.0...@adobe/spacecat-shared-data-access-v3.10.0) (2026-03-06)

### Features

* add skipReason and skipDetail attributes to Suggestion ([#1372](https://github.com/adobe/spacecat-shared/issues/1372)) ([1069556](https://github.com/adobe/spacecat-shared/commit/1069556b6b01bebdf215395fec34c317c290b7c0))

## [@adobe/spacecat-shared-data-access-v3.9.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.8.0...@adobe/spacecat-shared-data-access-v3.9.0) (2026-03-05)

### Features

* add optional aws region to cdn bucket config ([#1404](https://github.com/adobe/spacecat-shared/issues/1404)) ([76a7051](https://github.com/adobe/spacecat-shared/commit/76a7051f465d0d43cb03875fcc77b3ff174c4317))

## [@adobe/spacecat-shared-data-access-v3.8.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.7.0...@adobe/spacecat-shared-data-access-v3.8.0) (2026-03-05)

### Features

* **data-access:** add bulk entitlement query with organization embedding ([#1402](https://github.com/adobe/spacecat-shared/issues/1402)) ([588cfce](https://github.com/adobe/spacecat-shared/commit/588cfce8e1b4e81a55c3fbca4c7491368196b558))

## [@adobe/spacecat-shared-data-access-v3.7.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.6.2...@adobe/spacecat-shared-data-access-v3.7.0) (2026-03-04)

### Features

* **data-access:** add timesCited attribute to SentimentTopic schema ([#1399](https://github.com/adobe/spacecat-shared/issues/1399)) ([03cae03](https://github.com/adobe/spacecat-shared/commit/03cae0375a1c44e23d33b65f28002b5b22b975c1))

## [@adobe/spacecat-shared-data-access-v3.6.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.6.1...@adobe/spacecat-shared-data-access-v3.6.2) (2026-03-04)

### Bug Fixes

* **data-access:** surface PG error details in logs ([#1401](https://github.com/adobe/spacecat-shared/issues/1401)) ([ddd3041](https://github.com/adobe/spacecat-shared/commit/ddd3041322a1468ee911f49f06c240a6697b8e66))

## [@adobe/spacecat-shared-data-access-v3.6.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.6.0...@adobe/spacecat-shared-data-access-v3.6.1) (2026-03-03)

### Bug Fixes

* stage changes wrt to spacecat-shared ([#1394](https://github.com/adobe/spacecat-shared/issues/1394)) ([7145fb0](https://github.com/adobe/spacecat-shared/commit/7145fb037e5b809d4552889c291b6f8688655b88))

## [@adobe/spacecat-shared-data-access-v3.6.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.5.0...@adobe/spacecat-shared-data-access-v3.6.0) (2026-03-02)

### Features

* **data-access:** expose postgrestClient for direct PostgREST queries ([#1396](https://github.com/adobe/spacecat-shared/issues/1396)) ([307711c](https://github.com/adobe/spacecat-shared/commit/307711cfed7a3f2fc15f17afe31a48b21213a8e4))

## [@adobe/spacecat-shared-data-access-v3.5.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.4.2...@adobe/spacecat-shared-data-access-v3.5.0) (2026-03-02)

### Features

* **data-access:** auto-normalize enum values in PostgREST query filters ([#1392](https://github.com/adobe/spacecat-shared/issues/1392)) ([f44d0d2](https://github.com/adobe/spacecat-shared/commit/f44d0d257b0d47a719f592da13e91b2b01d89454))

## [@adobe/spacecat-shared-data-access-v3.4.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.4.1...@adobe/spacecat-shared-data-access-v3.4.2) (2026-03-02)

### Bug Fixes

* **deps:** update external fixes ([#1223](https://github.com/adobe/spacecat-shared/issues/1223)) ([7ee8461](https://github.com/adobe/spacecat-shared/commit/7ee8461c99223d07a2f47bd6838b6942fcb30f28))

## [@adobe/spacecat-shared-data-access-v3.4.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.4.0...@adobe/spacecat-shared-data-access-v3.4.1) (2026-03-01)

### Bug Fixes

* **data-access:** chunk batchGetByKeys to avoid 414 URI Too Large ([#1391](https://github.com/adobe/spacecat-shared/issues/1391)) ([25b0c0d](https://github.com/adobe/spacecat-shared/commit/25b0c0dab34b4e8e8b5fef9f4033cbcc698652f5)), closes [#1390](https://github.com/adobe/spacecat-shared/issues/1390)

## [@adobe/spacecat-shared-data-access-v3.4.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.3.0...@adobe/spacecat-shared-data-access-v3.4.0) (2026-02-26)

### Features

* register commerce-product-enrichments-yearly audit type ([#1381](https://github.com/adobe/spacecat-shared/issues/1381)) ([6d2990f](https://github.com/adobe/spacecat-shared/commit/6d2990f691d3c9837772d092efb72cd7069a8024))

## [@adobe/spacecat-shared-data-access-v3.3.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.2.0...@adobe/spacecat-shared-data-access-v3.3.0) (2026-02-26)

### Features

* **data-access:** add yearly job interval ([#1380](https://github.com/adobe/spacecat-shared/issues/1380)) ([422f301](https://github.com/adobe/spacecat-shared/commit/422f301bd6d8e3f4565b0790c39adf511855da69))

## [@adobe/spacecat-shared-data-access-v3.2.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.1.0...@adobe/spacecat-shared-data-access-v3.2.0) (2026-02-21)

### Features

* cloud manager client ([#1335](https://github.com/adobe/spacecat-shared/issues/1335)) ([2e4b013](https://github.com/adobe/spacecat-shared/commit/2e4b01359641706d633c16907b8292334581ce39))

## [@adobe/spacecat-shared-data-access-v3.1.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.0.1...@adobe/spacecat-shared-data-access-v3.1.0) (2026-02-18)

### Features

* add methods to manage LLMO tags | LLMO-3058 ([#1362](https://github.com/adobe/spacecat-shared/issues/1362)) ([c678d1a](https://github.com/adobe/spacecat-shared/commit/c678d1ad6e12febeeae6cc60211bb0cbf9f922a4))

## [@adobe/spacecat-shared-data-access-v3.0.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v3.0.0...@adobe/spacecat-shared-data-access-v3.0.1) (2026-02-17)

### Bug Fixes

* add consent-banner to DATA_SCHEMAS for minimal view projection ([#1361](https://github.com/adobe/spacecat-shared/issues/1361)) ([bc1379c](https://github.com/adobe/spacecat-shared/commit/bc1379c6e7eba64c2d7f2b17e1462db0ca798711))

## [@adobe/spacecat-shared-data-access-v3.0.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.109.0...@adobe/spacecat-shared-data-access-v3.0.0) (2026-02-16)

### ⚠ BREAKING CHANGES

* **data-access:** data-access v3 migrates from DynamoDB/ElectroDB to Postgres/PostgREST

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
* data access v3 (#1349)

### Features

* data access v3 ([#1349](https://github.com/adobe/spacecat-shared/issues/1349)) ([6db6b79](https://github.com/adobe/spacecat-shared/commit/6db6b79ecb7813acad798a2435fe317cd9d1731c))
* **data-access:** v3 Postgres/PostgREST migration ([b79725f](https://github.com/adobe/spacecat-shared/commit/b79725f6a53bc0baac14a64acd8105a3eec56d99))

# [@adobe/spacecat-shared-data-access-v2.109.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.108.0...@adobe/spacecat-shared-data-access-v2.109.0) (2026-02-16)


### Features

* consumer entity to register technical accounts ([#1341](https://github.com/adobe/spacecat-shared/issues/1341)) ([a0572e8](https://github.com/adobe/spacecat-shared/commit/a0572e8f52c95d90b986495a110ec66f58caa77e))

# [@adobe/spacecat-shared-data-access-v2.108.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.107.0...@adobe/spacecat-shared-data-access-v2.108.0) (2026-02-13)


### Features

* extend weekly-slot intervals from 18 to 23 ([#1345](https://github.com/adobe/spacecat-shared/issues/1345)) ([6f46aef](https://github.com/adobe/spacecat-shared/commit/6f46aef3b9dfaac35c928648201135b1fbe8857b))

# [@adobe/spacecat-shared-data-access-v2.107.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.106.1...@adobe/spacecat-shared-data-access-v2.107.0) (2026-02-12)


### Features

* add weekly-slot job intervals for staggered audits ([#1344](https://github.com/adobe/spacecat-shared/issues/1344)) ([5b85f6c](https://github.com/adobe/spacecat-shared/commit/5b85f6c9a98e39756c241d2d96db865a111f151b))

# [@adobe/spacecat-shared-data-access-v2.106.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.106.0...@adobe/spacecat-shared-data-access-v2.106.1) (2026-02-12)


### Bug Fixes

* enabled removal ([#1343](https://github.com/adobe/spacecat-shared/issues/1343)) ([3508c38](https://github.com/adobe/spacecat-shared/commit/3508c380b20994567ac7a5efc598bdc9cd1559c7))

# [@adobe/spacecat-shared-data-access-v2.106.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.105.1...@adobe/spacecat-shared-data-access-v2.106.0) (2026-02-11)


### Features

* **data-access:** add suggestionValue to FALLBACK_PROJECTION for reports ([#1337](https://github.com/adobe/spacecat-shared/issues/1337)) ([d17da2b](https://github.com/adobe/spacecat-shared/commit/d17da2b69bbccbf69d2fabe7c3ffd37d8ffb5106))

# [@adobe/spacecat-shared-data-access-v2.105.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.105.0...@adobe/spacecat-shared-data-access-v2.105.1) (2026-02-11)


### Bug Fixes

* **data-access:** support both snake_case and camelCase in BROKEN_BAC… ([#1336](https://github.com/adobe/spacecat-shared/issues/1336)) ([327d934](https://github.com/adobe/spacecat-shared/commit/327d934b7b93506fe397ca92548c4ff111fb26df))

# [@adobe/spacecat-shared-data-access-v2.105.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.104.0...@adobe/spacecat-shared-data-access-v2.105.0) (2026-02-10)


### Features

* **data-access:** add weekly-digest-email job interval ([#1333](https://github.com/adobe/spacecat-shared/issues/1333)) ([e4dd4cb](https://github.com/adobe/spacecat-shared/commit/e4dd4cb97f4f757f14233dd6f3d682e4180bfce9))

# [@adobe/spacecat-shared-data-access-v2.104.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.103.0...@adobe/spacecat-shared-data-access-v2.104.0) (2026-02-08)


### Features

* Bot press hold detection addition + add abort info to scrapeJob schema ([#1308](https://github.com/adobe/spacecat-shared/issues/1308)) ([4f19f91](https://github.com/adobe/spacecat-shared/commit/4f19f9143435aa283d8b9e57c17dd79873168177))

# [@adobe/spacecat-shared-data-access-v2.103.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.102.0...@adobe/spacecat-shared-data-access-v2.103.0) (2026-02-04)


### Features

* add brand sentiment guidelines ([#1297](https://github.com/adobe/spacecat-shared/issues/1297)) ([93f0a1d](https://github.com/adobe/spacecat-shared/commit/93f0a1dada56c1a3b6c40cff32a4b7be186e82e6))

# [@adobe/spacecat-shared-data-access-v2.102.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.101.0...@adobe/spacecat-shared-data-access-v2.102.0) (2026-02-04)


### Features

* add new types for commerce product enrichments ([#1317](https://github.com/adobe/spacecat-shared/issues/1317)) ([14a4f10](https://github.com/adobe/spacecat-shared/commit/14a4f104c06ed800cbaa318e72d0106f5398ca85))

# [@adobe/spacecat-shared-data-access-v2.101.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.100.2...@adobe/spacecat-shared-data-access-v2.101.0) (2026-02-04)


### Features

* update audit destination scrapeClient ([#1313](https://github.com/adobe/spacecat-shared/issues/1313)) ([d050937](https://github.com/adobe/spacecat-shared/commit/d0509370042ec48e8493496ba4b7d52d249c3689))

# [@adobe/spacecat-shared-data-access-v2.100.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.100.1...@adobe/spacecat-shared-data-access-v2.100.2) (2026-02-03)


### Bug Fixes

* opted changed to timestamp ([#1306](https://github.com/adobe/spacecat-shared/issues/1306)) ([24d34dc](https://github.com/adobe/spacecat-shared/commit/24d34dc9353460043441335ddb4f2a4f8b41584f))

# [@adobe/spacecat-shared-data-access-v2.100.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.100.0...@adobe/spacecat-shared-data-access-v2.100.1) (2026-02-02)


### Bug Fixes

* improve suggestion schema documentation ([#1304](https://github.com/adobe/spacecat-shared/issues/1304)) ([8d87f3f](https://github.com/adobe/spacecat-shared/commit/8d87f3f474dae73a0207d51cdf1e1b040befcf89))

# [@adobe/spacecat-shared-data-access-v2.100.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.99.0...@adobe/spacecat-shared-data-access-v2.100.0) (2026-02-02)


### Features

* **data-access:** add type-specific data schemas for suggestions [SITES-39183] ([#1289](https://github.com/adobe/spacecat-shared/issues/1289)) ([9824b22](https://github.com/adobe/spacecat-shared/commit/9824b22bc494467849a2ae903ce902ed3f9fde80))

# [@adobe/spacecat-shared-data-access-v2.99.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.98.0...@adobe/spacecat-shared-data-access-v2.99.0) (2026-01-30)


### Features

* **configuration:** add QUARTERLY job interval ([#1302](https://github.com/adobe/spacecat-shared/issues/1302)) ([30d3c10](https://github.com/adobe/spacecat-shared/commit/30d3c1006c5f9f3043b103b3a23893664090619f))

# [@adobe/spacecat-shared-data-access-v2.98.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.97.2...@adobe/spacecat-shared-data-access-v2.98.0) (2026-01-29)


### Features

* new flag opted added in edgeoptimizeconfig ([#1294](https://github.com/adobe/spacecat-shared/issues/1294)) ([8386e38](https://github.com/adobe/spacecat-shared/commit/8386e3805e9e67c18e4569428bef7ac5723eb991))

# [@adobe/spacecat-shared-data-access-v2.97.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.97.1...@adobe/spacecat-shared-data-access-v2.97.2) (2026-01-28)


### Bug Fixes

* page-citability adding new field in schema ([#1293](https://github.com/adobe/spacecat-shared/issues/1293)) ([9b4728e](https://github.com/adobe/spacecat-shared/commit/9b4728e1e97c8c4f80c2c9ccd011cc14195f5214))

# [@adobe/spacecat-shared-data-access-v2.97.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.97.0...@adobe/spacecat-shared-data-access-v2.97.1) (2026-01-23)


### Bug Fixes

* Add a dummy code ([#1283](https://github.com/adobe/spacecat-shared/issues/1283)) ([94e4ee1](https://github.com/adobe/spacecat-shared/commit/94e4ee121f5d5cfad14b4a7f73c0069515aa34be))

# [@adobe/spacecat-shared-data-access-v2.97.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.96.0...@adobe/spacecat-shared-data-access-v2.97.0) (2026-01-22)


### Features

* **AGENTCOM-302:** add new audit type for commerce product enrichments ([#1282](https://github.com/adobe/spacecat-shared/issues/1282)) ([7f3bfcc](https://github.com/adobe/spacecat-shared/commit/7f3bfcc9625bdd024173cf3c1bbf9182a3075fc2))

# [@adobe/spacecat-shared-data-access-v2.96.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.95.0...@adobe/spacecat-shared-data-access-v2.96.0) (2026-01-16)


### Features

* add ACO product code to Entitlement model ([#1259](https://github.com/adobe/spacecat-shared/issues/1259)) ([256f66a](https://github.com/adobe/spacecat-shared/commit/256f66a3114a5d8a27379a92109fc15c969be8b1))

# [@adobe/spacecat-shared-data-access-v2.95.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.94.0...@adobe/spacecat-shared-data-access-v2.95.0) (2026-01-15)


### Features

* Add autofixExcludedURLs configuration support for meta-tags opportunity ([#1258](https://github.com/adobe/spacecat-shared/issues/1258)) ([b5c5025](https://github.com/adobe/spacecat-shared/commit/b5c50250bb067799b352d98ab3ee860f3db324b4))

# [@adobe/spacecat-shared-data-access-v2.94.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.93.0...@adobe/spacecat-shared-data-access-v2.94.0) (2026-01-15)


### Features

* add TokowakaKVClient for fetching stale suggestions from edge o… ([#1262](https://github.com/adobe/spacecat-shared/issues/1262)) ([e8d440b](https://github.com/adobe/spacecat-shared/commit/e8d440bcc462419b4c82d3415f3a83dfde5195f1))

# [@adobe/spacecat-shared-data-access-v2.93.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.92.1...@adobe/spacecat-shared-data-access-v2.93.0) (2026-01-08)


### Features

* propagate traceId across workers for cross-worker tracing ([#1247](https://github.com/adobe/spacecat-shared/issues/1247)) ([f7d194d](https://github.com/adobe/spacecat-shared/commit/f7d194d2a8d23426c9dd66aae33f1118d226e827))

# [@adobe/spacecat-shared-data-access-v2.92.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.92.0...@adobe/spacecat-shared-data-access-v2.92.1) (2026-01-07)


### Bug Fixes

* fetch api key from s3 and fix invalidation sequence ([#1251](https://github.com/adobe/spacecat-shared/issues/1251)) ([fe66bd6](https://github.com/adobe/spacecat-shared/commit/fe66bd6732dc200ab4df27babc1e0831f6187271))

# [@adobe/spacecat-shared-data-access-v2.92.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.91.0...@adobe/spacecat-shared-data-access-v2.92.0) (2025-12-11)


### Features

* add WIKIPEDIA_ANALYSIS audit type and opportunity type ([#1222](https://github.com/adobe/spacecat-shared/issues/1222)) ([5a1b113](https://github.com/adobe/spacecat-shared/commit/5a1b113ff343a930e80bb5aafedbe2b8c5423534))

# [@adobe/spacecat-shared-data-access-v2.91.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.90.0...@adobe/spacecat-shared-data-access-v2.91.0) (2025-12-10)


### Features

* add unused content fragment audit type ([#1135](https://github.com/adobe/spacecat-shared/issues/1135)) ([dfdd01e](https://github.com/adobe/spacecat-shared/commit/dfdd01e2603ab737da2f1935139b66693edb9d70))

# [@adobe/spacecat-shared-data-access-v2.90.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.89.0...@adobe/spacecat-shared-data-access-v2.90.0) (2025-12-08)


### Features

* **data-access:** handle configuration via s3 ([#1216](https://github.com/adobe/spacecat-shared/issues/1216)) ([ef03ab7](https://github.com/adobe/spacecat-shared/commit/ef03ab705bae8653162de12405bcbc65c32bb5a8))

# [@adobe/spacecat-shared-data-access-v2.89.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.88.9...@adobe/spacecat-shared-data-access-v2.89.0) (2025-12-08)


### Features

* **audit-url:** add URL store data model and data access ([#1211](https://github.com/adobe/spacecat-shared/issues/1211)) ([a7e458e](https://github.com/adobe/spacecat-shared/commit/a7e458e91d4f1aa93b7243cea5361f028ef2b7db))

# [@adobe/spacecat-shared-data-access-v2.88.9](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.88.8...@adobe/spacecat-shared-data-access-v2.88.9) (2025-12-04)


### Bug Fixes

* adding toc audit type ([#1214](https://github.com/adobe/spacecat-shared/issues/1214)) ([7dab7d7](https://github.com/adobe/spacecat-shared/commit/7dab7d7afdcd4b56a56c10b65a3dff0fefb52e4e))

# [@adobe/spacecat-shared-data-access-v2.88.8](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.88.7...@adobe/spacecat-shared-data-access-v2.88.8) (2025-12-01)


### Bug Fixes

* use correct model name ([#1199](https://github.com/adobe/spacecat-shared/issues/1199)) ([3f5fb03](https://github.com/adobe/spacecat-shared/commit/3f5fb036c961036367376617d04bc1a7181146b1)), closes [#pk](https://github.com/adobe/spacecat-shared/issues/pk) [#sk](https://github.com/adobe/spacecat-shared/issues/sk)

# [@adobe/spacecat-shared-data-access-v2.88.7](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.88.6...@adobe/spacecat-shared-data-access-v2.88.7) (2025-11-30)


### Bug Fixes

* avoid static for esbuild ([#1195](https://github.com/adobe/spacecat-shared/issues/1195)) ([9ed69e3](https://github.com/adobe/spacecat-shared/commit/9ed69e3bb57d2f5fa84cb0ce60f4ab1a52a7bb70)), closes [#instance](https://github.com/adobe/spacecat-shared/issues/instance)

# [@adobe/spacecat-shared-data-access-v2.88.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.88.5...@adobe/spacecat-shared-data-access-v2.88.6) (2025-11-28)


### Bug Fixes

* adds executedAt as default createdAt for indexing fixEntity suggestion relationship ([#1177](https://github.com/adobe/spacecat-shared/issues/1177)) ([1db57ad](https://github.com/adobe/spacecat-shared/commit/1db57ade028db638b2185860bebcd4c4187c261e))

# [@adobe/spacecat-shared-data-access-v2.88.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.88.4...@adobe/spacecat-shared-data-access-v2.88.5) (2025-11-28)


### Bug Fixes

* package lock ([#1185](https://github.com/adobe/spacecat-shared/issues/1185)) ([d0708cc](https://github.com/adobe/spacecat-shared/commit/d0708cc8b7cbbea35a4440d684db2b3613240469))
* revert release to node 24 ([#1183](https://github.com/adobe/spacecat-shared/issues/1183)) ([e662259](https://github.com/adobe/spacecat-shared/commit/e66225930c1f56fbc6e8898d37d06f777e6ee356)), closes [#1182](https://github.com/adobe/spacecat-shared/issues/1182)

# [@adobe/spacecat-shared-data-access-v2.88.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.88.3...@adobe/spacecat-shared-data-access-v2.88.4) (2025-11-28)


### Bug Fixes

* update to node 24 ([#1179](https://github.com/adobe/spacecat-shared/issues/1179)) ([0e60c0a](https://github.com/adobe/spacecat-shared/commit/0e60c0ab791b47662d07822f7c93009a8f7048fd))

# [@adobe/spacecat-shared-data-access-v2.88.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.88.2...@adobe/spacecat-shared-data-access-v2.88.3) (2025-11-26)


### Bug Fixes

* Bundler-Agnostic Explicit COLLECTION_NAME ([#1174](https://github.com/adobe/spacecat-shared/issues/1174)) ([d08b4b8](https://github.com/adobe/spacecat-shared/commit/d08b4b82521da524dd37e64fa85258451dc4a3fa)), closes [#1173](https://github.com/adobe/spacecat-shared/issues/1173) [#1173](https://github.com/adobe/spacecat-shared/issues/1173) [#1173](https://github.com/adobe/spacecat-shared/issues/1173) [#1173](https://github.com/adobe/spacecat-shared/issues/1173)

# [@adobe/spacecat-shared-data-access-v2.88.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.88.1...@adobe/spacecat-shared-data-access-v2.88.2) (2025-11-26)


### Bug Fixes

* Make Entity Naming Bundler-Agnostic with Explicit ENTITY_NAME ([#1173](https://github.com/adobe/spacecat-shared/issues/1173)) ([c6cb69c](https://github.com/adobe/spacecat-shared/commit/c6cb69c6114db686f911afafe8d477b4556d9d49))

# [@adobe/spacecat-shared-data-access-v2.88.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.88.0...@adobe/spacecat-shared-data-access-v2.88.1) (2025-11-24)


### Bug Fixes

* remove enrollments when entitlment are removed ([#1161](https://github.com/adobe/spacecat-shared/issues/1161)) ([b82e6c4](https://github.com/adobe/spacecat-shared/commit/b82e6c4c259543bd0d3e3a3ad2d3e2702956d85c))

# [@adobe/spacecat-shared-data-access-v2.88.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.87.1...@adobe/spacecat-shared-data-access-v2.88.0) (2025-11-22)


### Bug Fixes

* **deps:** update external fixes ([#1162](https://github.com/adobe/spacecat-shared/issues/1162)) ([f0152c5](https://github.com/adobe/spacecat-shared/commit/f0152c5ecddb75b6b3c6e2f0d756d5fb04171dd3))


### Features

* add no-cta-above-the-fold audit ([#1159](https://github.com/adobe/spacecat-shared/issues/1159)) ([83b9a7d](https://github.com/adobe/spacecat-shared/commit/83b9a7dd0cac0979518dbf935f582df92acc0a47))

# [@adobe/spacecat-shared-data-access-v2.87.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.87.0...@adobe/spacecat-shared-data-access-v2.87.1) (2025-11-21)


### Bug Fixes

* edge preview feature for Tokowaka ([#1124](https://github.com/adobe/spacecat-shared/issues/1124)) ([cd2a06f](https://github.com/adobe/spacecat-shared/commit/cd2a06f62e3ca9e8c2b87e1810d420a06a002526))

# [@adobe/spacecat-shared-data-access-v2.87.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.86.0...@adobe/spacecat-shared-data-access-v2.87.0) (2025-11-19)


### Features

* add page citability ([#1140](https://github.com/adobe/spacecat-shared/issues/1140)) ([e4dfcdc](https://github.com/adobe/spacecat-shared/commit/e4dfcdccf44ad4a303c3b68b0655e00b25f3da3c))

# [@adobe/spacecat-shared-data-access-v2.86.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.85.1...@adobe/spacecat-shared-data-access-v2.86.0) (2025-11-19)


### Features

* add configuration management APIs ([#1063](https://github.com/adobe/spacecat-shared/issues/1063)) ([d6988a9](https://github.com/adobe/spacecat-shared/commit/d6988a94ad79016c238f3f4d9426c328b52c3131))

# [@adobe/spacecat-shared-data-access-v2.85.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.85.0...@adobe/spacecat-shared-data-access-v2.85.1) (2025-11-18)


### Bug Fixes

* **deps:** update shared utils in data access ([#1145](https://github.com/adobe/spacecat-shared/issues/1145)) ([5e38e70](https://github.com/adobe/spacecat-shared/commit/5e38e7032cf1e95a363c6fab67d67065a50ea7a0))

# [@adobe/spacecat-shared-data-access-v2.85.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.84.0...@adobe/spacecat-shared-data-access-v2.85.0) (2025-11-18)


### Features

* **data-access:** add new handlers to audit model ([#1141](https://github.com/adobe/spacecat-shared/issues/1141)) ([73e531b](https://github.com/adobe/spacecat-shared/commit/73e531b28773378defbef0f905f3db8e846cacc1))

# [@adobe/spacecat-shared-data-access-v2.84.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.83.2...@adobe/spacecat-shared-data-access-v2.84.0) (2025-11-17)


### Features

* add daily 1am interval ([#1137](https://github.com/adobe/spacecat-shared/issues/1137)) ([ac313e0](https://github.com/adobe/spacecat-shared/commit/ac313e070180a2b1165fdc9759896b339e520895))

# [@adobe/spacecat-shared-data-access-v2.83.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.83.1...@adobe/spacecat-shared-data-access-v2.83.2) (2025-11-15)


### Bug Fixes

* **deps:** update external fixes ([#1131](https://github.com/adobe/spacecat-shared/issues/1131)) ([d4a3f4a](https://github.com/adobe/spacecat-shared/commit/d4a3f4a653e59e9bdde7926ea8f1a2f9b68739ff))

# [@adobe/spacecat-shared-data-access-v2.83.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.83.0...@adobe/spacecat-shared-data-access-v2.83.1) (2025-11-14)


### Bug Fixes

* Add a dummy code ([#1128](https://github.com/adobe/spacecat-shared/issues/1128)) ([7d8a6d8](https://github.com/adobe/spacecat-shared/commit/7d8a6d829303f2710dd7363d05a511a7ddfbb0d0))

# [@adobe/spacecat-shared-data-access-v2.83.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.82.0...@adobe/spacecat-shared-data-access-v2.83.0) (2025-11-14)


### Features

* Add top-level brandProfile to Site Config with versioning and hash; tests and fixtures ([#1125](https://github.com/adobe/spacecat-shared/issues/1125)) ([6dcd3f8](https://github.com/adobe/spacecat-shared/commit/6dcd3f848d0dcc7303a9778ee86fc334166e2b68))
* added a new type reporting for fix entity ([#1121](https://github.com/adobe/spacecat-shared/issues/1121)) ([47f44b8](https://github.com/adobe/spacecat-shared/commit/47f44b81f073bdf1801746fb9e348a661f3a3fc5))

# [@adobe/spacecat-shared-data-access-v2.82.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.81.0...@adobe/spacecat-shared-data-access-v2.82.0) (2025-11-13)


### Features

* add ahref-paid-import ([#1120](https://github.com/adobe/spacecat-shared/issues/1120)) ([3818671](https://github.com/adobe/spacecat-shared/commit/381867174c60d157c2b5cd9fe68dc6f6a30fb71b))

# [@adobe/spacecat-shared-data-access-v2.81.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.80.2...@adobe/spacecat-shared-data-access-v2.81.0) (2025-11-11)


### Features

* **COMOPT-880:** add PRODUCT_METATAGS_AUTO_FIX audit type ([#1112](https://github.com/adobe/spacecat-shared/issues/1112)) ([b4e61db](https://github.com/adobe/spacecat-shared/commit/b4e61dbfa9b0d7c18a30d9ac025cfaa05c7d5bc0))

# [@adobe/spacecat-shared-data-access-v2.80.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.80.1...@adobe/spacecat-shared-data-access-v2.80.2) (2025-11-10)


### Bug Fixes

* **dynamo-db:** prevent connection storms in Lambda by caching client instances ([#1110](https://github.com/adobe/spacecat-shared/issues/1110)) ([f854100](https://github.com/adobe/spacecat-shared/commit/f85410088a2290dbab8d8956c16137e99e47147b))

# [@adobe/spacecat-shared-data-access-v2.80.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.80.0...@adobe/spacecat-shared-data-access-v2.80.1) (2025-11-08)


### Bug Fixes

* **deps:** update external fixes ([#1107](https://github.com/adobe/spacecat-shared/issues/1107)) ([f4cdb50](https://github.com/adobe/spacecat-shared/commit/f4cdb50f96d18dd92de81055f2b58310a68c0cac))

# [@adobe/spacecat-shared-data-access-v2.80.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.79.0...@adobe/spacecat-shared-data-access-v2.80.0) (2025-11-07)


### Features

* **data-access:** add twenty-past interval ([#1104](https://github.com/adobe/spacecat-shared/issues/1104)) ([4f1e7d7](https://github.com/adobe/spacecat-shared/commit/4f1e7d70e7ac1df884c7648be4202057d3a27a5f))

# [@adobe/spacecat-shared-data-access-v2.79.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.78.0...@adobe/spacecat-shared-data-access-v2.79.0) (2025-11-07)


### Features

* PTA2 Summary query ([#1102](https://github.com/adobe/spacecat-shared/issues/1102)) ([06e902a](https://github.com/adobe/spacecat-shared/commit/06e902a5487c2fc2e79a3f15d7acf1072900fab4))

# [@adobe/spacecat-shared-data-access-v2.78.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.77.1...@adobe/spacecat-shared-data-access-v2.78.0) (2025-11-06)


### Features

* **data-access:** add early-monday interval ([#1099](https://github.com/adobe/spacecat-shared/issues/1099)) ([3c7cc87](https://github.com/adobe/spacecat-shared/commit/3c7cc87b89c2bf06c9b5322ca20c26863cac14ac))

# [@adobe/spacecat-shared-data-access-v2.77.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.77.0...@adobe/spacecat-shared-data-access-v2.77.1) (2025-11-01)


### Bug Fixes

* **deps:** update external fixes ([#1081](https://github.com/adobe/spacecat-shared/issues/1081)) ([4476494](https://github.com/adobe/spacecat-shared/commit/44764944350f9344d0ca5e2af5a2161cc7470899))

# [@adobe/spacecat-shared-data-access-v2.77.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.76.1...@adobe/spacecat-shared-data-access-v2.77.0) (2025-10-31)


### Features

* pagination base code ([#1077](https://github.com/adobe/spacecat-shared/issues/1077)) ([7cd3806](https://github.com/adobe/spacecat-shared/commit/7cd38061c74f5a6e73097e2ceabcd1e90bf8de3b))

# [@adobe/spacecat-shared-data-access-v2.76.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.76.0...@adobe/spacecat-shared-data-access-v2.76.1) (2025-10-30)


### Bug Fixes

* **data-access:** include invocationId in audit schema ([#1075](https://github.com/adobe/spacecat-shared/issues/1075)) ([a7aecb2](https://github.com/adobe/spacecat-shared/commit/a7aecb211482e379ec77c20efbe672988071c660))

# [@adobe/spacecat-shared-data-access-v2.76.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.75.0...@adobe/spacecat-shared-data-access-v2.76.0) (2025-10-29)


### Features

* add tokowaka client ([#1025](https://github.com/adobe/spacecat-shared/issues/1025)) ([7af58b0](https://github.com/adobe/spacecat-shared/commit/7af58b03ef341c32b35a6614365024af6a636a56))

# [@adobe/spacecat-shared-data-access-v2.75.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.74.2...@adobe/spacecat-shared-data-access-v2.75.0) (2025-10-29)


### Features

* scrape url access pattern ([#1059](https://github.com/adobe/spacecat-shared/issues/1059)) ([26facf6](https://github.com/adobe/spacecat-shared/commit/26facf63dfae4908ed88221f16266910205e2473))

# [@adobe/spacecat-shared-data-access-v2.74.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.74.1...@adobe/spacecat-shared-data-access-v2.74.2) (2025-10-28)


### Bug Fixes

* remove cyclic deps in shared ([#1053](https://github.com/adobe/spacecat-shared/issues/1053)) ([acbbc93](https://github.com/adobe/spacecat-shared/commit/acbbc93f8c961fdef55edb5e7947958456538586))

# [@adobe/spacecat-shared-data-access-v2.74.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.74.0...@adobe/spacecat-shared-data-access-v2.74.1) (2025-10-25)


### Bug Fixes

* **deps:** update external fixes ([#1046](https://github.com/adobe/spacecat-shared/issues/1046)) ([bb6e118](https://github.com/adobe/spacecat-shared/commit/bb6e11886b323f73624fcb9e3c2b14d318aa00c9))

# [@adobe/spacecat-shared-data-access-v2.74.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.73.1...@adobe/spacecat-shared-data-access-v2.74.0) (2025-10-22)


### Features

* add FAQs audit ([#1036](https://github.com/adobe/spacecat-shared/issues/1036)) ([4ddc4de](https://github.com/adobe/spacecat-shared/commit/4ddc4de24dbfcd2200ed1245df9d9e0c3f87c757))

# [@adobe/spacecat-shared-data-access-v2.73.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.73.0...@adobe/spacecat-shared-data-access-v2.73.1) (2025-10-17)


### Bug Fixes

* maxScrapeAge zero handling ([#1024](https://github.com/adobe/spacecat-shared/issues/1024)) ([4aa087b](https://github.com/adobe/spacecat-shared/commit/4aa087b9af57f70f60ca38dc4d843929b7f4cc8f))

# [@adobe/spacecat-shared-data-access-v2.73.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.72.1...@adobe/spacecat-shared-data-access-v2.73.0) (2025-10-17)


### Features

* added pageType audit_type ([#1031](https://github.com/adobe/spacecat-shared/issues/1031)) ([ee469fa](https://github.com/adobe/spacecat-shared/commit/ee469fa60cdcfb0f20f44e90625ed49b235bbeb7))

# [@adobe/spacecat-shared-data-access-v2.72.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.72.0...@adobe/spacecat-shared-data-access-v2.72.1) (2025-10-16)


### Bug Fixes

* SITES-35629 adds origin attribute in fix entities ([#991](https://github.com/adobe/spacecat-shared/issues/991)) ([2551444](https://github.com/adobe/spacecat-shared/commit/255144441b246e22f9e84c6b1197ac6da726a742))

# [@adobe/spacecat-shared-data-access-v2.72.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.71.1...@adobe/spacecat-shared-data-access-v2.72.0) (2025-10-16)


### Features

* Sites 34129 adds many to many relationship between Fix Entity and Suggestions ([#993](https://github.com/adobe/spacecat-shared/issues/993)) ([8739d2b](https://github.com/adobe/spacecat-shared/commit/8739d2b891d5df6ce883ba3b319047531419100e))

# [@adobe/spacecat-shared-data-access-v2.71.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.71.0...@adobe/spacecat-shared-data-access-v2.71.1) (2025-10-13)


### Bug Fixes

* add interface for code config ([#1023](https://github.com/adobe/spacecat-shared/issues/1023)) ([74138b9](https://github.com/adobe/spacecat-shared/commit/74138b9adf135b536059a860315d89af67128601))

# [@adobe/spacecat-shared-data-access-v2.71.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.70.0...@adobe/spacecat-shared-data-access-v2.71.0) (2025-10-10)


### Features

* adding a new code config in Site ([#980](https://github.com/adobe/spacecat-shared/issues/980)) ([67aed42](https://github.com/adobe/spacecat-shared/commit/67aed425c43f2fdb9c7c51053b7ee4a726f545d9))

# [@adobe/spacecat-shared-data-access-v2.70.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.69.2...@adobe/spacecat-shared-data-access-v2.70.0) (2025-10-10)


### Features

* Add productCodes to configuration model ([#1017](https://github.com/adobe/spacecat-shared/issues/1017)) ([c7614b5](https://github.com/adobe/spacecat-shared/commit/c7614b59de924504440e711eb7d1d88a1608002b))

# [@adobe/spacecat-shared-data-access-v2.69.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.69.1...@adobe/spacecat-shared-data-access-v2.69.2) (2025-10-09)


### Bug Fixes

* add new attribute for product mapping ([#1014](https://github.com/adobe/spacecat-shared/issues/1014)) ([426b649](https://github.com/adobe/spacecat-shared/commit/426b649cb0dcff92a3c67f8e76bbfafd4b377885))

# [@adobe/spacecat-shared-data-access-v2.69.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.69.0...@adobe/spacecat-shared-data-access-v2.69.1) (2025-10-09)


### Bug Fixes

* update expires in for scrapeJobs and scrapeUrls to match S3 ([#998](https://github.com/adobe/spacecat-shared/issues/998)) ([289312b](https://github.com/adobe/spacecat-shared/commit/289312bd4fbfe6c48a4c678d153472406f3a7d30))

# [@adobe/spacecat-shared-data-access-v2.69.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.68.1...@adobe/spacecat-shared-data-access-v2.69.0) (2025-10-08)


### Features

* add summarization audit type ([#987](https://github.com/adobe/spacecat-shared/issues/987)) ([a000227](https://github.com/adobe/spacecat-shared/commit/a000227898df9b08e74eb555fc5a32e6f11ce7fd))

# [@adobe/spacecat-shared-data-access-v2.68.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.68.0...@adobe/spacecat-shared-data-access-v2.68.1) (2025-10-07)


### Bug Fixes

* site indexes order ([#1008](https://github.com/adobe/spacecat-shared/issues/1008)) ([215a961](https://github.com/adobe/spacecat-shared/commit/215a961a681873f4cb1882e2c8a53f8db13e32ea))

# [@adobe/spacecat-shared-data-access-v2.68.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.67.0...@adobe/spacecat-shared-data-access-v2.68.0) (2025-10-07)


### Features

* add query for fetching RUM engagement metrics ([#985](https://github.com/adobe/spacecat-shared/issues/985)) ([0eb8881](https://github.com/adobe/spacecat-shared/commit/0eb88818af000076ea663b2e08ab1fb2b1957510))

# [@adobe/spacecat-shared-data-access-v2.67.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.66.0...@adobe/spacecat-shared-data-access-v2.67.0) (2025-10-07)


### Features

* add support for region/language configurations ([#995](https://github.com/adobe/spacecat-shared/issues/995)) ([c5219da](https://github.com/adobe/spacecat-shared/commit/c5219da283370e7de5411aa778773315efdeb869))

# [@adobe/spacecat-shared-data-access-v2.66.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.65.2...@adobe/spacecat-shared-data-access-v2.66.0) (2025-10-03)


### Features

* Add configuration methods to register audits ([#1000](https://github.com/adobe/spacecat-shared/issues/1000)) ([f58670e](https://github.com/adobe/spacecat-shared/commit/f58670e5b3561bef09911102cc947fa6ba2a4955))

# [@adobe/spacecat-shared-data-access-v2.65.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.65.1...@adobe/spacecat-shared-data-access-v2.65.2) (2025-10-01)


### Bug Fixes

* remove all debug logs from data access ([#994](https://github.com/adobe/spacecat-shared/issues/994)) ([453d55b](https://github.com/adobe/spacecat-shared/commit/453d55bde5373519b9102ffdc8ca1ea523338078))

# [@adobe/spacecat-shared-data-access-v2.65.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.65.0...@adobe/spacecat-shared-data-access-v2.65.1) (2025-10-01)


### Bug Fixes

* remove accessor logging ([#992](https://github.com/adobe/spacecat-shared/issues/992)) ([22a8be3](https://github.com/adobe/spacecat-shared/commit/22a8be32b910bb03521400bc572d1ba084ccc381))

# [@adobe/spacecat-shared-data-access-v2.65.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.64.6...@adobe/spacecat-shared-data-access-v2.65.0) (2025-09-29)


### Features

* **COMOPT-1168:** add PRODUCT_METATAGS to AUDIT_TYPES and update tests ([#972](https://github.com/adobe/spacecat-shared/issues/972)) ([236086f](https://github.com/adobe/spacecat-shared/commit/236086f459622e59b7ce7caf764323a9e9f1da3c))

# [@adobe/spacecat-shared-data-access-v2.64.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.64.5...@adobe/spacecat-shared-data-access-v2.64.6) (2025-09-25)


### Bug Fixes

* allow configurable cache flag on import step ([#988](https://github.com/adobe/spacecat-shared/issues/988)) ([219d9ab](https://github.com/adobe/spacecat-shared/commit/219d9ab098ce1bc91d90c9e5ac8624ffd576dc14))

# [@adobe/spacecat-shared-data-access-v2.64.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.64.4...@adobe/spacecat-shared-data-access-v2.64.5) (2025-09-25)


### Bug Fixes

* remove unnecessary logs to reduce Coralogix usage ([#947](https://github.com/adobe/spacecat-shared/issues/947)) ([c93fa4f](https://github.com/adobe/spacecat-shared/commit/c93fa4f69238106caa0f8150df029e4535c99e39))

# [@adobe/spacecat-shared-data-access-v2.64.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.64.3...@adobe/spacecat-shared-data-access-v2.64.4) (2025-09-24)


### Bug Fixes

* dummy update readme ([#983](https://github.com/adobe/spacecat-shared/issues/983)) ([a631f36](https://github.com/adobe/spacecat-shared/commit/a631f36443ae96098a36412c1aab7995416c57d1))

# [@adobe/spacecat-shared-data-access-v2.64.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.64.2...@adobe/spacecat-shared-data-access-v2.64.3) (2025-09-23)


### Bug Fixes

* remove IDP left over ([#978](https://github.com/adobe/spacecat-shared/issues/978)) ([a8129e4](https://github.com/adobe/spacecat-shared/commit/a8129e40cbf6da1c0463d68a993d7e520c7542e6))

# [@adobe/spacecat-shared-data-access-v2.64.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.64.1...@adobe/spacecat-shared-data-access-v2.64.2) (2025-09-23)


### Bug Fixes

* remove IDP support ([#977](https://github.com/adobe/spacecat-shared/issues/977)) ([f2b4ad9](https://github.com/adobe/spacecat-shared/commit/f2b4ad95feeb6755cb6203c343c0ae4552cf8a76))

# [@adobe/spacecat-shared-data-access-v2.64.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.64.0...@adobe/spacecat-shared-data-access-v2.64.1) (2025-09-20)


### Bug Fixes

* **deps:** update external fixes ([#969](https://github.com/adobe/spacecat-shared/issues/969)) ([d722c62](https://github.com/adobe/spacecat-shared/commit/d722c623193fdbf292d96d71236cb4396db7ce3b))

# [@adobe/spacecat-shared-data-access-v2.64.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.63.0...@adobe/spacecat-shared-data-access-v2.64.0) (2025-09-19)


### Features

* adding new prerender audit type ([#959](https://github.com/adobe/spacecat-shared/issues/959)) ([7bebd89](https://github.com/adobe/spacecat-shared/commit/7bebd8992fa997f8dcb8db4c736b49d705fef905))

# [@adobe/spacecat-shared-data-access-v2.63.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.62.2...@adobe/spacecat-shared-data-access-v2.63.0) (2025-09-19)


### Features

* System-Wide Pagination Fix for DynamoDB Data Truncation ([#964](https://github.com/adobe/spacecat-shared/issues/964)) ([8f82e5f](https://github.com/adobe/spacecat-shared/commit/8f82e5fe2d5ed9ecd8ad2ff4e139b0588b3d8c01))

# [@adobe/spacecat-shared-data-access-v2.62.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.62.1...@adobe/spacecat-shared-data-access-v2.62.2) (2025-09-16)


### Bug Fixes

* **deps:** update external fixes ([#949](https://github.com/adobe/spacecat-shared/issues/949)) ([c25e099](https://github.com/adobe/spacecat-shared/commit/c25e099d2097b134f606e9a369b831d81143966d))

# [@adobe/spacecat-shared-data-access-v2.62.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.62.0...@adobe/spacecat-shared-data-access-v2.62.1) (2025-09-12)


### Bug Fixes

* Update entitlement.schema.js for consume numbers ([#955](https://github.com/adobe/spacecat-shared/issues/955)) ([0a65569](https://github.com/adobe/spacecat-shared/commit/0a65569c25d9a7abd13b8bce1e28d021d9b29967))

# [@adobe/spacecat-shared-data-access-v2.62.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.61.4...@adobe/spacecat-shared-data-access-v2.62.0) (2025-09-10)


### Features

* add security audit types ([#953](https://github.com/adobe/spacecat-shared/issues/953)) ([8d4827b](https://github.com/adobe/spacecat-shared/commit/8d4827be6f90689d4a49d8113bfaccc52d85b3a2))

# [@adobe/spacecat-shared-data-access-v2.61.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.61.3...@adobe/spacecat-shared-data-access-v2.61.4) (2025-09-09)


### Bug Fixes

* **deps:** update external major (major) ([#795](https://github.com/adobe/spacecat-shared/issues/795)) ([b020e88](https://github.com/adobe/spacecat-shared/commit/b020e884bfcad48667da87ad9caee7a3669e43d0))

# [@adobe/spacecat-shared-data-access-v2.61.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.61.2...@adobe/spacecat-shared-data-access-v2.61.3) (2025-09-08)


### Bug Fixes

* getSiblings not a function ([#951](https://github.com/adobe/spacecat-shared/issues/951)) ([f3af04a](https://github.com/adobe/spacecat-shared/commit/f3af04a9f64bd5e78c113f0672572ab374e7fda8))

# [@adobe/spacecat-shared-data-access-v2.61.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.61.1...@adobe/spacecat-shared-data-access-v2.61.2) (2025-09-06)


### Bug Fixes

* **deps:** update dependency electrodb to v3.4.5 ([#948](https://github.com/adobe/spacecat-shared/issues/948)) ([d02e298](https://github.com/adobe/spacecat-shared/commit/d02e298ccf4b3243cc8f07271c37bb587b3e23e7))

# [@adobe/spacecat-shared-data-access-v2.61.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.61.0...@adobe/spacecat-shared-data-access-v2.61.1) (2025-09-06)


### Bug Fixes

* **deps:** update external fixes ([#920](https://github.com/adobe/spacecat-shared/issues/920)) ([1a6b1e1](https://github.com/adobe/spacecat-shared/commit/1a6b1e1ac9531a41c86406ada4bd4ab903307fdc))

# [@adobe/spacecat-shared-data-access-v2.61.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.60.1...@adobe/spacecat-shared-data-access-v2.61.0) (2025-09-01)


### Features

* add bucket config inside llmo ([#944](https://github.com/adobe/spacecat-shared/issues/944)) ([0153f33](https://github.com/adobe/spacecat-shared/commit/0153f33615b3ccc51f6adee0475027ad93a41480))

# [@adobe/spacecat-shared-data-access-v2.60.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.60.0...@adobe/spacecat-shared-data-access-v2.60.1) (2025-08-29)


### Bug Fixes

* Fix findBy typescript definitions for LLMO tier types ([#942](https://github.com/adobe/spacecat-shared/issues/942)) ([396ca6f](https://github.com/adobe/spacecat-shared/commit/396ca6f1c4a251652c63449f9d67b89472f0065c))

# [@adobe/spacecat-shared-data-access-v2.60.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.59.0...@adobe/spacecat-shared-data-access-v2.60.0) (2025-08-29)


### Features

* add headings audit ([#943](https://github.com/adobe/spacecat-shared/issues/943)) ([17d45dd](https://github.com/adobe/spacecat-shared/commit/17d45dd624d5ada1feafa25ea541ff841a490d34))

# [@adobe/spacecat-shared-data-access-v2.59.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.58.0...@adobe/spacecat-shared-data-access-v2.59.0) (2025-08-29)


### Features

* added new audit-type LLM Error Pages ([#918](https://github.com/adobe/spacecat-shared/issues/918)) ([2f4ffbd](https://github.com/adobe/spacecat-shared/commit/2f4ffbd2b9cfbbf6fe534e92409649f97e9ee540))

# [@adobe/spacecat-shared-data-access-v2.58.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.57.1...@adobe/spacecat-shared-data-access-v2.58.0) (2025-08-28)


### Features

* **dataAccess:** Add entities for LLMO trial onboarding ([#928](https://github.com/adobe/spacecat-shared/issues/928)) ([b5acc3c](https://github.com/adobe/spacecat-shared/commit/b5acc3c3af49d5fd45b8abf91b851fe23da60bc7))

# [@adobe/spacecat-shared-data-access-v2.57.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.57.0...@adobe/spacecat-shared-data-access-v2.57.1) (2025-08-26)


### Bug Fixes

* use DELIVERY_TYPES from shared-utils ([#933](https://github.com/adobe/spacecat-shared/issues/933)) ([3592540](https://github.com/adobe/spacecat-shared/commit/3592540fc3cee05333fbf854447755b727dafae1))

# [@adobe/spacecat-shared-data-access-v2.57.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.56.1...@adobe/spacecat-shared-data-access-v2.57.0) (2025-08-22)


### Features

* add new redirect-chains audit ([#929](https://github.com/adobe/spacecat-shared/issues/929)) ([256c924](https://github.com/adobe/spacecat-shared/commit/256c924ce953a440dbd27d94a73cd6051f5e83b5))

# [@adobe/spacecat-shared-data-access-v2.56.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.56.0...@adobe/spacecat-shared-data-access-v2.56.1) (2025-08-20)


### Bug Fixes

* add readability as audit type ([#926](https://github.com/adobe/spacecat-shared/issues/926)) ([c9cec04](https://github.com/adobe/spacecat-shared/commit/c9cec041b4302eb792c5d715658e6f9e306e35b8))

# [@adobe/spacecat-shared-data-access-v2.56.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.55.0...@adobe/spacecat-shared-data-access-v2.56.0) (2025-08-20)


### Features

* add cdn filters in llmo config ([#925](https://github.com/adobe/spacecat-shared/issues/925)) ([021110b](https://github.com/adobe/spacecat-shared/commit/021110bbf7da221d41a808af54ed43f5e5f513ea))

# [@adobe/spacecat-shared-data-access-v2.55.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.54.0...@adobe/spacecat-shared-data-access-v2.55.0) (2025-08-20)


### Features

* add scrape-client destination  ([#913](https://github.com/adobe/spacecat-shared/issues/913)) ([e208a87](https://github.com/adobe/spacecat-shared/commit/e208a87214874a2708ac2d7614fcfd4c0770fe17))

# [@adobe/spacecat-shared-data-access-v2.54.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.53.0...@adobe/spacecat-shared-data-access-v2.54.0) (2025-08-13)


### Features

* add isOriginal field to scrapeUrl ([#908](https://github.com/adobe/spacecat-shared/issues/908)) ([03dfd59](https://github.com/adobe/spacecat-shared/commit/03dfd59c94f91204ac995aeeac53d4e128317dd5))

# [@adobe/spacecat-shared-data-access-v2.53.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.52.0...@adobe/spacecat-shared-data-access-v2.53.0) (2025-08-12)


### Features

* add llmo methods for api endpoints ([#910](https://github.com/adobe/spacecat-shared/issues/910)) ([be938d5](https://github.com/adobe/spacecat-shared/commit/be938d5bd2bf3d430ab6f7b4b3ee4734aab98185))

# [@adobe/spacecat-shared-data-access-v2.52.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.51.1...@adobe/spacecat-shared-data-access-v2.52.0) (2025-08-12)


### Features

* support extra properties for messages audit -> import ([#911](https://github.com/adobe/spacecat-shared/issues/911)) ([ebbccc1](https://github.com/adobe/spacecat-shared/commit/ebbccc17cdfa02a4f046c705a4410e697894cdb8))

# [@adobe/spacecat-shared-data-access-v2.51.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.51.0...@adobe/spacecat-shared-data-access-v2.51.1) (2025-08-12)


### Bug Fixes

* naming of the new llmo prompts import ([#907](https://github.com/adobe/spacecat-shared/issues/907)) ([e3a6703](https://github.com/adobe/spacecat-shared/commit/e3a6703ac7a052946b93707179c237274ec255c6))

# [@adobe/spacecat-shared-data-access-v2.51.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.50.0...@adobe/spacecat-shared-data-access-v2.51.0) (2025-08-12)


### Features

* removed slash from reports path ([#906](https://github.com/adobe/spacecat-shared/issues/906)) ([44ace99](https://github.com/adobe/spacecat-shared/commit/44ace9999fc2d5d2fc332b03cae7ceafbd9a939a))

# [@adobe/spacecat-shared-data-access-v2.50.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.49.0...@adobe/spacecat-shared-data-access-v2.50.0) (2025-08-12)


### Features

* SITES-34221 implemented getters for raw and ai reports ([#905](https://github.com/adobe/spacecat-shared/issues/905)) ([e2916f5](https://github.com/adobe/spacecat-shared/commit/e2916f52e5b13350a37d34502f65b7454f65cd0b))

# [@adobe/spacecat-shared-data-access-v2.49.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.48.0...@adobe/spacecat-shared-data-access-v2.49.0) (2025-08-11)


### Features

* simpler config for llmo-prompts-ahref import ([#904](https://github.com/adobe/spacecat-shared/issues/904)) ([39a65d7](https://github.com/adobe/spacecat-shared/commit/39a65d7260d10ba2e30f5a61ef68551e5bbf24af))

# [@adobe/spacecat-shared-data-access-v2.48.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.47.0...@adobe/spacecat-shared-data-access-v2.48.0) (2025-08-11)


### Features

* add import type llmo-prompts-ahref ([#902](https://github.com/adobe/spacecat-shared/issues/902)) ([64b7ba0](https://github.com/adobe/spacecat-shared/commit/64b7ba0bf622fe2eff021f2e3660d5f809a0c8b2))

# [@adobe/spacecat-shared-data-access-v2.47.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.46.2...@adobe/spacecat-shared-data-access-v2.47.0) (2025-08-11)


### Features

* make customerIntent config generic ([#896](https://github.com/adobe/spacecat-shared/issues/896)) ([d02a592](https://github.com/adobe/spacecat-shared/commit/d02a592fb556d282f652f8dc9c2603ae47a0e93c))

# [@adobe/spacecat-shared-data-access-v2.46.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.46.1...@adobe/spacecat-shared-data-access-v2.46.2) (2025-08-11)


### Bug Fixes

* [preflight] removing ref from externalOwnerId to find site for a branch-based preview URL ([#843](https://github.com/adobe/spacecat-shared/issues/843)) ([4f57fcf](https://github.com/adobe/spacecat-shared/commit/4f57fcf2f645279e423455dea60df37e116950b4))

# [@adobe/spacecat-shared-data-access-v2.46.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.46.0...@adobe/spacecat-shared-data-access-v2.46.1) (2025-08-09)


### Bug Fixes

* **deps:** update external fixes ([#899](https://github.com/adobe/spacecat-shared/issues/899)) ([c2cc342](https://github.com/adobe/spacecat-shared/commit/c2cc3422a0a4a3f8d1a2724847da456bf801ff59))

# [@adobe/spacecat-shared-data-access-v2.46.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.45.0...@adobe/spacecat-shared-data-access-v2.46.0) (2025-08-08)


### Features

* add paid traffic analysis audit ([#892](https://github.com/adobe/spacecat-shared/issues/892)) ([6d68f74](https://github.com/adobe/spacecat-shared/commit/6d68f7413be811220f0ad651ed4837d2133f832f))

# [@adobe/spacecat-shared-data-access-v2.45.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.44.0...@adobe/spacecat-shared-data-access-v2.45.0) (2025-08-07)


### Features

* hreflang as an audit type ([#893](https://github.com/adobe/spacecat-shared/issues/893)) ([3fe4b8d](https://github.com/adobe/spacecat-shared/commit/3fe4b8d0be59bd5ca9e5492dfb6ced11a5652afd))

# [@adobe/spacecat-shared-data-access-v2.44.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.43.2...@adobe/spacecat-shared-data-access-v2.44.0) (2025-08-06)


### Features

* add customer intent, filter schema and tags for llmo subconfig (LLMO-198, LLMO-202) ([#890](https://github.com/adobe/spacecat-shared/issues/890)) ([e11af65](https://github.com/adobe/spacecat-shared/commit/e11af6525b5ada6966d4c0424cc394e95c49c7a8))

# [@adobe/spacecat-shared-data-access-v2.43.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.43.1...@adobe/spacecat-shared-data-access-v2.43.2) (2025-08-04)


### Bug Fixes

* **deps:** update external fixes ([#888](https://github.com/adobe/spacecat-shared/issues/888)) ([45ccd67](https://github.com/adobe/spacecat-shared/commit/45ccd679577031d01771aa642ac0c2e33b22af6f))

# [@adobe/spacecat-shared-data-access-v2.43.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.43.0...@adobe/spacecat-shared-data-access-v2.43.1) (2025-08-04)


### Bug Fixes

* mark formSource optional in SiteTopForm model ([#884](https://github.com/adobe/spacecat-shared/issues/884)) ([7ea285b](https://github.com/adobe/spacecat-shared/commit/7ea285b59809e4983ec6337b9544be57ed62148e))

# [@adobe/spacecat-shared-data-access-v2.43.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.42.0...@adobe/spacecat-shared-data-access-v2.43.0) (2025-07-30)


### Features

* Add `'never'` to job intervals ([#885](https://github.com/adobe/spacecat-shared/issues/885)) ([#886](https://github.com/adobe/spacecat-shared/issues/886)) ([07a92ce](https://github.com/adobe/spacecat-shared/commit/07a92ce2659e27a85058d1d40942ec7e8b8897e3))

# [@adobe/spacecat-shared-data-access-v2.42.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.41.0...@adobe/spacecat-shared-data-access-v2.42.0) (2025-07-29)


### Features

* added `status` field in reports ([#883](https://github.com/adobe/spacecat-shared/issues/883)) ([f6e9fcd](https://github.com/adobe/spacecat-shared/commit/f6e9fcd1e8e5eabb731c4cdbd89654fc725c9837))

# [@adobe/spacecat-shared-data-access-v2.41.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.40.2...@adobe/spacecat-shared-data-access-v2.41.0) (2025-07-28)


### Features

* add top form model ([#863](https://github.com/adobe/spacecat-shared/issues/863)) ([66138ce](https://github.com/adobe/spacecat-shared/commit/66138ced4a0b0e3c68bf0aaec02b7adaafb0503d))

# [@adobe/spacecat-shared-data-access-v2.40.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.40.1...@adobe/spacecat-shared-data-access-v2.40.2) (2025-07-28)


### Bug Fixes

* SITES-33793 update updatedAt field in _saveMany method ([#860](https://github.com/adobe/spacecat-shared/issues/860)) ([5d6454b](https://github.com/adobe/spacecat-shared/commit/5d6454b7ef9eedee39c41eda56d72324bc472c09))

# [@adobe/spacecat-shared-data-access-v2.40.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.40.0...@adobe/spacecat-shared-data-access-v2.40.1) (2025-07-27)


### Bug Fixes

* **deps:** update external fixes ([#878](https://github.com/adobe/spacecat-shared/issues/878)) ([b049828](https://github.com/adobe/spacecat-shared/commit/b04982839c0ff5e4de4ab0e37508c5eb5272a679))

# [@adobe/spacecat-shared-data-access-v2.40.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.39.0...@adobe/spacecat-shared-data-access-v2.40.0) (2025-07-24)


### Features

* amend llmo config with URL patterns ([#869](https://github.com/adobe/spacecat-shared/issues/869)) ([c6cb047](https://github.com/adobe/spacecat-shared/commit/c6cb0476c6d2b3dad048855ae49481ae8fcfb5ce))

# [@adobe/spacecat-shared-data-access-v2.39.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.38.1...@adobe/spacecat-shared-data-access-v2.39.0) (2025-07-22)


### Features

* add llmo specific configuration in site config ([#853](https://github.com/adobe/spacecat-shared/issues/853)) ([476b8e8](https://github.com/adobe/spacecat-shared/commit/476b8e84009602a4c9d7ef8d42b9efcae3beae9e))

# [@adobe/spacecat-shared-data-access-v2.38.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.38.0...@adobe/spacecat-shared-data-access-v2.38.1) (2025-07-22)


### Bug Fixes

* return provided data when config error ([#862](https://github.com/adobe/spacecat-shared/issues/862)) ([eb418cd](https://github.com/adobe/spacecat-shared/commit/eb418cdf4e942f2da0b40d95cc991b9a4a34a393))

# [@adobe/spacecat-shared-data-access-v2.38.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.37.0...@adobe/spacecat-shared-data-access-v2.38.0) (2025-07-21)


### Features

* add pageTypes to store pattern matching for pageTypes ([#857](https://github.com/adobe/spacecat-shared/issues/857)) ([4081e8c](https://github.com/adobe/spacecat-shared/commit/4081e8cfd8571d43b9720c07caeb22ced77281d0))

# [@adobe/spacecat-shared-data-access-v2.37.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.36.1...@adobe/spacecat-shared-data-access-v2.37.0) (2025-07-21)


### Features

* added `Report` model, schema and collection implementation ([#855](https://github.com/adobe/spacecat-shared/issues/855)) ([4100a0e](https://github.com/adobe/spacecat-shared/commit/4100a0e557709d29dd590ff87c987d70b005f734))

# [@adobe/spacecat-shared-data-access-v2.36.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.36.0...@adobe/spacecat-shared-data-access-v2.36.1) (2025-07-19)


### Bug Fixes

* **deps:** update external fixes ([#859](https://github.com/adobe/spacecat-shared/issues/859)) ([7ca9099](https://github.com/adobe/spacecat-shared/commit/7ca90994d61d07f71e580301365447b94ad07a52))

# [@adobe/spacecat-shared-data-access-v2.36.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.35.0...@adobe/spacecat-shared-data-access-v2.36.0) (2025-07-17)


### Features

* page intent entity ([#856](https://github.com/adobe/spacecat-shared/issues/856)) ([9e6f709](https://github.com/adobe/spacecat-shared/commit/9e6f70925dc8b9467081e2a1a1b23968a2089638))

# [@adobe/spacecat-shared-data-access-v2.35.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.34.1...@adobe/spacecat-shared-data-access-v2.35.0) (2025-07-17)


### Features

* introduce isSandbox flag for sandbox sites ([#842](https://github.com/adobe/spacecat-shared/issues/842)) ([066adb4](https://github.com/adobe/spacecat-shared/commit/066adb4629901a82b7c5c21297795d82eb771d29))

# [@adobe/spacecat-shared-data-access-v2.34.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.34.0...@adobe/spacecat-shared-data-access-v2.34.1) (2025-07-16)


### Bug Fixes

* add try catch for config for sites validation ([#850](https://github.com/adobe/spacecat-shared/issues/850)) ([17c8402](https://github.com/adobe/spacecat-shared/commit/17c84023568de20395ba52a6876683f1354ba6b7))

# [@adobe/spacecat-shared-data-access-v2.34.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.33.6...@adobe/spacecat-shared-data-access-v2.34.0) (2025-07-14)


### Features

* add traffic analysis import handler ([#846](https://github.com/adobe/spacecat-shared/issues/846)) ([c8b65f0](https://github.com/adobe/spacecat-shared/commit/c8b65f0b0a29afdafc84686cf8b2ff1f6f9ed9cb))

# [@adobe/spacecat-shared-data-access-v2.33.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.33.5...@adobe/spacecat-shared-data-access-v2.33.6) (2025-07-12)


### Bug Fixes

* **deps:** update external fixes ([#845](https://github.com/adobe/spacecat-shared/issues/845)) ([23bd3a2](https://github.com/adobe/spacecat-shared/commit/23bd3a2235686480cb89d6379276d9ed000baea3))

# [@adobe/spacecat-shared-data-access-v2.33.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.33.4...@adobe/spacecat-shared-data-access-v2.33.5) (2025-07-10)


### Bug Fixes

* adding pageUrl and urlConfigs to import worker payload formatter ([#833](https://github.com/adobe/spacecat-shared/issues/833)) ([b9e7254](https://github.com/adobe/spacecat-shared/commit/b9e7254107b8690df0a414a80b4c9afce8f3a994))

# [@adobe/spacecat-shared-data-access-v2.33.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.33.3...@adobe/spacecat-shared-data-access-v2.33.4) (2025-07-10)


### Bug Fixes

* Supporting userId in brandConfig ([#838](https://github.com/adobe/spacecat-shared/issues/838)) ([b585ea6](https://github.com/adobe/spacecat-shared/commit/b585ea6e1821925644bac59bbe9e0fcadfaa55be))

# [@adobe/spacecat-shared-data-access-v2.33.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.33.2...@adobe/spacecat-shared-data-access-v2.33.3) (2025-07-09)


### Bug Fixes

* Update shared-data schema to include 'da' type in options ([#839](https://github.com/adobe/spacecat-shared/issues/839)) ([7131377](https://github.com/adobe/spacecat-shared/commit/7131377f088dc8457aef361682c78e64891cea7f))

# [@adobe/spacecat-shared-data-access-v2.33.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.33.1...@adobe/spacecat-shared-data-access-v2.33.2) (2025-07-08)


### Bug Fixes

* external site ID indexes for crosswalk authorType ([#840](https://github.com/adobe/spacecat-shared/issues/840)) ([6ac2a6e](https://github.com/adobe/spacecat-shared/commit/6ac2a6e8bd5aa082aa58498a7acd80f176932d7d))

# [@adobe/spacecat-shared-data-access-v2.33.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.33.0...@adobe/spacecat-shared-data-access-v2.33.1) (2025-07-05)


### Bug Fixes

* **deps:** update external fixes ([#837](https://github.com/adobe/spacecat-shared/issues/837)) ([acfbbe7](https://github.com/adobe/spacecat-shared/commit/acfbbe712d90fe2f4b0cab97e8a941eb1bd5c8ea))

# [@adobe/spacecat-shared-data-access-v2.33.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.32.1...@adobe/spacecat-shared-data-access-v2.33.0) (2025-07-02)


### Features

* add type for filter ([#836](https://github.com/adobe/spacecat-shared/issues/836)) ([e70cbf6](https://github.com/adobe/spacecat-shared/commit/e70cbf60550aa485c3b38ff3ed28393d8fd4b066))

# [@adobe/spacecat-shared-data-access-v2.32.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.32.0...@adobe/spacecat-shared-data-access-v2.32.1) (2025-06-30)


### Bug Fixes

* make filter value array ([#834](https://github.com/adobe/spacecat-shared/issues/834)) ([db48daa](https://github.com/adobe/spacecat-shared/commit/db48daab3907917f32f71fed27b7468790c0c2d5))

# [@adobe/spacecat-shared-data-access-v2.32.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.31.1...@adobe/spacecat-shared-data-access-v2.32.0) (2025-06-30)


### Features

* added paid traffic suggestion type ([#832](https://github.com/adobe/spacecat-shared/issues/832)) ([5ed8d52](https://github.com/adobe/spacecat-shared/commit/5ed8d52e93228b69ba6fe0a5da7309afbf8c479e))

# [@adobe/spacecat-shared-data-access-v2.31.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.31.0...@adobe/spacecat-shared-data-access-v2.31.1) (2025-06-28)


### Bug Fixes

* **deps:** update external fixes ([#830](https://github.com/adobe/spacecat-shared/issues/830)) ([b98589d](https://github.com/adobe/spacecat-shared/commit/b98589da5c11aa4e63358e98f0c0852b0ef2a02d))

# [@adobe/spacecat-shared-data-access-v2.31.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.30.1...@adobe/spacecat-shared-data-access-v2.31.0) (2025-06-27)


### Features

* introduce authoring type ([#826](https://github.com/adobe/spacecat-shared/issues/826)) ([36202ec](https://github.com/adobe/spacecat-shared/commit/36202ec19be415043ae333b2a3428d69595d920b))

# [@adobe/spacecat-shared-data-access-v2.30.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.30.0...@adobe/spacecat-shared-data-access-v2.30.1) (2025-06-26)


### Bug Fixes

* add setter for cdn logs condfig ([#828](https://github.com/adobe/spacecat-shared/issues/828)) ([094edf3](https://github.com/adobe/spacecat-shared/commit/094edf3edf362531930294b5195c55239f8b3efc))

# [@adobe/spacecat-shared-data-access-v2.30.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.29.1...@adobe/spacecat-shared-data-access-v2.30.0) (2025-06-26)


### Features

* add CDN logs config ([#827](https://github.com/adobe/spacecat-shared/issues/827)) ([c4dd99b](https://github.com/adobe/spacecat-shared/commit/c4dd99bf142312b8285491769ea552c90f3e60aa))

# [@adobe/spacecat-shared-data-access-v2.29.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.29.0...@adobe/spacecat-shared-data-access-v2.29.1) (2025-06-21)


### Bug Fixes

* **deps:** update external fixes ([#817](https://github.com/adobe/spacecat-shared/issues/817)) ([522b440](https://github.com/adobe/spacecat-shared/commit/522b440ac1ac1d704b4106ad1f90f192541a8f0c))

# [@adobe/spacecat-shared-data-access-v2.29.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.28.0...@adobe/spacecat-shared-data-access-v2.29.0) (2025-06-20)


### Features

* introduce findByPreviewURL in site collection ([#773](https://github.com/adobe/spacecat-shared/issues/773)) ([3b7c092](https://github.com/adobe/spacecat-shared/commit/3b7c0925ce66bcb8d38db3e05cc04fefd0cac229))

# [@adobe/spacecat-shared-data-access-v2.28.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.27.0...@adobe/spacecat-shared-data-access-v2.28.0) (2025-06-20)


### Features

* add paid audit type ([#811](https://github.com/adobe/spacecat-shared/issues/811)) ([e8aae98](https://github.com/adobe/spacecat-shared/commit/e8aae9853f2d53c22a352cf41417829a15e55319))

# [@adobe/spacecat-shared-data-access-v2.27.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.26.0...@adobe/spacecat-shared-data-access-v2.27.0) (2025-06-19)


### Features

* added `getDisabledAuditsForSite` for slack command ([#812](https://github.com/adobe/spacecat-shared/issues/812)) ([56ab4b4](https://github.com/adobe/spacecat-shared/commit/56ab4b4bd76ec8edac9b9219b725b1442d11ef14))

# [@adobe/spacecat-shared-data-access-v2.26.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.25.0...@adobe/spacecat-shared-data-access-v2.26.0) (2025-06-19)


### Features

* added scrape client ([#814](https://github.com/adobe/spacecat-shared/issues/814)) ([fad6614](https://github.com/adobe/spacecat-shared/commit/fad6614672a046da5319e493cc7c26bfdc3993d2))

# [@adobe/spacecat-shared-data-access-v2.25.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.24.1...@adobe/spacecat-shared-data-access-v2.25.0) (2025-06-18)


### Features

* introduce ScrapeJob and ScrapeUrl entities ([#803](https://github.com/adobe/spacecat-shared/issues/803)) ([d295f65](https://github.com/adobe/spacecat-shared/commit/d295f65a89a986f08d5d3b28fe60b45d4c65ee36))

# [@adobe/spacecat-shared-data-access-v2.24.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.24.0...@adobe/spacecat-shared-data-access-v2.24.1) (2025-06-14)


### Bug Fixes

* **deps:** update external fixes ([#802](https://github.com/adobe/spacecat-shared/issues/802)) ([fc2cb47](https://github.com/adobe/spacecat-shared/commit/fc2cb47183948833f5b0a411ae78d1649e747a17))

# [@adobe/spacecat-shared-data-access-v2.24.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.23.3...@adobe/spacecat-shared-data-access-v2.24.0) (2025-06-13)


### Features

* added security-csp as an audit type ([#801](https://github.com/adobe/spacecat-shared/issues/801)) ([4c3aa51](https://github.com/adobe/spacecat-shared/commit/4c3aa5194fc7e6b102cdab8ce1c6875ec5379821))

# [@adobe/spacecat-shared-data-access-v2.23.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.23.2...@adobe/spacecat-shared-data-access-v2.23.3) (2025-06-07)


### Bug Fixes

* **deps:** update external fixes ([#794](https://github.com/adobe/spacecat-shared/issues/794)) ([756cc67](https://github.com/adobe/spacecat-shared/commit/756cc67513540b0fc69ead1b90345891fef64793))

# [@adobe/spacecat-shared-data-access-v2.23.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.23.1...@adobe/spacecat-shared-data-access-v2.23.2) (2025-06-04)


### Bug Fixes

* typo issue for elmo ([#788](https://github.com/adobe/spacecat-shared/issues/788)) ([ba56401](https://github.com/adobe/spacecat-shared/commit/ba5640131566d0980a9104114cbe57fcfc53c181))

# [@adobe/spacecat-shared-data-access-v2.23.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.23.0...@adobe/spacecat-shared-data-access-v2.23.1) (2025-06-04)


### Bug Fixes

* new organic keyword imports configs ([#787](https://github.com/adobe/spacecat-shared/issues/787)) ([b2e70fc](https://github.com/adobe/spacecat-shared/commit/b2e70fc77f4695e7aaf4cb8e578410b459226e82))

# [@adobe/spacecat-shared-data-access-v2.23.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.22.2...@adobe/spacecat-shared-data-access-v2.23.0) (2025-06-04)


### Features

* add new keyword import types ([#786](https://github.com/adobe/spacecat-shared/issues/786)) ([e82c55e](https://github.com/adobe/spacecat-shared/commit/e82c55e5fe1b27603e35b2fdf5e5c23c3c1d338c))

# [@adobe/spacecat-shared-data-access-v2.22.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.22.1...@adobe/spacecat-shared-data-access-v2.22.2) (2025-05-31)


### Bug Fixes

* **deps:** update external fixes ([#779](https://github.com/adobe/spacecat-shared/issues/779)) ([07f8cce](https://github.com/adobe/spacecat-shared/commit/07f8cce73e33bfb9c61fe14f2ef28012b872437d))

# [@adobe/spacecat-shared-data-access-v2.22.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.22.0...@adobe/spacecat-shared-data-access-v2.22.1) (2025-05-27)


### Bug Fixes

* amend DEFAULT_IMPORT_CONFIGS ([#771](https://github.com/adobe/spacecat-shared/issues/771)) ([5d2b8c3](https://github.com/adobe/spacecat-shared/commit/5d2b8c304df72cc546cd9fc40e16123b0792c0cc))

# [@adobe/spacecat-shared-data-access-v2.22.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.21.0...@adobe/spacecat-shared-data-access-v2.22.0) (2025-05-27)


### Features

* add `organic-keywords-nonbranded` import type to site config ([#766](https://github.com/adobe/spacecat-shared/issues/766)) ([a3be1ec](https://github.com/adobe/spacecat-shared/commit/a3be1ec3a31dd0361fb475da329cb1655a875ebd))
* add 405 response util ([#768](https://github.com/adobe/spacecat-shared/issues/768)) ([300ceb2](https://github.com/adobe/spacecat-shared/commit/300ceb2c979b304849a30f0e227823308d144c40))

# [@adobe/spacecat-shared-data-access-v2.21.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.20.1...@adobe/spacecat-shared-data-access-v2.21.0) (2025-05-26)


### Features

* add updatedBy attribute to entities and ims api to resolve profile ([#758](https://github.com/adobe/spacecat-shared/issues/758)) ([47f73ff](https://github.com/adobe/spacecat-shared/commit/47f73ff18609f0b97576c391caad7409f0d24349))

# [@adobe/spacecat-shared-data-access-v2.20.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.20.0...@adobe/spacecat-shared-data-access-v2.20.1) (2025-05-24)


### Bug Fixes

* **deps:** update external fixes ([#762](https://github.com/adobe/spacecat-shared/issues/762)) ([2eb5a22](https://github.com/adobe/spacecat-shared/commit/2eb5a22935a7293ef293157e0b0fe6506d5b4c94))

# [@adobe/spacecat-shared-data-access-v2.20.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.19.4...@adobe/spacecat-shared-data-access-v2.20.0) (2025-05-23)


### Features

* added accessibility as an audit type ([#759](https://github.com/adobe/spacecat-shared/issues/759)) ([9ec2874](https://github.com/adobe/spacecat-shared/commit/9ec2874a18b27ab2c923b2944cbbc89d82996291))

# [@adobe/spacecat-shared-data-access-v2.19.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.19.3...@adobe/spacecat-shared-data-access-v2.19.4) (2025-05-22)


### Bug Fixes

* async job schema ([#756](https://github.com/adobe/spacecat-shared/issues/756)) ([1546cdd](https://github.com/adobe/spacecat-shared/commit/1546cdd07907b1f41684d6486b38004bd5e893d1))

# [@adobe/spacecat-shared-data-access-v2.19.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.19.2...@adobe/spacecat-shared-data-access-v2.19.3) (2025-05-17)


### Bug Fixes

* **deps:** update external fixes ([#743](https://github.com/adobe/spacecat-shared/issues/743)) ([afee6a7](https://github.com/adobe/spacecat-shared/commit/afee6a75d7cb6fb52d5fd18dbc5d74f2e73206f2))

# [@adobe/spacecat-shared-data-access-v2.19.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.19.1...@adobe/spacecat-shared-data-access-v2.19.2) (2025-05-16)


### Bug Fixes

* default table name ([#742](https://github.com/adobe/spacecat-shared/issues/742)) ([deaa0af](https://github.com/adobe/spacecat-shared/commit/deaa0afee239d2f24444cb39df54a929135617ba))

# [@adobe/spacecat-shared-data-access-v2.19.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.19.0...@adobe/spacecat-shared-data-access-v2.19.1) (2025-05-15)


### Bug Fixes

* local development friendly aws clients and sqs wrapper ([#739](https://github.com/adobe/spacecat-shared/issues/739)) ([fada9c6](https://github.com/adobe/spacecat-shared/commit/fada9c6fc0508ba6acf46a4416593427b67306dd))

# [@adobe/spacecat-shared-data-access-v2.19.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.18.0...@adobe/spacecat-shared-data-access-v2.19.0) (2025-05-14)


### Features

* adding options to scraper sqs payload ([#733](https://github.com/adobe/spacecat-shared/issues/733)) ([eb9a08b](https://github.com/adobe/spacecat-shared/commit/eb9a08b06bc48388a5aa3c78f9ce57c05ef04313))

# [@adobe/spacecat-shared-data-access-v2.18.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.17.4...@adobe/spacecat-shared-data-access-v2.18.0) (2025-05-12)


### Features

* content scraper audit step will honour the allowCache value fro… ([#725](https://github.com/adobe/spacecat-shared/issues/725)) ([89bfe23](https://github.com/adobe/spacecat-shared/commit/89bfe231b368aaf65eba1777c3799e5cd42fe8f6))

# [@adobe/spacecat-shared-data-access-v2.17.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.17.3...@adobe/spacecat-shared-data-access-v2.17.4) (2025-05-12)


### Bug Fixes

* Update type definitions for FixEntity ([#731](https://github.com/adobe/spacecat-shared/issues/731)) ([cb0bee7](https://github.com/adobe/spacecat-shared/commit/cb0bee72e6d6e7d6cddaefc55f3e20230884b8ec))

# [@adobe/spacecat-shared-data-access-v2.17.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.17.2...@adobe/spacecat-shared-data-access-v2.17.3) (2025-05-10)


### Bug Fixes

* **deps:** update external fixes ([#726](https://github.com/adobe/spacecat-shared/issues/726)) ([adbd174](https://github.com/adobe/spacecat-shared/commit/adbd174a05b46578ef636a6c4f69ea4d329581c9))

# [@adobe/spacecat-shared-data-access-v2.17.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.17.1...@adobe/spacecat-shared-data-access-v2.17.2) (2025-05-08)


### Bug Fixes

* collection._saveMany deals with empty `.unprocessed` array in response ([#721](https://github.com/adobe/spacecat-shared/issues/721)) ([2750273](https://github.com/adobe/spacecat-shared/commit/27502735d2759d83a65129cb2c0ccb09f974368d))

# [@adobe/spacecat-shared-data-access-v2.17.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.17.0...@adobe/spacecat-shared-data-access-v2.17.1) (2025-05-03)


### Bug Fixes

* **deps:** update external fixes ([#712](https://github.com/adobe/spacecat-shared/issues/712)) ([76cebd2](https://github.com/adobe/spacecat-shared/commit/76cebd2a7a7b9799e4ca265833620eada01f5c8c))

# [@adobe/spacecat-shared-data-access-v2.17.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.16.1...@adobe/spacecat-shared-data-access-v2.17.0) (2025-04-28)


### Features

* async job ([#698](https://github.com/adobe/spacecat-shared/issues/698)) ([31cf58f](https://github.com/adobe/spacecat-shared/commit/31cf58fc9ef128d2cf094afe0286932c7edc369d))

# [@adobe/spacecat-shared-data-access-v2.16.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.16.0...@adobe/spacecat-shared-data-access-v2.16.1) (2025-04-26)


### Bug Fixes

* **deps:** update external fixes ([#708](https://github.com/adobe/spacecat-shared/issues/708)) ([57535ac](https://github.com/adobe/spacecat-shared/commit/57535ac8c636de229cec7c5cee83dead07ac09fb))

# [@adobe/spacecat-shared-data-access-v2.16.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.15.2...@adobe/spacecat-shared-data-access-v2.16.0) (2025-04-24)


### Features

* Added cwv-daily and cwv-weekly import types ([#693](https://github.com/adobe/spacecat-shared/issues/693)) ([659826b](https://github.com/adobe/spacecat-shared/commit/659826b37cea03aa08f2db36a0ff7a43437c03a7))

# [@adobe/spacecat-shared-data-access-v2.15.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.15.1...@adobe/spacecat-shared-data-access-v2.15.2) (2025-04-17)


### Bug Fixes

* add comments ([7b62a79](https://github.com/adobe/spacecat-shared/commit/7b62a7987d5f72f100840543870b74b9b783e721))

# [@adobe/spacecat-shared-data-access-v2.15.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.15.0...@adobe/spacecat-shared-data-access-v2.15.1) (2025-04-17)


### Bug Fixes

* completion queue url for audit jobs ([#697](https://github.com/adobe/spacecat-shared/issues/697)) ([5987a4c](https://github.com/adobe/spacecat-shared/commit/5987a4cda6f682e12270e202d5bfd262b156d104))

# [@adobe/spacecat-shared-data-access-v2.15.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.14.1...@adobe/spacecat-shared-data-access-v2.15.0) (2025-04-17)


### Bug Fixes

* completionUrl not sent to content scraper and introduce skip property ([#685](https://github.com/adobe/spacecat-shared/issues/685)) ([4d89a29](https://github.com/adobe/spacecat-shared/commit/4d89a297495fa69ebbcc0429ed879b2edafbd760))


### Features

* Add contentAiConfig validation to Config class ([#686](https://github.com/adobe/spacecat-shared/issues/686)) ([077fbbd](https://github.com/adobe/spacecat-shared/commit/077fbbd583f5567c265fe47e724ea5ce9f1a722d))

# [@adobe/spacecat-shared-data-access-v2.14.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.14.0...@adobe/spacecat-shared-data-access-v2.14.1) (2025-04-15)


### Bug Fixes

* **deps:** update external fixes ([#679](https://github.com/adobe/spacecat-shared/issues/679)) ([a41bf0c](https://github.com/adobe/spacecat-shared/commit/a41bf0cd488efa0f72af0933992edb256302af18))

# [@adobe/spacecat-shared-data-access-v2.14.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.13.3...@adobe/spacecat-shared-data-access-v2.14.0) (2025-04-11)


### Features

* add FixEntity for keeping track of the suggestion fixes ([#671](https://github.com/adobe/spacecat-shared/issues/671)) ([3be02da](https://github.com/adobe/spacecat-shared/commit/3be02da115cbb2d106e863ee715a5904aa2c75d2))

# [@adobe/spacecat-shared-data-access-v2.13.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.13.2...@adobe/spacecat-shared-data-access-v2.13.3) (2025-04-08)


### Bug Fixes

* configuration shouldn't check for enabled if audit is enabledByDefault ([#675](https://github.com/adobe/spacecat-shared/issues/675)) ([0d8538a](https://github.com/adobe/spacecat-shared/commit/0d8538ac967e2a69a08ebc462530985780584f0e))

# [@adobe/spacecat-shared-data-access-v2.13.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.13.1...@adobe/spacecat-shared-data-access-v2.13.2) (2025-04-01)


### Bug Fixes

* **deps:** update external major (major) ([#674](https://github.com/adobe/spacecat-shared/issues/674)) ([285b37d](https://github.com/adobe/spacecat-shared/commit/285b37de9df42adb6a23694bcc699608e3b5b8fe))

# [@adobe/spacecat-shared-data-access-v2.13.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.13.0...@adobe/spacecat-shared-data-access-v2.13.1) (2025-03-07)


### Bug Fixes

* **data-access:** fetch all records on demand ([#660](https://github.com/adobe/spacecat-shared/issues/660)) ([16bbeb4](https://github.com/adobe/spacecat-shared/commit/16bbeb4767526c846800480f49e2f7d06912330f))

# [@adobe/spacecat-shared-data-access-v2.13.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.12.0...@adobe/spacecat-shared-data-access-v2.13.0) (2025-03-07)


### Features

* **data-access:** fetch all records on demand ([#659](https://github.com/adobe/spacecat-shared/issues/659)) ([a424f47](https://github.com/adobe/spacecat-shared/commit/a424f4763399ceaa1fb2d09bee454e8d5d0923f9))

# [@adobe/spacecat-shared-data-access-v2.12.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.11.0...@adobe/spacecat-shared-data-access-v2.12.0) (2025-03-06)


### Features

* added structured data auto suggest audit type ([#628](https://github.com/adobe/spacecat-shared/issues/628)) ([6162442](https://github.com/adobe/spacecat-shared/commit/61624423669e0d93e6f2ed3c90c1a134a2458949))

# [@adobe/spacecat-shared-data-access-v2.11.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.10.2...@adobe/spacecat-shared-data-access-v2.11.0) (2025-03-05)


### Features

* Brand client ([#640](https://github.com/adobe/spacecat-shared/issues/640)) ([8d82f45](https://github.com/adobe/spacecat-shared/commit/8d82f45349ea9be2b1359fe5ebebf5a350f52666))

# [@adobe/spacecat-shared-data-access-v2.10.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.10.1...@adobe/spacecat-shared-data-access-v2.10.2) (2025-03-04)


### Bug Fixes

* add all-traffic to import schema ([#647](https://github.com/adobe/spacecat-shared/issues/647)) ([9fb3ee5](https://github.com/adobe/spacecat-shared/commit/9fb3ee56b332d095ff73b8dda235192d6ef31aa7))

# [@adobe/spacecat-shared-data-access-v2.10.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.10.0...@adobe/spacecat-shared-data-access-v2.10.1) (2025-03-04)


### Bug Fixes

* getEnabledAuditsForSite not part of Configuration interface ([#646](https://github.com/adobe/spacecat-shared/issues/646)) ([33d7d03](https://github.com/adobe/spacecat-shared/commit/33d7d03ab52069aacb4f6c97fdfdc971a1eb8f1e))

# [@adobe/spacecat-shared-data-access-v2.10.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.9.6...@adobe/spacecat-shared-data-access-v2.10.0) (2025-03-04)


### Features

* introduce getEnabledAuditsForSite in the configuration model ([#643](https://github.com/adobe/spacecat-shared/issues/643)) ([c4b60f5](https://github.com/adobe/spacecat-shared/commit/c4b60f519b75a7482856c7e1b35a1e087d2f1731))

# [@adobe/spacecat-shared-data-access-v2.9.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.9.5...@adobe/spacecat-shared-data-access-v2.9.6) (2025-03-03)


### Bug Fixes

* **deps:** update external fixes ([#638](https://github.com/adobe/spacecat-shared/issues/638)) ([64625c2](https://github.com/adobe/spacecat-shared/commit/64625c24f1b3b7bc4a26b576155bb6bc8529ef45))

# [@adobe/spacecat-shared-data-access-v2.9.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.9.4...@adobe/spacecat-shared-data-access-v2.9.5) (2025-02-28)


### Bug Fixes

* **override-base-url:** add overrideBaseURL in site.config.fetchConfig ([#633](https://github.com/adobe/spacecat-shared/issues/633)) ([526874f](https://github.com/adobe/spacecat-shared/commit/526874f8665e7bae94ca8968f1cb834cd424ae9f))

# [@adobe/spacecat-shared-data-access-v2.9.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.9.3...@adobe/spacecat-shared-data-access-v2.9.4) (2025-02-27)


### Bug Fixes

* url override in import-schema ([#634](https://github.com/adobe/spacecat-shared/issues/634)) ([39b76fa](https://github.com/adobe/spacecat-shared/commit/39b76facbd215100370cd6c2d9ed19c32fd6f9e7))

# [@adobe/spacecat-shared-data-access-v2.9.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.9.2...@adobe/spacecat-shared-data-access-v2.9.3) (2025-02-26)


### Bug Fixes

* adds OUTDATED suggestion status ([#611](https://github.com/adobe/spacecat-shared/issues/611)) ([51ca3a7](https://github.com/adobe/spacecat-shared/commit/51ca3a711036a7c1e41396c27fc81aa077a0b307))

# [@adobe/spacecat-shared-data-access-v2.9.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.9.1...@adobe/spacecat-shared-data-access-v2.9.2) (2025-02-26)


### Bug Fixes

* add limit param ([#631](https://github.com/adobe/spacecat-shared/issues/631)) ([72faa3c](https://github.com/adobe/spacecat-shared/commit/72faa3cb0a0037558a6dd11372b923562c884668))

# [@adobe/spacecat-shared-data-access-v2.9.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.9.0...@adobe/spacecat-shared-data-access-v2.9.1) (2025-02-26)


### Bug Fixes

* import-schema backwards compatibility ([#630](https://github.com/adobe/spacecat-shared/issues/630)) ([9ef74bf](https://github.com/adobe/spacecat-shared/commit/9ef74bfc89b0ccb9d27d34e5a10eef182b9ee527)), closes [#626](https://github.com/adobe/spacecat-shared/issues/626)

# [@adobe/spacecat-shared-data-access-v2.9.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.8.4...@adobe/spacecat-shared-data-access-v2.9.0) (2025-02-25)


### Features

* import config schema ([#626](https://github.com/adobe/spacecat-shared/issues/626)) ([df147d8](https://github.com/adobe/spacecat-shared/commit/df147d8c8f83cc45f373b1d89823229afe035129))

# [@adobe/spacecat-shared-data-access-v2.8.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.8.3...@adobe/spacecat-shared-data-access-v2.8.4) (2025-02-25)


### Bug Fixes

* add in progress suggestion status ([#627](https://github.com/adobe/spacecat-shared/issues/627)) ([188c83f](https://github.com/adobe/spacecat-shared/commit/188c83f03a16406085e1ae6ecbd129a27a6d41e7))

# [@adobe/spacecat-shared-data-access-v2.8.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.8.2...@adobe/spacecat-shared-data-access-v2.8.3) (2025-02-22)


### Bug Fixes

* **deps:** update external fixes ([#622](https://github.com/adobe/spacecat-shared/issues/622)) ([6552a61](https://github.com/adobe/spacecat-shared/commit/6552a61ebd8b83c0a1dec51d50d44cf3b97819c1))

# [@adobe/spacecat-shared-data-access-v2.8.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.8.1...@adobe/spacecat-shared-data-access-v2.8.2) (2025-02-21)


### Bug Fixes

* validate IMS Org ID ([#618](https://github.com/adobe/spacecat-shared/issues/618)) ([aa79853](https://github.com/adobe/spacecat-shared/commit/aa79853bddea717281f38984ec0cc88c10d12128))

# [@adobe/spacecat-shared-data-access-v2.8.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.8.0...@adobe/spacecat-shared-data-access-v2.8.1) (2025-02-20)


### Bug Fixes

* log fields affected by validation error ([#614](https://github.com/adobe/spacecat-shared/issues/614)) ([e7b91bd](https://github.com/adobe/spacecat-shared/commit/e7b91bdc1d3f2a28b5755ccdbacfdb651411611e))

# [@adobe/spacecat-shared-data-access-v2.8.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.7.1...@adobe/spacecat-shared-data-access-v2.8.0) (2025-02-19)


### Features

* add alt-text audit type constant ([#613](https://github.com/adobe/spacecat-shared/issues/613)) ([cc1bbdb](https://github.com/adobe/spacecat-shared/commit/cc1bbdbfcb0884d1a56f7dacfc360dfaf80a7942))

# [@adobe/spacecat-shared-data-access-v2.7.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.7.0...@adobe/spacecat-shared-data-access-v2.7.1) (2025-02-19)


### Bug Fixes

* get queue url ([#612](https://github.com/adobe/spacecat-shared/issues/612)) ([232af0a](https://github.com/adobe/spacecat-shared/commit/232af0af829289214826275f81504ce6bdae5467))

# [@adobe/spacecat-shared-data-access-v2.7.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.6.0...@adobe/spacecat-shared-data-access-v2.7.0) (2025-02-18)


### Features

* Implement dependency check for handlers ([#608](https://github.com/adobe/spacecat-shared/issues/608)) ([0ada515](https://github.com/adobe/spacecat-shared/commit/0ada5157a3cf50bf67129e296e719a14ee2c451c)), closes [/github.com/adobe/spacecat-shared/blob/main/packages/spacecat-shared-data-access/src/models/configuration/configuration.schema.js#L35-L39](https://github.com//github.com/adobe/spacecat-shared/blob/main/packages/spacecat-shared-data-access/src/models/configuration/configuration.schema.js/issues/L35-L39)

# [@adobe/spacecat-shared-data-access-v2.6.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.5.0...@adobe/spacecat-shared-data-access-v2.6.0) (2025-02-18)


### Features

* **latest-metrics:** add latest metrics handling to config ([#607](https://github.com/adobe/spacecat-shared/issues/607)) ([0233958](https://github.com/adobe/spacecat-shared/commit/0233958f782e1cef24cc3df3c7445520697c1efa))

# [@adobe/spacecat-shared-data-access-v2.5.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.4.0...@adobe/spacecat-shared-data-access-v2.5.0) (2025-02-18)


### Features

* adds site name ([#605](https://github.com/adobe/spacecat-shared/issues/605)) ([f066c3d](https://github.com/adobe/spacecat-shared/commit/f066c3da12e72ee85a97120ac8bb4b5deeca93fa))

# [@adobe/spacecat-shared-data-access-v2.4.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.3.1...@adobe/spacecat-shared-data-access-v2.4.0) (2025-02-17)


### Features

* introduce fetch config for site to use custom headers ([#585](https://github.com/adobe/spacecat-shared/issues/585)) ([10a2892](https://github.com/adobe/spacecat-shared/commit/10a28928c3946ea05c4644f16971ccff8d43e994))

# [@adobe/spacecat-shared-data-access-v2.3.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.3.0...@adobe/spacecat-shared-data-access-v2.3.1) (2025-02-17)


### Bug Fixes

* add aem_ams delivery type ([#601](https://github.com/adobe/spacecat-shared/issues/601)) ([a6a08cf](https://github.com/adobe/spacecat-shared/commit/a6a08cf7c13678a682e564447b6662db5970ea06))

# [@adobe/spacecat-shared-data-access-v2.3.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.2.2...@adobe/spacecat-shared-data-access-v2.3.0) (2025-02-17)


### Features

* audit step destinations ([#602](https://github.com/adobe/spacecat-shared/issues/602)) ([9aa9a8a](https://github.com/adobe/spacecat-shared/commit/9aa9a8a98aeeccd16e665140beae114bdd12924b))

# [@adobe/spacecat-shared-data-access-v2.2.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.2.1...@adobe/spacecat-shared-data-access-v2.2.2) (2025-02-16)


### Bug Fixes

* **deps:** update external fixes ([#603](https://github.com/adobe/spacecat-shared/issues/603)) ([b58d4c7](https://github.com/adobe/spacecat-shared/commit/b58d4c7237fb2522bba9b722e9eed7b0ae9e5f70))

# [@adobe/spacecat-shared-data-access-v2.2.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.2.0...@adobe/spacecat-shared-data-access-v2.2.1) (2025-02-14)


### Bug Fixes

* delivery configuration ([#600](https://github.com/adobe/spacecat-shared/issues/600)) ([a5d1871](https://github.com/adobe/spacecat-shared/commit/a5d1871307b1043d82f5c43fe675130ac42acafe))

# [@adobe/spacecat-shared-data-access-v2.2.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.1.2...@adobe/spacecat-shared-data-access-v2.2.0) (2025-02-12)


### Features

* add delivery configuration object to site object  ([fc1dbd3](https://github.com/adobe/spacecat-shared/commit/fc1dbd341b4f22058e38f90122dd7691b6f5ff8c))

# [@adobe/spacecat-shared-data-access-v2.1.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.1.1...@adobe/spacecat-shared-data-access-v2.1.2) (2025-02-08)


### Bug Fixes

* **deps:** update external fixes ([#587](https://github.com/adobe/spacecat-shared/issues/587)) ([14cce0a](https://github.com/adobe/spacecat-shared/commit/14cce0aa900b4a1b3bbec2d48e6d37766c7769ee))

# [@adobe/spacecat-shared-data-access-v2.1.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.1.0...@adobe/spacecat-shared-data-access-v2.1.1) (2025-02-06)


### Bug Fixes

* **sites-28856:** update shared-data schema to include type in options ([#577](https://github.com/adobe/spacecat-shared/issues/577)) ([de6b670](https://github.com/adobe/spacecat-shared/commit/de6b670f86e532e518453461de1b088697474852))

# [@adobe/spacecat-shared-data-access-v2.1.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.0.6...@adobe/spacecat-shared-data-access-v2.1.0) (2025-02-06)


### Features

* add multiple missing audit types ([#575](https://github.com/adobe/spacecat-shared/issues/575)) ([48dcbee](https://github.com/adobe/spacecat-shared/commit/48dcbeed3eecf231e9da204121921d0c395b0401))

# [@adobe/spacecat-shared-data-access-v2.0.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.0.5...@adobe/spacecat-shared-data-access-v2.0.6) (2025-02-01)


### Bug Fixes

* **deps:** update external fixes ([#569](https://github.com/adobe/spacecat-shared/issues/569)) ([b266e8f](https://github.com/adobe/spacecat-shared/commit/b266e8ff57fd574818dc807e6114f708be624d41))

# [@adobe/spacecat-shared-data-access-v2.0.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.0.4...@adobe/spacecat-shared-data-access-v2.0.5) (2025-01-25)


### Bug Fixes

* **deps:** update external fixes ([#561](https://github.com/adobe/spacecat-shared/issues/561)) ([e922c1d](https://github.com/adobe/spacecat-shared/commit/e922c1df3b9a7bfcf6a5699d65bcb02dc130393a))

# [@adobe/spacecat-shared-data-access-v2.0.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.0.3...@adobe/spacecat-shared-data-access-v2.0.4) (2025-01-18)


### Bug Fixes

* **deps:** update external fixes ([#547](https://github.com/adobe/spacecat-shared/issues/547)) ([5a1a3bb](https://github.com/adobe/spacecat-shared/commit/5a1a3bbf0327dd8f66995629d8878db1f8050616))

# [@adobe/spacecat-shared-data-access-v2.0.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.0.2...@adobe/spacecat-shared-data-access-v2.0.3) (2025-01-16)


### Bug Fixes

* branch protection / npm cache / deps ([#545](https://github.com/adobe/spacecat-shared/issues/545)) ([004de60](https://github.com/adobe/spacecat-shared/commit/004de60b05b5039590f92ed8f7117725f6e4df41))

# [@adobe/spacecat-shared-data-access-v2.0.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.0.1...@adobe/spacecat-shared-data-access-v2.0.2) (2025-01-13)


### Bug Fixes

* patcher should use schema getter, schema omissions ([#539](https://github.com/adobe/spacecat-shared/issues/539)) ([b14b469](https://github.com/adobe/spacecat-shared/commit/b14b469d3714795c6291ddcf742c38abd94250e6))

# [@adobe/spacecat-shared-data-access-v2.0.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v2.0.0...@adobe/spacecat-shared-data-access-v2.0.1) (2025-01-12)


### Bug Fixes

* **deps:** update external fixes ([#538](https://github.com/adobe/spacecat-shared/issues/538)) ([a3bddf6](https://github.com/adobe/spacecat-shared/commit/a3bddf6cb2a9b60db8f8c3450e81205cd10c0b23))

# [@adobe/spacecat-shared-data-access-v2.0.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.19...@adobe/spacecat-shared-data-access-v2.0.0) (2025-01-10)


### Code Refactoring

* **data-access:** remove legacy data access ([#534](https://github.com/adobe/spacecat-shared/issues/534)) ([5d42c77](https://github.com/adobe/spacecat-shared/commit/5d42c77abfcd4e70284b438c5232dd9d74da03a7))


### BREAKING CHANGES

* **data-access:** the V1 data-access API has been removed

# [@adobe/spacecat-shared-data-access-v1.61.19](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.18...@adobe/spacecat-shared-data-access-v1.61.19) (2025-01-10)


### Bug Fixes

* dependent remove errors, more tests ([#532](https://github.com/adobe/spacecat-shared/issues/532)) ([cdec563](https://github.com/adobe/spacecat-shared/commit/cdec563c881d088feeb5ed24514f528173eec59d))

# [@adobe/spacecat-shared-data-access-v1.61.18](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.17...@adobe/spacecat-shared-data-access-v1.61.18) (2025-01-08)


### Bug Fixes

* import top pages ([c68b563](https://github.com/adobe/spacecat-shared/commit/c68b563e45b3af5810a569ab52f317751b2df847))

# [@adobe/spacecat-shared-data-access-v1.61.17](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.16...@adobe/spacecat-shared-data-access-v1.61.17) (2025-01-07)


### Bug Fixes

* update latest audit and allByIndexQuery ([#528](https://github.com/adobe/spacecat-shared/issues/528)) ([ff2c5c9](https://github.com/adobe/spacecat-shared/commit/ff2c5c9bfeae1d38c505653818184e5a040bb09c))

# [@adobe/spacecat-shared-data-access-v1.61.16](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.15...@adobe/spacecat-shared-data-access-v1.61.16) (2025-01-06)


### Bug Fixes

* **deps:** update external fixes ([#524](https://github.com/adobe/spacecat-shared/issues/524)) ([ae50dad](https://github.com/adobe/spacecat-shared/commit/ae50dad8e6e31f53350fc411122a8aed0b715279))

# [@adobe/spacecat-shared-data-access-v1.61.15](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.14...@adobe/spacecat-shared-data-access-v1.61.15) (2025-01-06)


### Bug Fixes

* key-event schema, fixture, test ([#525](https://github.com/adobe/spacecat-shared/issues/525)) ([365870e](https://github.com/adobe/spacecat-shared/commit/365870e5f870fbbc47369982e484d6235fd1fd68))

# [@adobe/spacecat-shared-data-access-v1.61.14](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.13...@adobe/spacecat-shared-data-access-v1.61.14) (2025-01-03)


### Bug Fixes

* latest audit result to validate array ([#523](https://github.com/adobe/spacecat-shared/issues/523)) ([3450c18](https://github.com/adobe/spacecat-shared/commit/3450c184b2ca2b52ebfa437e5dd23ba6d540b3b5))

# [@adobe/spacecat-shared-data-access-v1.61.13](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.12...@adobe/spacecat-shared-data-access-v1.61.13) (2025-01-03)


### Bug Fixes

* audit result to validate array ([#522](https://github.com/adobe/spacecat-shared/issues/522)) ([a6978d5](https://github.com/adobe/spacecat-shared/commit/a6978d54c52e668ea2336e68c9dcb000ba1a45a3))

# [@adobe/spacecat-shared-data-access-v1.61.12](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.11...@adobe/spacecat-shared-data-access-v1.61.12) (2024-12-31)


### Bug Fixes

* calling all wrong args ([#520](https://github.com/adobe/spacecat-shared/issues/520)) ([b727e50](https://github.com/adobe/spacecat-shared/commit/b727e50e8375c8b6a33bac101d0a2ecaf8fc8b7e))

# [@adobe/spacecat-shared-data-access-v1.61.11](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.10...@adobe/spacecat-shared-data-access-v1.61.11) (2024-12-31)


### Bug Fixes

* org config access ([#518](https://github.com/adobe/spacecat-shared/issues/518)) ([8ef162d](https://github.com/adobe/spacecat-shared/commit/8ef162d85a2086d9029010b4e93b20404d39c38c))

# [@adobe/spacecat-shared-data-access-v1.61.10](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.9...@adobe/spacecat-shared-data-access-v1.61.10) (2024-12-31)


### Bug Fixes

* get org config ([#517](https://github.com/adobe/spacecat-shared/issues/517)) ([2878f31](https://github.com/adobe/spacecat-shared/commit/2878f31ad502272c645d634fe0796e43ee001cde))

# [@adobe/spacecat-shared-data-access-v1.61.9](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.8...@adobe/spacecat-shared-data-access-v1.61.9) (2024-12-31)


### Bug Fixes

* return proper config object ([#516](https://github.com/adobe/spacecat-shared/issues/516)) ([84a393a](https://github.com/adobe/spacecat-shared/commit/84a393ac636f287089f4862365fe9305381c9afd))

# [@adobe/spacecat-shared-data-access-v1.61.8](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.7...@adobe/spacecat-shared-data-access-v1.61.8) (2024-12-31)


### Bug Fixes

* logging ([#515](https://github.com/adobe/spacecat-shared/issues/515)) ([a0010ea](https://github.com/adobe/spacecat-shared/commit/a0010eae6ff87b04c065568c1af135736cfdbcfd))

# [@adobe/spacecat-shared-data-access-v1.61.7](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.6...@adobe/spacecat-shared-data-access-v1.61.7) (2024-12-31)


### Bug Fixes

* job groups & schedules, engine version ([#514](https://github.com/adobe/spacecat-shared/issues/514)) ([995f81e](https://github.com/adobe/spacecat-shared/commit/995f81eedb76d45a09cfd2ae3952f3676033a235))

# [@adobe/spacecat-shared-data-access-v1.61.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.5...@adobe/spacecat-shared-data-access-v1.61.6) (2024-12-30)


### Bug Fixes

* isNonEmptyArray from utils ([#512](https://github.com/adobe/spacecat-shared/issues/512)) ([21b87ed](https://github.com/adobe/spacecat-shared/commit/21b87edc507f20285355becd5d51a9b7010e9651))

# [@adobe/spacecat-shared-data-access-v1.61.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.4...@adobe/spacecat-shared-data-access-v1.61.5) (2024-12-30)


### Bug Fixes

* replace expiresAt with recordExporesAt in ImportUrl ([#511](https://github.com/adobe/spacecat-shared/issues/511)) ([7349c9c](https://github.com/adobe/spacecat-shared/commit/7349c9c66659fae4b62edb27e2e03a83a0af2e13))

# [@adobe/spacecat-shared-data-access-v1.61.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.3...@adobe/spacecat-shared-data-access-v1.61.4) (2024-12-30)


### Bug Fixes

* types & deps ([#510](https://github.com/adobe/spacecat-shared/issues/510)) ([d162c1d](https://github.com/adobe/spacecat-shared/commit/d162c1d75a2052fc07da844923762e9397016b90))

# [@adobe/spacecat-shared-data-access-v1.61.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.2...@adobe/spacecat-shared-data-access-v1.61.3) (2024-12-28)


### Bug Fixes

* cache key ([#507](https://github.com/adobe/spacecat-shared/issues/507)) ([7146bfd](https://github.com/adobe/spacecat-shared/commit/7146bfd908e1bc13076bd58b3c24ca89b7f4c531))

# [@adobe/spacecat-shared-data-access-v1.61.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.1...@adobe/spacecat-shared-data-access-v1.61.2) (2024-12-27)


### Bug Fixes

* various missing ([#506](https://github.com/adobe/spacecat-shared/issues/506)) ([8fc72f0](https://github.com/adobe/spacecat-shared/commit/8fc72f0545eb17fb9ccdf0caa35872734f518883))

# [@adobe/spacecat-shared-data-access-v1.61.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.61.0...@adobe/spacecat-shared-data-access-v1.61.1) (2024-12-24)


### Bug Fixes

* schema and db init ([#505](https://github.com/adobe/spacecat-shared/issues/505)) ([9b67b9a](https://github.com/adobe/spacecat-shared/commit/9b67b9a9f40f643c648cc5043018bfbc1d2a9c12))

# [@adobe/spacecat-shared-data-access-v1.61.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.60.3...@adobe/spacecat-shared-data-access-v1.61.0) (2024-12-23)


### Features

* latest audit entity ([#503](https://github.com/adobe/spacecat-shared/issues/503)) ([2d01b09](https://github.com/adobe/spacecat-shared/commit/2d01b0969c0c046cdbffa480f8e40991e5abf91e))

# [@adobe/spacecat-shared-data-access-v1.60.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.60.2...@adobe/spacecat-shared-data-access-v1.60.3) (2024-12-22)


### Bug Fixes

* **deps:** update external fixes ([#502](https://github.com/adobe/spacecat-shared/issues/502)) ([6ea4ef2](https://github.com/adobe/spacecat-shared/commit/6ea4ef2889ac665160adc9ebdad38b41b67d0782))

# [@adobe/spacecat-shared-data-access-v1.60.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.60.1...@adobe/spacecat-shared-data-access-v1.60.2) (2024-12-19)


### Bug Fixes

* reduce number of indexes ([#499](https://github.com/adobe/spacecat-shared/issues/499)) ([95601cc](https://github.com/adobe/spacecat-shared/commit/95601cca8ca37f989a650fa841e0dae678cebc25))

# [@adobe/spacecat-shared-data-access-v1.60.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.60.0...@adobe/spacecat-shared-data-access-v1.60.1) (2024-12-18)


### Bug Fixes

* removeElectroProperties ([#498](https://github.com/adobe/spacecat-shared/issues/498)) ([a21b188](https://github.com/adobe/spacecat-shared/commit/a21b1887d6872092679f9c5d02452e79711955e7))

# [@adobe/spacecat-shared-data-access-v1.60.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.59.2...@adobe/spacecat-shared-data-access-v1.60.0) (2024-12-18)


### Features

* migrate entities to electrodb ([#484](https://github.com/adobe/spacecat-shared/issues/484)) ([e9a6310](https://github.com/adobe/spacecat-shared/commit/e9a6310dbdea4d44562432b794aa1e287ba9428d))

# [@adobe/spacecat-shared-data-access-v1.59.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.59.1...@adobe/spacecat-shared-data-access-v1.59.2) (2024-12-14)


### Bug Fixes

* **deps:** update external fixes ([#492](https://github.com/adobe/spacecat-shared/issues/492)) ([d4daba5](https://github.com/adobe/spacecat-shared/commit/d4daba5686c856f9f0029d805fb2b9f1b9baf777))

# [@adobe/spacecat-shared-data-access-v1.59.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.59.0...@adobe/spacecat-shared-data-access-v1.59.1) (2024-12-12)


### Bug Fixes

* **data-access:** get all site candidates table name ([#487](https://github.com/adobe/spacecat-shared/issues/487)) ([5d62aee](https://github.com/adobe/spacecat-shared/commit/5d62aee7e29a1f78f692ea6802ac1334e884b9a3))

# [@adobe/spacecat-shared-data-access-v1.59.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.58.2...@adobe/spacecat-shared-data-access-v1.59.0) (2024-12-11)


### Features

* **data-access:** get site candidates ([#486](https://github.com/adobe/spacecat-shared/issues/486)) ([f45032d](https://github.com/adobe/spacecat-shared/commit/f45032dbcd3ea1e8cdfc2066f523b4a1690b5da4))

# [@adobe/spacecat-shared-data-access-v1.58.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.58.1...@adobe/spacecat-shared-data-access-v1.58.2) (2024-12-07)


### Bug Fixes

* **deps:** update external fixes ([#477](https://github.com/adobe/spacecat-shared/issues/477)) ([53d5c13](https://github.com/adobe/spacecat-shared/commit/53d5c13cd4e14a37b3778518a106f06fef6b90ac))

# [@adobe/spacecat-shared-data-access-v1.58.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.58.0...@adobe/spacecat-shared-data-access-v1.58.1) (2024-11-30)


### Bug Fixes

* **deps:** update external fixes ([#465](https://github.com/adobe/spacecat-shared/issues/465)) ([d8ebb23](https://github.com/adobe/spacecat-shared/commit/d8ebb23fbd3d292479a4118dc6a9fb9931a31694))

# [@adobe/spacecat-shared-data-access-v1.58.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.57.2...@adobe/spacecat-shared-data-access-v1.58.0) (2024-11-26)


### Features

* auto references & attribute set/get ([#461](https://github.com/adobe/spacecat-shared/issues/461)) ([2c29683](https://github.com/adobe/spacecat-shared/commit/2c296835bb7e71f2984e5537eab1dfc25bcc6141))

# [@adobe/spacecat-shared-data-access-v1.57.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.57.1...@adobe/spacecat-shared-data-access-v1.57.2) (2024-11-23)


### Bug Fixes

* **deps:** update external fixes ([#454](https://github.com/adobe/spacecat-shared/issues/454)) ([325cf8d](https://github.com/adobe/spacecat-shared/commit/325cf8dded5fcabadaf7d8fdd510d33aeafd08a7))

# [@adobe/spacecat-shared-data-access-v1.57.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.57.0...@adobe/spacecat-shared-data-access-v1.57.1) (2024-11-22)


### Bug Fixes

* multi status create result type ([#453](https://github.com/adobe/spacecat-shared/issues/453)) ([c8df70b](https://github.com/adobe/spacecat-shared/commit/c8df70bb8606162fcb9cee16603b349ab55e1d09))

# [@adobe/spacecat-shared-data-access-v1.57.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.56.0...@adobe/spacecat-shared-data-access-v1.57.0) (2024-11-22)


### Features

* batch create/update items & open oppty type ([#450](https://github.com/adobe/spacecat-shared/issues/450)) ([642beaf](https://github.com/adobe/spacecat-shared/commit/642beaf3ab1ef9494f00c2148241d3986cca7fe7))

# [@adobe/spacecat-shared-data-access-v1.56.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.55.0...@adobe/spacecat-shared-data-access-v1.56.0) (2024-11-21)


### Features

* introduce missing audit id property ([#452](https://github.com/adobe/spacecat-shared/issues/452)) ([c17e447](https://github.com/adobe/spacecat-shared/commit/c17e447b275d9788d587dc44f3043fb60e83c51b))

# [@adobe/spacecat-shared-data-access-v1.55.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.54.0...@adobe/spacecat-shared-data-access-v1.55.0) (2024-11-20)


### Features

* Adding getEnabledSiteIdsForHandler in Configuration ([#449](https://github.com/adobe/spacecat-shared/issues/449)) ([ba3f3aa](https://github.com/adobe/spacecat-shared/commit/ba3f3aa3578551c39fc1115956967b74e824b659))

# [@adobe/spacecat-shared-data-access-v1.54.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.53.1...@adobe/spacecat-shared-data-access-v1.54.0) (2024-11-20)


### Features

* opportunity & suggestion model (+electrodb) ([#447](https://github.com/adobe/spacecat-shared/issues/447)) ([91cf931](https://github.com/adobe/spacecat-shared/commit/91cf931facbc7f13a6fe6eebe71f2948a4ec007e))

# [@adobe/spacecat-shared-data-access-v1.53.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.53.0...@adobe/spacecat-shared-data-access-v1.53.1) (2024-11-16)


### Bug Fixes

* **deps:** update external fixes ([#444](https://github.com/adobe/spacecat-shared/issues/444)) ([5e86c98](https://github.com/adobe/spacecat-shared/commit/5e86c98f274e514e8ec3032b52a128b7b394f5bc))

# [@adobe/spacecat-shared-data-access-v1.53.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.52.0...@adobe/spacecat-shared-data-access-v1.53.0) (2024-11-15)


### Features

* Introduce configurable grouping patterns ([#439](https://github.com/adobe/spacecat-shared/issues/439)) ([bd2ad3b](https://github.com/adobe/spacecat-shared/commit/bd2ad3b39379f66ccdb8e20bfd4ef013c6230f79))

# [@adobe/spacecat-shared-data-access-v1.52.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.51.0...@adobe/spacecat-shared-data-access-v1.52.0) (2024-11-13)


### Features

* SITES-26835 [Import Assistant] Introduce imports.assistant api key scope ([#438](https://github.com/adobe/spacecat-shared/issues/438)) ([0cb0d35](https://github.com/adobe/spacecat-shared/commit/0cb0d357b11be588ab1bc00ed71745cc6052a321))

# [@adobe/spacecat-shared-data-access-v1.51.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.50.1...@adobe/spacecat-shared-data-access-v1.51.0) (2024-11-12)


### Features

* enable internal workspace reporting ([2425c88](https://github.com/adobe/spacecat-shared/commit/2425c881b147272645ea29c0028ebe11878a5e26))

# [@adobe/spacecat-shared-data-access-v1.50.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.50.0...@adobe/spacecat-shared-data-access-v1.50.1) (2024-11-11)


### Bug Fixes

* **deps:** update external fixes ([#434](https://github.com/adobe/spacecat-shared/issues/434)) ([b71b615](https://github.com/adobe/spacecat-shared/commit/b71b61528513821f9e34c50a095d47cb4e14f8db))

# [@adobe/spacecat-shared-data-access-v1.50.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.49.8...@adobe/spacecat-shared-data-access-v1.50.0) (2024-11-08)


### Features

* support queries to generate self-service api-keys ([#428](https://github.com/adobe/spacecat-shared/issues/428)) ([90a46c2](https://github.com/adobe/spacecat-shared/commit/90a46c2f095e07d77636189c04f52ba31a626c7b))

# [@adobe/spacecat-shared-data-access-v1.49.8](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.49.7...@adobe/spacecat-shared-data-access-v1.49.8) (2024-11-08)


### Bug Fixes

* engine spec ([#433](https://github.com/adobe/spacecat-shared/issues/433)) ([19dd309](https://github.com/adobe/spacecat-shared/commit/19dd30956c0a9d35ea343c580e589205bfdbdfd8))

# [@adobe/spacecat-shared-data-access-v1.49.7](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.49.6...@adobe/spacecat-shared-data-access-v1.49.7) (2024-11-08)


### Bug Fixes

* engine spec ([#431](https://github.com/adobe/spacecat-shared/issues/431)) ([f19600e](https://github.com/adobe/spacecat-shared/commit/f19600e74ae7ee42a97c08d5b1c30db79c8ec13d))

# [@adobe/spacecat-shared-data-access-v1.49.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.49.5...@adobe/spacecat-shared-data-access-v1.49.6) (2024-11-07)


### Bug Fixes

* handle missing 'sites' and 'orgs' in enabled/disabled configuraions safely ([#424](https://github.com/adobe/spacecat-shared/issues/424)) ([5a1468f](https://github.com/adobe/spacecat-shared/commit/5a1468f92fb2b0b288cebb44576dea3f4948b462)), closes [/github.com/adobe/spacecat-shared/blob/main/packages/spacecat-shared-data-access/src/models/configuration.js#L39-L45](https://github.com//github.com/adobe/spacecat-shared/blob/main/packages/spacecat-shared-data-access/src/models/configuration.js/issues/L39-L45)

# [@adobe/spacecat-shared-data-access-v1.49.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.49.4...@adobe/spacecat-shared-data-access-v1.49.5) (2024-11-07)


### Bug Fixes

* set correct node engine spec ([#423](https://github.com/adobe/spacecat-shared/issues/423)) ([5086ce7](https://github.com/adobe/spacecat-shared/commit/5086ce7d41bebb502cadf092e5b9a7b84b5bf103))

# [@adobe/spacecat-shared-data-access-v1.49.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.49.3...@adobe/spacecat-shared-data-access-v1.49.4) (2024-11-02)


### Bug Fixes

* **deps:** update external fixes ([#419](https://github.com/adobe/spacecat-shared/issues/419)) ([6ee73f3](https://github.com/adobe/spacecat-shared/commit/6ee73f3aa944bda730276d7a06a588f39b52a56a))

# [@adobe/spacecat-shared-data-access-v1.49.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.49.2...@adobe/spacecat-shared-data-access-v1.49.3) (2024-10-29)


### Bug Fixes

* **deps:** update dependency uuid to v11 ([#416](https://github.com/adobe/spacecat-shared/issues/416)) ([35c9f4a](https://github.com/adobe/spacecat-shared/commit/35c9f4ab24e12800e3227f59533fc8c06e71a705))

# [@adobe/spacecat-shared-data-access-v1.49.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.49.1...@adobe/spacecat-shared-data-access-v1.49.2) (2024-10-29)


### Bug Fixes

* configuration version should have numeric type ([e9b9dfc](https://github.com/adobe/spacecat-shared/commit/e9b9dfc6e35f9c1c383ec3941834b18a3179a237))

# [@adobe/spacecat-shared-data-access-v1.49.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.49.0...@adobe/spacecat-shared-data-access-v1.49.1) (2024-10-26)


### Bug Fixes

* **deps:** update external fixes ([#413](https://github.com/adobe/spacecat-shared/issues/413)) ([ee2c715](https://github.com/adobe/spacecat-shared/commit/ee2c715e08034bea8fb88b4f7166d40b18e107c4))

# [@adobe/spacecat-shared-data-access-v1.49.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.48.3...@adobe/spacecat-shared-data-access-v1.49.0) (2024-10-23)


### Features

* Support cancelling / stopping a running job ([#410](https://github.com/adobe/spacecat-shared/issues/410)) ([68fdee4](https://github.com/adobe/spacecat-shared/commit/68fdee4db65fe87c75b925eda804ac8cb97c02af))

# [@adobe/spacecat-shared-data-access-v1.48.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.48.2...@adobe/spacecat-shared-data-access-v1.48.3) (2024-10-21)


### Bug Fixes

* update deps ([#408](https://github.com/adobe/spacecat-shared/issues/408)) ([b1f8283](https://github.com/adobe/spacecat-shared/commit/b1f8283f658e22a69d69f4379de306cfd73133d1))

# [@adobe/spacecat-shared-data-access-v1.48.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.48.1...@adobe/spacecat-shared-data-access-v1.48.2) (2024-10-19)


### Bug Fixes

* **deps:** update external fixes ([#405](https://github.com/adobe/spacecat-shared/issues/405)) ([11072b4](https://github.com/adobe/spacecat-shared/commit/11072b4289db7e18328ed8faff4651fb95a1370d))

# [@adobe/spacecat-shared-data-access-v1.48.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.48.0...@adobe/spacecat-shared-data-access-v1.48.1) (2024-10-12)


### Bug Fixes

* **deps:** update external fixes ([#402](https://github.com/adobe/spacecat-shared/issues/402)) ([9a5acba](https://github.com/adobe/spacecat-shared/commit/9a5acba2773b83ce26f4ac97e04d8ad24b00d8ce))

# [@adobe/spacecat-shared-data-access-v1.48.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.47.1...@adobe/spacecat-shared-data-access-v1.48.0) (2024-10-11)


### Features

* Support import job deletion ([#400](https://github.com/adobe/spacecat-shared/issues/400)) ([d5a9df6](https://github.com/adobe/spacecat-shared/commit/d5a9df68f103b34adab87dfc78cc5bca7aa99ebc))

# [@adobe/spacecat-shared-data-access-v1.47.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.47.0...@adobe/spacecat-shared-data-access-v1.47.1) (2024-10-07)


### Bug Fixes

* gracefully handle config in case handler is not defined ([#396](https://github.com/adobe/spacecat-shared/issues/396)) ([a4c8abd](https://github.com/adobe/spacecat-shared/commit/a4c8abdf4c99cfc32b1d92233eb8786f439320f1))

# [@adobe/spacecat-shared-data-access-v1.47.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.46.1...@adobe/spacecat-shared-data-access-v1.47.0) (2024-10-07)


### Features

* added `slackRoles` access methods to configuration and model ([#393](https://github.com/adobe/spacecat-shared/issues/393)) ([269b911](https://github.com/adobe/spacecat-shared/commit/269b91158ed2977379aee2c53a06db3821b131f5))

# [@adobe/spacecat-shared-data-access-v1.46.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.46.0...@adobe/spacecat-shared-data-access-v1.46.1) (2024-10-05)


### Bug Fixes

* **deps:** update external fixes ([#394](https://github.com/adobe/spacecat-shared/issues/394)) ([ad165f5](https://github.com/adobe/spacecat-shared/commit/ad165f5fcf9c0ab17d2e901e7a5c0ed3c39dcb51))

# [@adobe/spacecat-shared-data-access-v1.46.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.45.6...@adobe/spacecat-shared-data-access-v1.46.0) (2024-10-02)


### Features

* Expire Import URLs automatically after set period of time ([#392](https://github.com/adobe/spacecat-shared/issues/392)) ([294fd9e](https://github.com/adobe/spacecat-shared/commit/294fd9ec112b99a66e7025bed9219fed280eb128))

# [@adobe/spacecat-shared-data-access-v1.45.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.45.5...@adobe/spacecat-shared-data-access-v1.45.6) (2024-10-02)


### Bug Fixes

* content client should use the hlxConfig ([8e74827](https://github.com/adobe/spacecat-shared/commit/8e74827613421828eaef29cf1372d329433526cc))

# [@adobe/spacecat-shared-data-access-v1.45.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.45.4...@adobe/spacecat-shared-data-access-v1.45.5) (2024-09-30)


### Bug Fixes

* config and content client fixes ([9650742](https://github.com/adobe/spacecat-shared/commit/965074276cc93b8a6e9e382602670ae8a709d9bb))

# [@adobe/spacecat-shared-data-access-v1.45.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.45.3...@adobe/spacecat-shared-data-access-v1.45.4) (2024-09-28)


### Bug Fixes

* **deps:** update external fixes ([#387](https://github.com/adobe/spacecat-shared/issues/387)) ([5f301fb](https://github.com/adobe/spacecat-shared/commit/5f301fb7bfee78ab57c966ebc3559bc148744933))

# [@adobe/spacecat-shared-data-access-v1.45.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.45.2...@adobe/spacecat-shared-data-access-v1.45.3) (2024-09-26)


### Bug Fixes

* Modify the scope name to imports.all_domains ([#385](https://github.com/adobe/spacecat-shared/issues/385)) ([3462257](https://github.com/adobe/spacecat-shared/commit/34622579fec6e7fd8f49e1836b63576f0983a564))

# [@adobe/spacecat-shared-data-access-v1.45.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.45.1...@adobe/spacecat-shared-data-access-v1.45.2) (2024-09-25)


### Bug Fixes

* Add a unit test for imports.write_all_domains scope ([#384](https://github.com/adobe/spacecat-shared/issues/384)) ([800ec89](https://github.com/adobe/spacecat-shared/commit/800ec89532cc83f32290ced2b91f1af4fcccb44a))

# [@adobe/spacecat-shared-data-access-v1.45.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.45.0...@adobe/spacecat-shared-data-access-v1.45.1) (2024-09-24)


### Bug Fixes

* SITES-25634 [Importer] Expose hasCustomImportJs and hasCustomHeaders as two new fields on a import job ([#381](https://github.com/adobe/spacecat-shared/issues/381)) ([b90a7c5](https://github.com/adobe/spacecat-shared/commit/b90a7c5623af90924a2122dbc10077f989a8550b))

# [@adobe/spacecat-shared-data-access-v1.45.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.44.5...@adobe/spacecat-shared-data-access-v1.45.0) (2024-09-24)


### Features

* Add an additional scope to all imports on all domains ([#383](https://github.com/adobe/spacecat-shared/issues/383)) ([92ad32c](https://github.com/adobe/spacecat-shared/commit/92ad32c892b151082b1ac6b67b29f6307dbeba15))

# [@adobe/spacecat-shared-data-access-v1.44.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.44.4...@adobe/spacecat-shared-data-access-v1.44.5) (2024-09-23)


### Bug Fixes

* [Importer] Specify the list of supported features ([#362](https://github.com/adobe/spacecat-shared/issues/362)) ([c1cf7e1](https://github.com/adobe/spacecat-shared/commit/c1cf7e19b7a4bfe78a03a1996bb6d6c8667dd823))

# [@adobe/spacecat-shared-data-access-v1.44.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.44.3...@adobe/spacecat-shared-data-access-v1.44.4) (2024-09-21)


### Bug Fixes

* **deps:** update external fixes ([#378](https://github.com/adobe/spacecat-shared/issues/378)) ([273a70d](https://github.com/adobe/spacecat-shared/commit/273a70d6b6e862a266628185254e1e99bcaae219))

# [@adobe/spacecat-shared-data-access-v1.44.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.44.2...@adobe/spacecat-shared-data-access-v1.44.3) (2024-09-19)


### Bug Fixes

* add an additional space in the unit test ([#376](https://github.com/adobe/spacecat-shared/issues/376)) ([c98ae55](https://github.com/adobe/spacecat-shared/commit/c98ae55433970663bc5d50a9546d1fbc9d4bf8d7))

# [@adobe/spacecat-shared-data-access-v1.44.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.44.1...@adobe/spacecat-shared-data-access-v1.44.2) (2024-09-16)


### Bug Fixes

* **audits:** extend expiry date for audits from 1 to 6 months ([#363](https://github.com/adobe/spacecat-shared/issues/363)) ([1327a5b](https://github.com/adobe/spacecat-shared/commit/1327a5bcc60fdb7dab0284e9d10d3001ad7fa403))

# [@adobe/spacecat-shared-data-access-v1.44.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.44.0...@adobe/spacecat-shared-data-access-v1.44.1) (2024-09-14)


### Bug Fixes

* **deps:** update external fixes ([#369](https://github.com/adobe/spacecat-shared/issues/369)) ([5412d7b](https://github.com/adobe/spacecat-shared/commit/5412d7be554b9940d43b39b18f2913146e866846))

# [@adobe/spacecat-shared-data-access-v1.44.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.43.4...@adobe/spacecat-shared-data-access-v1.44.0) (2024-09-11)


### Features

* Add a query to get all import urls by jobId ([#365](https://github.com/adobe/spacecat-shared/issues/365)) ([17b216d](https://github.com/adobe/spacecat-shared/commit/17b216d75f3573480e257c36101b0388dc1772be)), closes [/github.com/adobe/spacecat-content-processor/pull/143#discussion_r1754542157](https://github.com//github.com/adobe/spacecat-content-processor/pull/143/issues/discussion_r1754542157)

# [@adobe/spacecat-shared-data-access-v1.43.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.43.3...@adobe/spacecat-shared-data-access-v1.43.4) (2024-09-07)


### Bug Fixes

* **deps:** update external fixes ([#360](https://github.com/adobe/spacecat-shared/issues/360)) ([315f6e4](https://github.com/adobe/spacecat-shared/commit/315f6e42798d78d33f435e67f70e9a35d05ecf2b))

# [@adobe/spacecat-shared-data-access-v1.43.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.43.2...@adobe/spacecat-shared-data-access-v1.43.3) (2024-08-24)


### Bug Fixes

* **deps:** update external fixes ([#345](https://github.com/adobe/spacecat-shared/issues/345)) ([ae2c7a6](https://github.com/adobe/spacecat-shared/commit/ae2c7a6104394a53d74f5c19465d6741751576ce))

# [@adobe/spacecat-shared-data-access-v1.43.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.43.1...@adobe/spacecat-shared-data-access-v1.43.2) (2024-08-22)


### Bug Fixes

* add property to include specific urls in the site config ([#343](https://github.com/adobe/spacecat-shared/issues/343)) ([184107a](https://github.com/adobe/spacecat-shared/commit/184107a5329a89653e6ec55cfbb9e4c86f1eea55))

# [@adobe/spacecat-shared-data-access-v1.43.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.43.0...@adobe/spacecat-shared-data-access-v1.43.1) (2024-08-22)


### Bug Fixes

* add Scoped API Key docs ([#342](https://github.com/adobe/spacecat-shared/issues/342)) ([2fbf707](https://github.com/adobe/spacecat-shared/commit/2fbf707dfeff914dc47ae1f9860629873927e03e))

# [@adobe/spacecat-shared-data-access-v1.43.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.42.0...@adobe/spacecat-shared-data-access-v1.43.0) (2024-08-21)


### Features

* add initiatedBy attribute to import job ([#341](https://github.com/adobe/spacecat-shared/issues/341)) ([8a7634c](https://github.com/adobe/spacecat-shared/commit/8a7634c68cf0df01a71abc5d99a17519869f3c45))

# [@adobe/spacecat-shared-data-access-v1.42.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.41.8...@adobe/spacecat-shared-data-access-v1.42.0) (2024-08-20)


### Features

* introduce url inspect in google client ([#326](https://github.com/adobe/spacecat-shared/issues/326)) ([eb9e8ae](https://github.com/adobe/spacecat-shared/commit/eb9e8ae67f7a95ca5e4abb993f8b625400735312))

# [@adobe/spacecat-shared-data-access-v1.41.8](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.41.7...@adobe/spacecat-shared-data-access-v1.41.8) (2024-08-20)


### Bug Fixes

* add only unique site/org ids in enabled/disabled for a handler ([#322](https://github.com/adobe/spacecat-shared/issues/322)) ([abb01c9](https://github.com/adobe/spacecat-shared/commit/abb01c914f1d77d2adf06c0de80c977945d597bb))

# [@adobe/spacecat-shared-data-access-v1.41.7](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.41.6...@adobe/spacecat-shared-data-access-v1.41.7) (2024-08-20)


### Bug Fixes

* move metrics-store and s3 in shared utils ([#327](https://github.com/adobe/spacecat-shared/issues/327)) ([bff367c](https://github.com/adobe/spacecat-shared/commit/bff367cf05f9b7d802a7b8c24bc81abbf0e2665c))

# [@adobe/spacecat-shared-data-access-v1.41.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.41.5...@adobe/spacecat-shared-data-access-v1.41.6) (2024-08-20)


### Bug Fixes

* experimentation IT tests failing intermittently ([#337](https://github.com/adobe/spacecat-shared/issues/337)) ([b6651d6](https://github.com/adobe/spacecat-shared/commit/b6651d60bdfe93ffb55f95018352ea3647432b0d))

# [@adobe/spacecat-shared-data-access-v1.41.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.41.4...@adobe/spacecat-shared-data-access-v1.41.5) (2024-08-19)


### Bug Fixes

* **deps:** update external fixes ([#332](https://github.com/adobe/spacecat-shared/issues/332)) ([b2bb2a4](https://github.com/adobe/spacecat-shared/commit/b2bb2a4dd1a0995c36cd2b64510b7c4e0e05436f))
* **tests:** temporarily disable flaky tests ([#335](https://github.com/adobe/spacecat-shared/issues/335)) ([40008c1](https://github.com/adobe/spacecat-shared/commit/40008c1a29be5bc7766ed71366c9b9262c9db8c2))

# [@adobe/spacecat-shared-data-access-v1.41.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.41.3...@adobe/spacecat-shared-data-access-v1.41.4) (2024-08-16)


### Bug Fixes

* Add id to api-key DTO ([#330](https://github.com/adobe/spacecat-shared/issues/330)) ([aa451ab](https://github.com/adobe/spacecat-shared/commit/aa451abf7b0178412803b553fe9a39f47e958c02))

# [@adobe/spacecat-shared-data-access-v1.41.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.41.2...@adobe/spacecat-shared-data-access-v1.41.3) (2024-08-15)


### Bug Fixes

* refactor hashed api key and query to retrieve API key ([#325](https://github.com/adobe/spacecat-shared/issues/325)) ([a99fc76](https://github.com/adobe/spacecat-shared/commit/a99fc76963fdcd6bce8de7d5b315dbefbb03fd95))

# [@adobe/spacecat-shared-data-access-v1.41.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.41.1...@adobe/spacecat-shared-data-access-v1.41.2) (2024-08-14)


### Bug Fixes

* add query changes ([#324](https://github.com/adobe/spacecat-shared/issues/324)) ([6104f65](https://github.com/adobe/spacecat-shared/commit/6104f65620f8f020e70494c2c2138ae2afefe15e))

# [@adobe/spacecat-shared-data-access-v1.41.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.41.0...@adobe/spacecat-shared-data-access-v1.41.1) (2024-08-14)


### Bug Fixes

* **deps:** update external fixes ([#320](https://github.com/adobe/spacecat-shared/issues/320)) ([c75b743](https://github.com/adobe/spacecat-shared/commit/c75b7432e0add9b261ddc7999fe80b20442a0dd7))

# [@adobe/spacecat-shared-data-access-v1.41.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.40.0...@adobe/spacecat-shared-data-access-v1.41.0) (2024-08-09)


### Features

* Introduce scoped API keys ([#312](https://github.com/adobe/spacecat-shared/issues/312)) ([449d273](https://github.com/adobe/spacecat-shared/commit/449d2736154d7e92fb4a3d1f9f290e15e665aa5e))

# [@adobe/spacecat-shared-data-access-v1.40.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.39.1...@adobe/spacecat-shared-data-access-v1.40.0) (2024-08-08)


### Features

* update import job models to include hashed key ([#318](https://github.com/adobe/spacecat-shared/issues/318)) ([cd90252](https://github.com/adobe/spacecat-shared/commit/cd902522629d13e2707b7a78a38bdffc5d6194c0))

# [@adobe/spacecat-shared-data-access-v1.39.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.39.0...@adobe/spacecat-shared-data-access-v1.39.1) (2024-08-06)


### Bug Fixes

* **deps:** update external fixes ([#314](https://github.com/adobe/spacecat-shared/issues/314)) ([cc47ba3](https://github.com/adobe/spacecat-shared/commit/cc47ba34b7f3e859deea89da57bfa4887e788772))

# [@adobe/spacecat-shared-data-access-v1.39.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.38.2...@adobe/spacecat-shared-data-access-v1.39.0) (2024-07-31)


### Features

* Add API Key data attributes ([#306](https://github.com/adobe/spacecat-shared/issues/306)) ([37ddf55](https://github.com/adobe/spacecat-shared/commit/37ddf55f73acb9e6848dbe6a9292496a15d77ff0))

# [@adobe/spacecat-shared-data-access-v1.38.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.38.1...@adobe/spacecat-shared-data-access-v1.38.2) (2024-07-27)


### Bug Fixes

* **deps:** update external fixes ([#304](https://github.com/adobe/spacecat-shared/issues/304)) ([c6c56a7](https://github.com/adobe/spacecat-shared/commit/c6c56a72897acb60fb042215b708816ec16a5870))

# [@adobe/spacecat-shared-data-access-v1.38.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.38.0...@adobe/spacecat-shared-data-access-v1.38.1) (2024-07-24)


### Bug Fixes

* naming issues ([#300](https://github.com/adobe/spacecat-shared/issues/300)) ([f0a7468](https://github.com/adobe/spacecat-shared/commit/f0a7468526a5f71c4bfed5ec0b88c3c889316cd6))

# [@adobe/spacecat-shared-data-access-v1.38.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.37.0...@adobe/spacecat-shared-data-access-v1.38.0) (2024-07-23)


### Features

* Experimentation entity ([#288](https://github.com/adobe/spacecat-shared/issues/288)) ([774e2c7](https://github.com/adobe/spacecat-shared/commit/774e2c7013c9e617c745c494e20e1cdd8cce71e7))

# [@adobe/spacecat-shared-data-access-v1.37.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.36.0...@adobe/spacecat-shared-data-access-v1.37.0) (2024-07-22)


### Bug Fixes

* **deps:** update external fixes ([#295](https://github.com/adobe/spacecat-shared/issues/295)) ([4e8d50d](https://github.com/adobe/spacecat-shared/commit/4e8d50d8d88b2d68b483fda2ead31542d15ee952))


### Features

* new config data model ([2525af4](https://github.com/adobe/spacecat-shared/commit/2525af48d1d4dad7e1b6e1fb3fbf3cda79d1252d))
* update the config model for sites and orgs ([ed556bd](https://github.com/adobe/spacecat-shared/commit/ed556bda995d8cb6b79cb44efbee7d0b779dc0aa))
* update to trigger release ([b1610ab](https://github.com/adobe/spacecat-shared/commit/b1610ab8160a75348803b470deaa8c28d2baf6f1))

# [@adobe/spacecat-shared-data-access-v1.36.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.35.2...@adobe/spacecat-shared-data-access-v1.36.0) (2024-07-16)


### Features

* Get all import jobs by date range ([#292](https://github.com/adobe/spacecat-shared/issues/292)) ([21accd3](https://github.com/adobe/spacecat-shared/commit/21accd34a543af3ab39aacaa0545f84c7bb50f3b))

# [@adobe/spacecat-shared-data-access-v1.35.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.35.1...@adobe/spacecat-shared-data-access-v1.35.2) (2024-07-13)


### Bug Fixes

* **deps:** update external fixes ([#291](https://github.com/adobe/spacecat-shared/issues/291)) ([5678328](https://github.com/adobe/spacecat-shared/commit/5678328a8efe4c2068b3b796274d8e4392f75c8a))

# [@adobe/spacecat-shared-data-access-v1.35.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.35.0...@adobe/spacecat-shared-data-access-v1.35.1) (2024-07-12)


### Bug Fixes

* Fix the getFailedCount function in importJob interface ([#290](https://github.com/adobe/spacecat-shared/issues/290)) ([db4d0cc](https://github.com/adobe/spacecat-shared/commit/db4d0cc754d77d6a32780c48ca45e4b86712bb01)), closes [/github.com/adobe/spacecat-shared/blob/main/packages/spacecat-shared-data-access/src/dto/import-job.js#L39](https://github.com//github.com/adobe/spacecat-shared/blob/main/packages/spacecat-shared-data-access/src/dto/import-job.js/issues/L39)

# [@adobe/spacecat-shared-data-access-v1.35.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.34.2...@adobe/spacecat-shared-data-access-v1.35.0) (2024-07-11)


### Features

* Add urlCount attribute to import-jobs data model ([#287](https://github.com/adobe/spacecat-shared/issues/287)) ([4fecc4c](https://github.com/adobe/spacecat-shared/commit/4fecc4cb5f31fa0a62cf22ff0ae9e98d4c12b399))

# [@adobe/spacecat-shared-data-access-v1.34.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.34.1...@adobe/spacecat-shared-data-access-v1.34.2) (2024-07-08)


### Bug Fixes

* **deps:** update external fixes ([#284](https://github.com/adobe/spacecat-shared/issues/284)) ([f4fe169](https://github.com/adobe/spacecat-shared/commit/f4fe1699c432637f1217198ad7f4a1cde6deeb76))

# [@adobe/spacecat-shared-data-access-v1.34.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.34.0...@adobe/spacecat-shared-data-access-v1.34.1) (2024-06-29)


### Bug Fixes

* **deps:** update external fixes ([#279](https://github.com/adobe/spacecat-shared/issues/279)) ([4710607](https://github.com/adobe/spacecat-shared/commit/471060797fac55649ff0c0ea24129bdd421d46b2))

# [@adobe/spacecat-shared-data-access-v1.34.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.33.1...@adobe/spacecat-shared-data-access-v1.34.0) (2024-06-28)


### Features

* add helix config to site/candidates ([#277](https://github.com/adobe/spacecat-shared/issues/277)) ([5ed489d](https://github.com/adobe/spacecat-shared/commit/5ed489dc84cb594689092e1f0019dd83d3647039))

# [@adobe/spacecat-shared-data-access-v1.33.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.33.0...@adobe/spacecat-shared-data-access-v1.33.1) (2024-06-27)


### Bug Fixes

* **deps:** update external fixes ([#274](https://github.com/adobe/spacecat-shared/issues/274)) ([6bed341](https://github.com/adobe/spacecat-shared/commit/6bed3412af558946575f9f6be6d313ff0511db40))

# [@adobe/spacecat-shared-data-access-v1.33.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.32.0...@adobe/spacecat-shared-data-access-v1.33.0) (2024-06-21)


### Bug Fixes

* getSitesByOrganizationID performance ([485818f](https://github.com/adobe/spacecat-shared/commit/485818f846c1ceb0e50b32f531bd2e438cee7614))


### Features

* introduce fixed URLs in audit type config ([#272](https://github.com/adobe/spacecat-shared/issues/272)) ([07858a9](https://github.com/adobe/spacecat-shared/commit/07858a95ce457f395fd2c4269d79b445f34de504))

# [@adobe/spacecat-shared-data-access-v1.32.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.31.0...@adobe/spacecat-shared-data-access-v1.32.0) (2024-06-20)


### Features

* **audit-configs:** ess audits disabled by default ([#271](https://github.com/adobe/spacecat-shared/issues/271)) ([de6f83d](https://github.com/adobe/spacecat-shared/commit/de6f83db75135820b236d55d7d2b477f29ca5e43))

# [@adobe/spacecat-shared-data-access-v1.31.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.30.0...@adobe/spacecat-shared-data-access-v1.31.0) (2024-06-20)


### Features

* overwrite broken-backlinks ([#270](https://github.com/adobe/spacecat-shared/issues/270)) ([62256f2](https://github.com/adobe/spacecat-shared/commit/62256f2f750a97ada3d6b624b0ec50865589f39f))

# [@adobe/spacecat-shared-data-access-v1.30.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.29.2...@adobe/spacecat-shared-data-access-v1.30.0) (2024-06-19)


### Features

* introduce organic keywords for ahrefs client and top keyword in top pages ([#257](https://github.com/adobe/spacecat-shared/issues/257)) ([371f1c4](https://github.com/adobe/spacecat-shared/commit/371f1c475870fd2aac833f925236237a8b25c026))

# [@adobe/spacecat-shared-data-access-v1.29.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.29.1...@adobe/spacecat-shared-data-access-v1.29.2) (2024-06-18)


### Bug Fixes

* [#268](https://github.com/adobe/spacecat-shared/issues/268) Import URL entities need a REDIRECT status, and additional properties for reporting ([#269](https://github.com/adobe/spacecat-shared/issues/269)) ([88bb491](https://github.com/adobe/spacecat-shared/commit/88bb49105a9b0a9cd297fe9667aff1df24bcee03))

# [@adobe/spacecat-shared-data-access-v1.29.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.29.0...@adobe/spacecat-shared-data-access-v1.29.1) (2024-06-15)


### Bug Fixes

* **deps:** update external fixes ([#266](https://github.com/adobe/spacecat-shared/issues/266)) ([a89ab83](https://github.com/adobe/spacecat-shared/commit/a89ab83e1c108c10044f6d098526bafed67b88b2))

# [@adobe/spacecat-shared-data-access-v1.29.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.28.0...@adobe/spacecat-shared-data-access-v1.29.0) (2024-06-13)


### Features

* opt-out brokenlinks ([#265](https://github.com/adobe/spacecat-shared/issues/265)) ([025158f](https://github.com/adobe/spacecat-shared/commit/025158f8549733ff2c45c67fc3d421a03dac66d7))

# [@adobe/spacecat-shared-data-access-v1.28.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.27.0...@adobe/spacecat-shared-data-access-v1.28.0) (2024-06-12)


### Features

* opt-out broken-backlinks ([#263](https://github.com/adobe/spacecat-shared/issues/263)) ([14402cb](https://github.com/adobe/spacecat-shared/commit/14402cbda51bf54b2928ca1d66afac00ca2444ed))

# [@adobe/spacecat-shared-data-access-v1.27.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.26.1...@adobe/spacecat-shared-data-access-v1.27.0) (2024-06-12)


### Features

* query for URLs for a given jobID matching status ([#262](https://github.com/adobe/spacecat-shared/issues/262)) ([a74b629](https://github.com/adobe/spacecat-shared/commit/a74b629b78b100c140515efd072807f628de4a2a))

# [@adobe/spacecat-shared-data-access-v1.26.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.26.0...@adobe/spacecat-shared-data-access-v1.26.1) (2024-06-10)


### Bug Fixes

* Add an ExpressionAttributeName to fix issues with reserved keywords ([#261](https://github.com/adobe/spacecat-shared/issues/261)) ([b528c65](https://github.com/adobe/spacecat-shared/commit/b528c659b5ae2f6b17db0146ca0f650d9426f332)), closes [#260](https://github.com/adobe/spacecat-shared/issues/260)

# [@adobe/spacecat-shared-data-access-v1.26.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.25.1...@adobe/spacecat-shared-data-access-v1.26.0) (2024-06-10)


### Features

* Add PENDING status for import URL entities ([#259](https://github.com/adobe/spacecat-shared/issues/259)) ([031194c](https://github.com/adobe/spacecat-shared/commit/031194cb91434ae66bc3870e63e29167ea94de8f)), closes [#258](https://github.com/adobe/spacecat-shared/issues/258)

# [@adobe/spacecat-shared-data-access-v1.25.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.25.0...@adobe/spacecat-shared-data-access-v1.25.1) (2024-06-08)


### Bug Fixes

* **deps:** update external fixes ([#256](https://github.com/adobe/spacecat-shared/issues/256)) ([f28b6b6](https://github.com/adobe/spacecat-shared/commit/f28b6b6f520a8dfb8e82a7302da1b8c5e6bc4390))

# [@adobe/spacecat-shared-data-access-v1.25.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.24.0...@adobe/spacecat-shared-data-access-v1.25.0) (2024-06-07)


### Features

* Add update queries for import-job and import-url entites ([#254](https://github.com/adobe/spacecat-shared/issues/254)) ([d1cba93](https://github.com/adobe/spacecat-shared/commit/d1cba93c2ce1073426dc8333142a8d8fd81017ea))

# [@adobe/spacecat-shared-data-access-v1.24.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.23.6...@adobe/spacecat-shared-data-access-v1.24.0) (2024-06-06)


### Features

* Add import-job.js and import-url.js to the data model layer ([#250](https://github.com/adobe/spacecat-shared/issues/250)) ([447a95e](https://github.com/adobe/spacecat-shared/commit/447a95e0c4fbb6afa630d9ba78c699974b9f5d5c))

# [@adobe/spacecat-shared-data-access-v1.23.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.23.5...@adobe/spacecat-shared-data-access-v1.23.6) (2024-06-01)


### Bug Fixes

* **deps:** update external fixes ([#248](https://github.com/adobe/spacecat-shared/issues/248)) ([edbe81d](https://github.com/adobe/spacecat-shared/commit/edbe81d2a32f4d9977cb9548ebe47bda5a457c6e))

# [@adobe/spacecat-shared-data-access-v1.23.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.23.4...@adobe/spacecat-shared-data-access-v1.23.5) (2024-05-25)


### Bug Fixes

* **deps:** update external fixes ([#241](https://github.com/adobe/spacecat-shared/issues/241)) ([85babb2](https://github.com/adobe/spacecat-shared/commit/85babb22b8663f79fe857dead6ecc3bf65674687))

# [@adobe/spacecat-shared-data-access-v1.23.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.23.3...@adobe/spacecat-shared-data-access-v1.23.4) (2024-05-23)


### Bug Fixes

* status change key event type ([#240](https://github.com/adobe/spacecat-shared/issues/240)) ([d32dd76](https://github.com/adobe/spacecat-shared/commit/d32dd7652a29c7a3f2e778c341e2770787bcb891))

# [@adobe/spacecat-shared-data-access-v1.23.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.23.2...@adobe/spacecat-shared-data-access-v1.23.3) (2024-05-18)


### Bug Fixes

* **deps:** update external fixes ([#233](https://github.com/adobe/spacecat-shared/issues/233)) ([85c1f50](https://github.com/adobe/spacecat-shared/commit/85c1f509c4ba860dffd62ffe3ac8adf2c76ecf9e))

# [@adobe/spacecat-shared-data-access-v1.23.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.23.1...@adobe/spacecat-shared-data-access-v1.23.2) (2024-05-11)


### Bug Fixes

* **deps:** update external fixes ([#228](https://github.com/adobe/spacecat-shared/issues/228)) ([ef2ab41](https://github.com/adobe/spacecat-shared/commit/ef2ab41a9175ec5ba8ec7e2830898e9db01fb2b6))

# [@adobe/spacecat-shared-data-access-v1.23.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.23.0...@adobe/spacecat-shared-data-access-v1.23.1) (2024-05-08)


### Bug Fixes

* **deps:** update external fixes ([#225](https://github.com/adobe/spacecat-shared/issues/225)) ([ffb3e3d](https://github.com/adobe/spacecat-shared/commit/ffb3e3d216dd05bafaa7ab26f83ae1c3f0c4d391))

# [@adobe/spacecat-shared-data-access-v1.23.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.22.1...@adobe/spacecat-shared-data-access-v1.23.0) (2024-05-03)


### Features

* key events data access layer ([#223](https://github.com/adobe/spacecat-shared/issues/223)) ([83228cc](https://github.com/adobe/spacecat-shared/commit/83228ccb3011868da54460b7fb2788e27ee33454))

# [@adobe/spacecat-shared-data-access-v1.22.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.22.0...@adobe/spacecat-shared-data-access-v1.22.1) (2024-04-30)


### Bug Fixes

* **deps:** update external fixes ([#221](https://github.com/adobe/spacecat-shared/issues/221)) ([13e72c3](https://github.com/adobe/spacecat-shared/commit/13e72c36433dd62058275475acb46a03bd307f91))

# [@adobe/spacecat-shared-data-access-v1.22.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.21.3...@adobe/spacecat-shared-data-access-v1.22.0) (2024-04-29)


### Features

* add site top pages data access (SITES-21274) ([#213](https://github.com/adobe/spacecat-shared/issues/213)) ([b892e7c](https://github.com/adobe/spacecat-shared/commit/b892e7cb056824a4f5917fa2cf8a89c7dd077f7f))

# [@adobe/spacecat-shared-data-access-v1.21.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.21.2...@adobe/spacecat-shared-data-access-v1.21.3) (2024-04-25)


### Bug Fixes

* **deps:** update external fixes ([#215](https://github.com/adobe/spacecat-shared/issues/215)) ([4227263](https://github.com/adobe/spacecat-shared/commit/4227263b6bc917982d361cd621c7001c4ee1fa56))

# [@adobe/spacecat-shared-data-access-v1.21.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.21.1...@adobe/spacecat-shared-data-access-v1.21.2) (2024-04-16)


### Bug Fixes

* **deps:** update external fixes ([#202](https://github.com/adobe/spacecat-shared/issues/202)) ([d5d20a8](https://github.com/adobe/spacecat-shared/commit/d5d20a8d606c7589fb794d6c6e3319541a3e6439))

# [@adobe/spacecat-shared-data-access-v1.21.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.21.0...@adobe/spacecat-shared-data-access-v1.21.1) (2024-04-01)


### Bug Fixes

* validate scores only needed ([#203](https://github.com/adobe/spacecat-shared/issues/203)) ([e2e4d14](https://github.com/adobe/spacecat-shared/commit/e2e4d14fa7d28bf2606b933c6c8f6f329c1ff33a))

# [@adobe/spacecat-shared-data-access-v1.21.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.20.5...@adobe/spacecat-shared-data-access-v1.21.0) (2024-03-25)


### Features

* Track number of users invited to Slack [#195](https://github.com/adobe/spacecat-shared/issues/195) ([#196](https://github.com/adobe/spacecat-shared/issues/196)) ([e808a42](https://github.com/adobe/spacecat-shared/commit/e808a4249ea470f8da3bfd659093d2ab134630a5))

# [@adobe/spacecat-shared-data-access-v1.20.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.20.4...@adobe/spacecat-shared-data-access-v1.20.5) (2024-03-23)


### Bug Fixes

* **deps:** update external fixes ([#197](https://github.com/adobe/spacecat-shared/issues/197)) ([776c657](https://github.com/adobe/spacecat-shared/commit/776c657b3ebb2d5b2cd2379aed82d3b9a85ded51))

# [@adobe/spacecat-shared-data-access-v1.20.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.20.3...@adobe/spacecat-shared-data-access-v1.20.4) (2024-03-19)


### Bug Fixes

* audit result can be an array ([#189](https://github.com/adobe/spacecat-shared/issues/189)) ([6982907](https://github.com/adobe/spacecat-shared/commit/698290744cf15758f0d27c900484ac4949d42224))

# [@adobe/spacecat-shared-data-access-v1.20.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.20.2...@adobe/spacecat-shared-data-access-v1.20.3) (2024-03-18)


### Bug Fixes

* **deps:** update external fixes ([#183](https://github.com/adobe/spacecat-shared/issues/183)) ([0c292e5](https://github.com/adobe/spacecat-shared/commit/0c292e5cff5647e1947f4095ff8f28b3a0155ed6))

# [@adobe/spacecat-shared-data-access-v1.20.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.20.1...@adobe/spacecat-shared-data-access-v1.20.2) (2024-03-11)


### Bug Fixes

* include invalid base url in error message ([#180](https://github.com/adobe/spacecat-shared/issues/180)) ([4254305](https://github.com/adobe/spacecat-shared/commit/4254305402e5764a00388cc3904dc667eae1d602))

# [@adobe/spacecat-shared-data-access-v1.20.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.20.0...@adobe/spacecat-shared-data-access-v1.20.1) (2024-03-09)


### Bug Fixes

* **deps:** update external fixes ([#179](https://github.com/adobe/spacecat-shared/issues/179)) ([9d0aa97](https://github.com/adobe/spacecat-shared/commit/9d0aa97df6a67bb66c5f098c74aebdebbd0d5f01))

# [@adobe/spacecat-shared-data-access-v1.20.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.19.3...@adobe/spacecat-shared-data-access-v1.20.0) (2024-03-07)


### Features

* get and update configurations ([#178](https://github.com/adobe/spacecat-shared/issues/178)) ([163e27a](https://github.com/adobe/spacecat-shared/commit/163e27ad1cf704608a3fba8087d5103c8cb4226d)), closes [#183](https://github.com/adobe/spacecat-shared/issues/183) [/github.com/adobe/spacecat-api-service/issues/183#issuecomment-1973345923](https://github.com//github.com/adobe/spacecat-api-service/issues/183/issues/issuecomment-1973345923)

# [@adobe/spacecat-shared-data-access-v1.19.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.19.2...@adobe/spacecat-shared-data-access-v1.19.3) (2024-03-02)


### Bug Fixes

* **deps:** update external fixes ([#177](https://github.com/adobe/spacecat-shared/issues/177)) ([dbe3b90](https://github.com/adobe/spacecat-shared/commit/dbe3b9051f682ca2c1a6677eea9d1fcdf021dbdb))

# [@adobe/spacecat-shared-data-access-v1.19.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.19.1...@adobe/spacecat-shared-data-access-v1.19.2) (2024-02-28)


### Bug Fixes

* update config packaging for site ([#172](https://github.com/adobe/spacecat-shared/issues/172)) ([c07f100](https://github.com/adobe/spacecat-shared/commit/c07f1007fd90fbf2cb211200cf9fd01e1db13fc6))

# [@adobe/spacecat-shared-data-access-v1.19.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.19.0...@adobe/spacecat-shared-data-access-v1.19.1) (2024-02-28)


### Bug Fixes

* update config packaging ([#171](https://github.com/adobe/spacecat-shared/issues/171)) ([0e07ce6](https://github.com/adobe/spacecat-shared/commit/0e07ce6aa3f1a585bcaadb9f4ca3f69293834bf0))

# [@adobe/spacecat-shared-data-access-v1.19.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.18.1...@adobe/spacecat-shared-data-access-v1.19.0) (2024-02-28)


### Features

* audit-config support for organizations ([#169](https://github.com/adobe/spacecat-shared/issues/169)) ([ed867a5](https://github.com/adobe/spacecat-shared/commit/ed867a56917f349f82f6e8fa64c23bbf71376859))

# [@adobe/spacecat-shared-data-access-v1.18.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.18.0...@adobe/spacecat-shared-data-access-v1.18.1) (2024-02-24)


### Bug Fixes

* **deps:** update external fixes ([#161](https://github.com/adobe/spacecat-shared/issues/161)) ([532976a](https://github.com/adobe/spacecat-shared/commit/532976adecead566dac4659be916cd26f2350ba0))

# [@adobe/spacecat-shared-data-access-v1.18.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.17.2...@adobe/spacecat-shared-data-access-v1.18.0) (2024-02-23)


### Features

* fulfillable items support on Organization ([#160](https://github.com/adobe/spacecat-shared/issues/160)) ([7bc5bfc](https://github.com/adobe/spacecat-shared/commit/7bc5bfc596171f6007eb759c282681b29b138672))

# [@adobe/spacecat-shared-data-access-v1.17.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.17.1...@adobe/spacecat-shared-data-access-v1.17.2) (2024-02-17)


### Bug Fixes

* **deps:** update external fixes ([#157](https://github.com/adobe/spacecat-shared/issues/157)) ([015d12d](https://github.com/adobe/spacecat-shared/commit/015d12d34d3fded8d214df7147869d8905feb88a))

# [@adobe/spacecat-shared-data-access-v1.17.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.17.0...@adobe/spacecat-shared-data-access-v1.17.1) (2024-02-15)


### Bug Fixes

* generify site and organization config ([0ec8ee1](https://github.com/adobe/spacecat-shared/commit/0ec8ee1445e389c47d6ece436853e5b4c105ca93))

# [@adobe/spacecat-shared-data-access-v1.17.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.16.0...@adobe/spacecat-shared-data-access-v1.17.0) (2024-02-14)


### Features

* get organization by IMS org ID ([#153](https://github.com/adobe/spacecat-shared/issues/153)) ([541e7e7](https://github.com/adobe/spacecat-shared/commit/541e7e721cb21e977b59b19cf53dfb7ba460905f))

# [@adobe/spacecat-shared-data-access-v1.16.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.15.6...@adobe/spacecat-shared-data-access-v1.16.0) (2024-02-14)


### Features

* add configurations data access ([65bdc25](https://github.com/adobe/spacecat-shared/commit/65bdc2581e150cb32eb51d4d2bf03c8172ec2247))

# [@adobe/spacecat-shared-data-access-v1.15.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.15.5...@adobe/spacecat-shared-data-access-v1.15.6) (2024-02-12)


### Bug Fixes

* return empty sites for getSitesByOrganizationIDWithLatestAudit ([1caaa39](https://github.com/adobe/spacecat-shared/commit/1caaa39f20d2c73b9a195d43c57d320fb009fba7))

# [@adobe/spacecat-shared-data-access-v1.15.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.15.4...@adobe/spacecat-shared-data-access-v1.15.5) (2024-02-12)


### Bug Fixes

* **deps:** update external fixes ([#148](https://github.com/adobe/spacecat-shared/issues/148)) ([a32b5ce](https://github.com/adobe/spacecat-shared/commit/a32b5ce7c57e06d9b27250a8e59b666198945f72))

# [@adobe/spacecat-shared-data-access-v1.15.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.15.3...@adobe/spacecat-shared-data-access-v1.15.4) (2024-02-09)


### Bug Fixes

* add experimentation type audit ([#147](https://github.com/adobe/spacecat-shared/issues/147)) ([221fa29](https://github.com/adobe/spacecat-shared/commit/221fa296799a9004c991a9f3656e735d4babd612))

# [@adobe/spacecat-shared-data-access-v1.15.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.15.2...@adobe/spacecat-shared-data-access-v1.15.3) (2024-02-08)


### Bug Fixes

* site-candidate should not have id ([#144](https://github.com/adobe/spacecat-shared/issues/144)) ([9d0ebe8](https://github.com/adobe/spacecat-shared/commit/9d0ebe85c993ea428a845ce417b1e9c727b13b52))

# [@adobe/spacecat-shared-data-access-v1.15.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.15.1...@adobe/spacecat-shared-data-access-v1.15.2) (2024-02-07)


### Bug Fixes

* increase it test timeout ([70d92a2](https://github.com/adobe/spacecat-shared/commit/70d92a25b1571b5de2c22be4c71e3142dff360ad))

# [@adobe/spacecat-shared-data-access-v1.15.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.15.0...@adobe/spacecat-shared-data-access-v1.15.1) (2024-02-07)


### Bug Fixes

* retrieve site candidate by base url ([#140](https://github.com/adobe/spacecat-shared/issues/140)) ([b37cb0b](https://github.com/adobe/spacecat-shared/commit/b37cb0b1948f87e0e791cfec1e2b1fef9c0abb07))

# [@adobe/spacecat-shared-data-access-v1.15.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.14.1...@adobe/spacecat-shared-data-access-v1.15.0) (2024-02-06)


### Features

* add organic traffic audit type (SITES-18661) ([#132](https://github.com/adobe/spacecat-shared/issues/132)) ([ae63081](https://github.com/adobe/spacecat-shared/commit/ae6308174534ae702c8074a47cbda9a59c6b7f6c))

# [@adobe/spacecat-shared-data-access-v1.14.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.14.0...@adobe/spacecat-shared-data-access-v1.14.1) (2024-02-05)


### Bug Fixes

* **deps:** update external fixes ([#129](https://github.com/adobe/spacecat-shared/issues/129)) ([22b6c90](https://github.com/adobe/spacecat-shared/commit/22b6c90aea25783116165fa1dacb08c631c792bc))

# [@adobe/spacecat-shared-data-access-v1.14.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.13.2...@adobe/spacecat-shared-data-access-v1.14.0) (2024-02-02)


### Features

* site candidate data model ([#126](https://github.com/adobe/spacecat-shared/issues/126)) ([c457645](https://github.com/adobe/spacecat-shared/commit/c4576455b514675e7f3ce1efa53ecc1372fe491a))

# [@adobe/spacecat-shared-data-access-v1.13.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.13.1...@adobe/spacecat-shared-data-access-v1.13.2) (2024-01-30)


### Bug Fixes

* config validation ([edc1276](https://github.com/adobe/spacecat-shared/commit/edc127681e26c3283e5ecc94cde7c5fec78529dd))

# [@adobe/spacecat-shared-data-access-v1.13.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.13.0...@adobe/spacecat-shared-data-access-v1.13.1) (2024-01-30)


### Bug Fixes

* allow update config for site ([ad9e677](https://github.com/adobe/spacecat-shared/commit/ad9e677c7c721aa70e37b97373a4b9545f2f21fd))

# [@adobe/spacecat-shared-data-access-v1.13.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.12.0...@adobe/spacecat-shared-data-access-v1.13.0) (2024-01-30)


### Features

* introduce default config for organic-keywords report (SITES-19317) ([#118](https://github.com/adobe/spacecat-shared/issues/118)) ([4301556](https://github.com/adobe/spacecat-shared/commit/430155645e1452760bf2818d70a0faae2fb8db12))

# [@adobe/spacecat-shared-data-access-v1.12.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.11.0...@adobe/spacecat-shared-data-access-v1.12.0) (2024-01-29)


### Features

* add getSitesByOrganizationIDWithLatestAudits query ([d3a8f8c](https://github.com/adobe/spacecat-shared/commit/d3a8f8cc2148229aecec3df277e298a3f0746865))

# [@adobe/spacecat-shared-data-access-v1.11.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.10.5...@adobe/spacecat-shared-data-access-v1.11.0) (2024-01-29)


### Features

* default value for disabled property of audit config ([#114](https://github.com/adobe/spacecat-shared/issues/114)) ([daf9b80](https://github.com/adobe/spacecat-shared/commit/daf9b8039a6fe567e283dc07eef156bfd13edc4f))

# [@adobe/spacecat-shared-data-access-v1.10.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.10.4...@adobe/spacecat-shared-data-access-v1.10.5) (2024-01-27)


### Bug Fixes

* **deps:** update external fixes to v3.501.0 ([#115](https://github.com/adobe/spacecat-shared/issues/115)) ([7cf246f](https://github.com/adobe/spacecat-shared/commit/7cf246f4ddb303f149937bbe019032b876934bd7))

# [@adobe/spacecat-shared-data-access-v1.10.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.10.3...@adobe/spacecat-shared-data-access-v1.10.4) (2024-01-26)


### Bug Fixes

* **deps:** update external fixes ([#111](https://github.com/adobe/spacecat-shared/issues/111)) ([d58736c](https://github.com/adobe/spacecat-shared/commit/d58736cb76499f40ae3e0d43c9981f5d34c96c0b))

# [@adobe/spacecat-shared-data-access-v1.10.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.10.2...@adobe/spacecat-shared-data-access-v1.10.3) (2024-01-24)


### Bug Fixes

* organizations query ([37b4b14](https://github.com/adobe/spacecat-shared/commit/37b4b1439e6f2b6ab7c87b1abcfcefb9b2c8a394))

# [@adobe/spacecat-shared-data-access-v1.10.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.10.1...@adobe/spacecat-shared-data-access-v1.10.2) (2024-01-24)


### Bug Fixes

* add missing org data layer methods ([#107](https://github.com/adobe/spacecat-shared/issues/107)) ([0504d8e](https://github.com/adobe/spacecat-shared/commit/0504d8e8f0486d1f1a00f44a18c42948ddfd93c7))

# [@adobe/spacecat-shared-data-access-v1.10.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.10.0...@adobe/spacecat-shared-data-access-v1.10.1) (2024-01-23)


### Bug Fixes

* use released official version of monorepo after fix ([#101](https://github.com/adobe/spacecat-shared/issues/101)) ([39297be](https://github.com/adobe/spacecat-shared/commit/39297be9f7e335925a8ace1b1a19efad01ba3628))

# [@adobe/spacecat-shared-data-access-v1.10.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.9.6...@adobe/spacecat-shared-data-access-v1.10.0) (2024-01-23)


### Features

* add 404 as valid audit type ([62e0dec](https://github.com/adobe/spacecat-shared/commit/62e0dec832cdccfc9c3d8fbda61a81d756a5a08a))

# [@adobe/spacecat-shared-data-access-v1.9.6](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.9.5...@adobe/spacecat-shared-data-access-v1.9.6) (2024-01-23)


### Bug Fixes

* missing module releaserc ([0ec70ba](https://github.com/adobe/spacecat-shared/commit/0ec70ba171edd66f4aa4e3770cc9b2a3e29d752c))
* monorepo extends overwrites config ([#99](https://github.com/adobe/spacecat-shared/issues/99)) ([fea357f](https://github.com/adobe/spacecat-shared/commit/fea357f105d96e3d9dbf87687c26bc34b21f8b5d))
* set latest version for semantic ([#94](https://github.com/adobe/spacecat-shared/issues/94)) ([932e11f](https://github.com/adobe/spacecat-shared/commit/932e11fa4128013a13dcdbd32b378ce448d449f6))

# 1.0.0 (2024-01-22)


### Bug Fixes

* add code-ql ([312af05](https://github.com/adobe/spacecat-shared/commit/312af0553ee001736f4625bea7498bf44268f5d5))
* add missing pattern to interface ([#72](https://github.com/adobe/spacecat-shared/issues/72)) ([0eacbff](https://github.com/adobe/spacecat-shared/commit/0eacbff39dbc12d604e40ae94285533f7804ca0a))
* add package exports to npm module ([#4](https://github.com/adobe/spacecat-shared/issues/4)) ([7236d40](https://github.com/adobe/spacecat-shared/commit/7236d408c560e89a28972b6c695a6919e72854e7))
* allow sorting for get audits for site ([#41](https://github.com/adobe/spacecat-shared/issues/41)) ([3664c97](https://github.com/adobe/spacecat-shared/commit/3664c97bd63d4f10e260582455e3763da60399dd))
* allow update of github URL ([#40](https://github.com/adobe/spacecat-shared/issues/40)) ([21da989](https://github.com/adobe/spacecat-shared/commit/21da9893fcb9c971c1c6a4e1271133188351c155))
* allow use of index for getItem ([#10](https://github.com/adobe/spacecat-shared/issues/10)) ([9a984d1](https://github.com/adobe/spacecat-shared/commit/9a984d176f02444409318a5f4287d75249b2d83a))
* audit result scores init, test ([#89](https://github.com/adobe/spacecat-shared/issues/89)) ([96f829c](https://github.com/adobe/spacecat-shared/commit/96f829c908e38b2e5f303eee83da2488f8076a0b))
* auto-remove undefined values ([#64](https://github.com/adobe/spacecat-shared/issues/64)) ([ce9abac](https://github.com/adobe/spacecat-shared/commit/ce9abac0f99471616bd2fb971e18953791e364c3))
* bogus change to force release ([e77e830](https://github.com/adobe/spacecat-shared/commit/e77e8305c96ac2504aeb22af44d45cb4acbcae56))
* createdAt test ([#88](https://github.com/adobe/spacecat-shared/issues/88)) ([ac6a5ba](https://github.com/adobe/spacecat-shared/commit/ac6a5bab9ee45a2840681f291a13f23a3eb97e25))
* **deps:** update aws-sdk-js-v3 monorepo ([#16](https://github.com/adobe/spacecat-shared/issues/16)) ([e60296a](https://github.com/adobe/spacecat-shared/commit/e60296a78105079527e80c802c60de5d28ebd207))
* **deps:** update aws-sdk-js-v3 monorepo to v3.465.0 ([#19](https://github.com/adobe/spacecat-shared/issues/19)) ([612c257](https://github.com/adobe/spacecat-shared/commit/612c257870dc171d32c4ca5f8c2e48f9f77f8198))
* **deps:** update aws-sdk-js-v3 monorepo to v3.477.0 ([#68](https://github.com/adobe/spacecat-shared/issues/68)) ([492913f](https://github.com/adobe/spacecat-shared/commit/492913f0011d557b7c91ba631c13ced171bc2ce9))
* **deps:** update dependency uuid to v9 ([#22](https://github.com/adobe/spacecat-shared/issues/22)) ([456bfe8](https://github.com/adobe/spacecat-shared/commit/456bfe8e253d3589304624ba2281d51a4c9e4d22))
* **deps:** update external fixes ([#71](https://github.com/adobe/spacecat-shared/issues/71)) ([b9a6679](https://github.com/adobe/spacecat-shared/commit/b9a667966e7b0f013f46c62f6cc4a85f80623c61))
* **deps:** update external fixes ([#76](https://github.com/adobe/spacecat-shared/issues/76)) ([5b74623](https://github.com/adobe/spacecat-shared/commit/5b74623a4accfb601b607170f9bd67fb380f5c84))
* **deps:** update external fixes ([#81](https://github.com/adobe/spacecat-shared/issues/81)) ([67cf21c](https://github.com/adobe/spacecat-shared/commit/67cf21c548d036de45221e118ff3bc0e7b26a692))
* **deps:** update external fixes ([#90](https://github.com/adobe/spacecat-shared/issues/90)) ([df8161e](https://github.com/adobe/spacecat-shared/commit/df8161e4be87a5a3035729ce94388a8ccaf1630b))
* distinguish lhs-mobile vs lhs-desktop ([#27](https://github.com/adobe/spacecat-shared/issues/27)) ([18fd1b1](https://github.com/adobe/spacecat-shared/commit/18fd1b18ae400c32bbb3a175f7d6a6cde104f4a1))
* export getLatestAuditsForSite ([#39](https://github.com/adobe/spacecat-shared/issues/39)) ([e9c9130](https://github.com/adobe/spacecat-shared/commit/e9c9130b940122714be76e3df6e96e44bbde5348))
* export rumapiclient as default ([#52](https://github.com/adobe/spacecat-shared/issues/52)) ([7c5d2f5](https://github.com/adobe/spacecat-shared/commit/7c5d2f56a5822ed93d63c894ded766924905c797))
* get audit no query ([#34](https://github.com/adobe/spacecat-shared/issues/34)) ([8fadd0a](https://github.com/adobe/spacecat-shared/commit/8fadd0a21a1e0cc232a06ccf805d1ac5c946b8be))
* get latest audits with delivery type ([#80](https://github.com/adobe/spacecat-shared/issues/80)) ([d823773](https://github.com/adobe/spacecat-shared/commit/d823773d738ebddf2790356750827ae74e66b052))
* getSitesByDeliveryType signature ([#78](https://github.com/adobe/spacecat-shared/issues/78)) ([2b6c0fd](https://github.com/adobe/spacecat-shared/commit/2b6c0fd3e603eb3c688a45ae9ab78baf88a508ef))
* github org ([02f86c3](https://github.com/adobe/spacecat-shared/commit/02f86c351b2b1ab99ce5aca7fd5e6af2246c0efd))
* github semantic plugin config ([db5a14a](https://github.com/adobe/spacecat-shared/commit/db5a14af6d09333cea10af8624e07454bbeac838))
* github token reference ([8ac46cf](https://github.com/adobe/spacecat-shared/commit/8ac46cfa7dd8e0e2cc7b8bfa2f07e186055ce417))
* GSI sort key when error ([#62](https://github.com/adobe/spacecat-shared/issues/62)) ([dbb6a91](https://github.com/adobe/spacecat-shared/commit/dbb6a91f75fa9492a621de7b258cbebe38fe3ac7))
* include audit ref and audited at ([#75](https://github.com/adobe/spacecat-shared/issues/75)) ([e573c90](https://github.com/adobe/spacecat-shared/commit/e573c903851d88c7293caa5e5a9af763987edb3a))
* include sites without latest audits ([#45](https://github.com/adobe/spacecat-shared/issues/45)) ([b843190](https://github.com/adobe/spacecat-shared/commit/b843190da09916832a743d6fc4bf83e804b61912))
* initialize scores as an empty object (SITES-18417) ([b43b96d](https://github.com/adobe/spacecat-shared/commit/b43b96d5636e5f91bd08ef81d22f2372b02d2809))
* initialize scores as an empty object (SITES-18417) ([#87](https://github.com/adobe/spacecat-shared/issues/87)) ([eb38e32](https://github.com/adobe/spacecat-shared/commit/eb38e3298228edb1d996fa633bff4af4dcbf69db))
* key validation ([#7](https://github.com/adobe/spacecat-shared/issues/7)) ([4283e14](https://github.com/adobe/spacecat-shared/commit/4283e1418f78b8d610637b90bd504e47ae3bc8ee))
* latest-audits sort key ([#33](https://github.com/adobe/spacecat-shared/issues/33)) ([21dc14e](https://github.com/adobe/spacecat-shared/commit/21dc14e75e8aad641f1c99330243a3102e8de465))
* make RUMOptions optional ([6c2825b](https://github.com/adobe/spacecat-shared/commit/6c2825b49977ce50bc998258e9f23c73cc822b22))
* missing module releaserc ([0ec70ba](https://github.com/adobe/spacecat-shared/commit/0ec70ba171edd66f4aa4e3770cc9b2a3e29d752c))
* move to main.yml ([89a8c69](https://github.com/adobe/spacecat-shared/commit/89a8c6969a576b17544345e0975d97b52c3c8ebc))
* no undefined for putItem ([#43](https://github.com/adobe/spacecat-shared/issues/43)) ([283f229](https://github.com/adobe/spacecat-shared/commit/283f2299956c53ea77206a973210c3ecc9475180))
* npm token (again) ([9934572](https://github.com/adobe/spacecat-shared/commit/99345729cc40e48dd5789ec54c30acca69c57516))
* npm token renovate ([b6656e7](https://github.com/adobe/spacecat-shared/commit/b6656e7d32b5b9432b72944fa5aef44d1cd82259))
* npmToken for renovate ([155a5f3](https://github.com/adobe/spacecat-shared/commit/155a5f333dfe95eb729f5fa271d351b5f5493405))
* package name to "adobe" ([475434e](https://github.com/adobe/spacecat-shared/commit/475434e6619c2128ba1a8308a4eed23cf3d40691))
* pass ascending param ([#42](https://github.com/adobe/spacecat-shared/issues/42)) ([930ae6b](https://github.com/adobe/spacecat-shared/commit/930ae6b09825cf37de90db0a4331eebe5f58a70e))
* re-set node 20 ([ef24765](https://github.com/adobe/spacecat-shared/commit/ef2476591d7eed34f2d6726c60faab285c3706e2))
* reduce log output of putitem ([#31](https://github.com/adobe/spacecat-shared/issues/31)) ([29d1496](https://github.com/adobe/spacecat-shared/commit/29d149661c56f2cef0c7d02d39bc8aad89475afa))
* remove .keep ([4f9319f](https://github.com/adobe/spacecat-shared/commit/4f9319fe77138684d2a81ac29a1bdfa34575d238))
* remove unneeded import (force release) ([49964f9](https://github.com/adobe/spacecat-shared/commit/49964f99906d5a0fafeb68b460cb19f98a51fc86))
* remove unsupported codeql workflow ([467bd3b](https://github.com/adobe/spacecat-shared/commit/467bd3b47c35280f6dc2e6bd897ec61976df0169))
* rename circle ci ([c12906e](https://github.com/adobe/spacecat-shared/commit/c12906ee6a9e572e2763babe60c276dd49310d17))
* rename NPM token ([fb23bf1](https://github.com/adobe/spacecat-shared/commit/fb23bf1f17ca393cbef1faaadfc42b4526b30589))
* renovate ([1a16980](https://github.com/adobe/spacecat-shared/commit/1a16980d5c78530a10dfbd7513ce3b338ffb5e7a))
* repo reference ([881487d](https://github.com/adobe/spacecat-shared/commit/881487dce4c840ac2bf02a285f17cac511d39c88))
* roll-back esm monorepo ([ab77518](https://github.com/adobe/spacecat-shared/commit/ab775187dc79a7f2cdb0ca4fa31198202be78143))
* roll-back node 20 for github workflow ([876e26c](https://github.com/adobe/spacecat-shared/commit/876e26c343fbf5121bcfed0827e551f0973c1b83))
* rollback test change for node 18 ([ff981fb](https://github.com/adobe/spacecat-shared/commit/ff981fbb658cba611a188a57a1b1c79f1ba8e89a))
* rum domain key env var ([b52ead5](https://github.com/adobe/spacecat-shared/commit/b52ead5217f20cb48f2026bf86d04d72671f81c5))
* semantic-release scripts ([6078334](https://github.com/adobe/spacecat-shared/commit/607833457210c50342712fb8a90c2b711915ffec))
* set default organization ([#92](https://github.com/adobe/spacecat-shared/issues/92)) ([ac7e70c](https://github.com/adobe/spacecat-shared/commit/ac7e70c65f643c2f52730c3d5da4a0c4be282632))
* set github_token correctly ([cf6a8aa](https://github.com/adobe/spacecat-shared/commit/cf6a8aa75a17fbc82a3f3cd9499f26cbb945c8aa))
* set latest version for semantic ([#94](https://github.com/adobe/spacecat-shared/issues/94)) ([932e11f](https://github.com/adobe/spacecat-shared/commit/932e11fa4128013a13dcdbd32b378ce448d449f6))
* set package version to semantic, remove dev deps ([bf62c5f](https://github.com/adobe/spacecat-shared/commit/bf62c5fe013dbbb7425eb21cffa23e7f01322aee))
* set pre-commit hook executable ([3ce9a6c](https://github.com/adobe/spacecat-shared/commit/3ce9a6ccfa2950c7401c11a8846b38f2ab4baadb))
* set to semantic-release versioning ([9209799](https://github.com/adobe/spacecat-shared/commit/92097995b657207996dd6a35277fdfcd3f3e8fb9))
* sort order sites with latest audits ([#46](https://github.com/adobe/spacecat-shared/issues/46)) ([8da2bf1](https://github.com/adobe/spacecat-shared/commit/8da2bf16b904ced6787d8c56ba2b4b72678687a0))
* switch defaults to dev (force release) ([b85d54c](https://github.com/adobe/spacecat-shared/commit/b85d54ca7430a4e54b49d112429242c81ff55714))
* type def / jsdoc ([#61](https://github.com/adobe/spacecat-shared/issues/61)) ([078f9e6](https://github.com/adobe/spacecat-shared/commit/078f9e6855d3f475f3a746561758aaefb5cb3c79))
* typo ([9167cf3](https://github.com/adobe/spacecat-shared/commit/9167cf3ac70a998aa92aaef24e080cd8147a70e9))
* update dynamo client ([#65](https://github.com/adobe/spacecat-shared/issues/65)) ([cc09041](https://github.com/adobe/spacecat-shared/commit/cc09041200dfe23c0a83c384fc9695ac972564e9))
* update node to lts/20, semantic release, misc ([#91](https://github.com/adobe/spacecat-shared/issues/91)) ([099662a](https://github.com/adobe/spacecat-shared/commit/099662af314866852313e250cecead2404e52f42))
* update readme (force release) ([#95](https://github.com/adobe/spacecat-shared/issues/95)) ([8dd61cd](https://github.com/adobe/spacecat-shared/commit/8dd61cd3eda24af6915dc19ba42bbd4586b18962))
* update readme (test release ([#93](https://github.com/adobe/spacecat-shared/issues/93)) ([d5142d0](https://github.com/adobe/spacecat-shared/commit/d5142d06b912beb6cba01c27aa6cafb04ab0baf7))
* use correct doc client ([#9](https://github.com/adobe/spacecat-shared/issues/9)) ([d052b16](https://github.com/adobe/spacecat-shared/commit/d052b16dc6baf65efe83e34fe82d50265f6ae751))
* use getItem for latest audit ([#35](https://github.com/adobe/spacecat-shared/issues/35)) ([6e4a87e](https://github.com/adobe/spacecat-shared/commit/6e4a87ea2d515f632b34278a8cc1ffd51d692a16))
* use new aem datadesk ui for the backlinks ([#79](https://github.com/adobe/spacecat-shared/issues/79)) ([526b69c](https://github.com/adobe/spacecat-shared/commit/526b69cc8067f883f2ce0ab10c712b8ca094c81d))
* variouss ([ea9d44f](https://github.com/adobe/spacecat-shared/commit/ea9d44f6071c1a53d2c31515966e7cdf44be7ae9))
* wrap scores ([#28](https://github.com/adobe/spacecat-shared/issues/28)) ([4733a93](https://github.com/adobe/spacecat-shared/commit/4733a93d2db087dd57f94955a2101e5a4bb74ce2))


### Features

* add audit config ([#59](https://github.com/adobe/spacecat-shared/issues/59)) ([f851862](https://github.com/adobe/spacecat-shared/commit/f8518623a8b8e4e337b3c44a16b65724a953596a))
* add broken-backlinks audit type (SITES-18417) ([#86](https://github.com/adobe/spacecat-shared/issues/86)) ([b16c366](https://github.com/adobe/spacecat-shared/commit/b16c3667808221958ff4a526512cb89c3cd0bbcb))
* add data access module ([#11](https://github.com/adobe/spacecat-shared/issues/11)) ([cdbfff3](https://github.com/adobe/spacecat-shared/commit/cdbfff3961cbfc5702b832c386e3ccfd8572b439))
* add dynamo and utils modules ([#3](https://github.com/adobe/spacecat-shared/issues/3)) ([5e2e605](https://github.com/adobe/spacecat-shared/commit/5e2e6059648f4f554168dabeab737f6a09d8a050))
* add guards and use spacecat-shared-utils ([#6](https://github.com/adobe/spacecat-shared/issues/6)) ([27143cf](https://github.com/adobe/spacecat-shared/commit/27143cf2d4a439f1b5904e62756e59e501b3f67d))
* add isArray function ([eeb45a6](https://github.com/adobe/spacecat-shared/commit/eeb45a6784c6406403d0a59b65ba873a107c654c))
* add rum api calls to shared ([56cccd0](https://github.com/adobe/spacecat-shared/commit/56cccd0f498eaca6a4bb35a6b64d5f0dbe68a096))
* add support for 404 report backlink ([0d622de](https://github.com/adobe/spacecat-shared/commit/0d622de241b51f0df625679591dd5168b5b070a7))
* allow configuration from ctx / add missing fields ([#24](https://github.com/adobe/spacecat-shared/issues/24)) ([6959f89](https://github.com/adobe/spacecat-shared/commit/6959f895ed9b167f421b201f856ef871bd2a335c))
* data model for organizations ([944be83](https://github.com/adobe/spacecat-shared/commit/944be83c9f19e3acee9bb17352b3058fe6578a69))
* http utils package ([#51](https://github.com/adobe/spacecat-shared/issues/51)) ([84cd91a](https://github.com/adobe/spacecat-shared/commit/84cd91ae4225455327116169f5b040cc9adc1c2e))
* http-utils functions ([#49](https://github.com/adobe/spacecat-shared/issues/49)) ([20e98fa](https://github.com/adobe/spacecat-shared/commit/20e98faa75d2f439ea5e671937f78bea706ec5d7))
* introduce getSiteByID ([#36](https://github.com/adobe/spacecat-shared/issues/36)) ([5677f76](https://github.com/adobe/spacecat-shared/commit/5677f76d11d97f2a2afd878e0ada7cad22fd1f03))
* resolve secrets name ([#44](https://github.com/adobe/spacecat-shared/issues/44)) ([8c7604d](https://github.com/adobe/spacecat-shared/commit/8c7604da6b36f450a9054fa93c6c469c1f47319b))
* rum api client ([#48](https://github.com/adobe/spacecat-shared/issues/48)) ([ccfa187](https://github.com/adobe/spacecat-shared/commit/ccfa187a45f35e57085ac241ff156c0b9418592d))
* set isLiveToggledAt ([#85](https://github.com/adobe/spacecat-shared/issues/85)) ([cefc093](https://github.com/adobe/spacecat-shared/commit/cefc0938385b9fa079d24c24f03b21651a0999cc))
* site delivery type ([#77](https://github.com/adobe/spacecat-shared/issues/77)) ([005bc38](https://github.com/adobe/spacecat-shared/commit/005bc388ed6ab0f82c8b0f562d4c1f4c0d1e2894))
* store previous latest audit result ([#74](https://github.com/adobe/spacecat-shared/issues/74)) ([4663c43](https://github.com/adobe/spacecat-shared/commit/4663c4344e260f85c4e64691e0685260d36629e5))
* test ([bd3cc5d](https://github.com/adobe/spacecat-shared/commit/bd3cc5df89ccde75b86b000e8495893f4b099b5b))
* update audit config ([#63](https://github.com/adobe/spacecat-shared/issues/63)) ([00a468e](https://github.com/adobe/spacecat-shared/commit/00a468e9404676212ec9441c8a7fccf1a93c636f))


### Reverts

* Revert "fix: allow use of index for getItem (#10)" (#15) ([ad03176](https://github.com/adobe/spacecat-shared/commit/ad0317625074a26a4600d7e464a53c3b6dd78fe4)), closes [#10](https://github.com/adobe/spacecat-shared/issues/10) [#15](https://github.com/adobe/spacecat-shared/issues/15)

## [1.0.2](https://github.com/adobe/spacecat-shared/compare/v1.0.1...v1.0.2) (2024-01-22)


### Bug Fixes

* set latest version for semantic ([#94](https://github.com/adobe/spacecat-shared/issues/94)) ([932e11f](https://github.com/adobe/spacecat-shared/commit/932e11fa4128013a13dcdbd32b378ce448d449f6))

## [1.0.1](https://github.com/adobe/spacecat-shared/compare/v1.0.0...v1.0.1) (2024-01-22)


### Bug Fixes

* update readme (test release ([#93](https://github.com/adobe/spacecat-shared/issues/93)) ([d5142d0](https://github.com/adobe/spacecat-shared/commit/d5142d06b912beb6cba01c27aa6cafb04ab0baf7))

# 1.0.0 (2024-01-22)


### Bug Fixes

* add code-ql ([312af05](https://github.com/adobe/spacecat-shared/commit/312af0553ee001736f4625bea7498bf44268f5d5))
* add missing pattern to interface ([#72](https://github.com/adobe/spacecat-shared/issues/72)) ([0eacbff](https://github.com/adobe/spacecat-shared/commit/0eacbff39dbc12d604e40ae94285533f7804ca0a))
* add package exports to npm module ([#4](https://github.com/adobe/spacecat-shared/issues/4)) ([7236d40](https://github.com/adobe/spacecat-shared/commit/7236d408c560e89a28972b6c695a6919e72854e7))
* allow sorting for get audits for site ([#41](https://github.com/adobe/spacecat-shared/issues/41)) ([3664c97](https://github.com/adobe/spacecat-shared/commit/3664c97bd63d4f10e260582455e3763da60399dd))
* allow update of github URL ([#40](https://github.com/adobe/spacecat-shared/issues/40)) ([21da989](https://github.com/adobe/spacecat-shared/commit/21da9893fcb9c971c1c6a4e1271133188351c155))
* allow use of index for getItem ([#10](https://github.com/adobe/spacecat-shared/issues/10)) ([9a984d1](https://github.com/adobe/spacecat-shared/commit/9a984d176f02444409318a5f4287d75249b2d83a))
* audit result scores init, test ([#89](https://github.com/adobe/spacecat-shared/issues/89)) ([96f829c](https://github.com/adobe/spacecat-shared/commit/96f829c908e38b2e5f303eee83da2488f8076a0b))
* auto-remove undefined values ([#64](https://github.com/adobe/spacecat-shared/issues/64)) ([ce9abac](https://github.com/adobe/spacecat-shared/commit/ce9abac0f99471616bd2fb971e18953791e364c3))
* bogus change to force release ([e77e830](https://github.com/adobe/spacecat-shared/commit/e77e8305c96ac2504aeb22af44d45cb4acbcae56))
* createdAt test ([#88](https://github.com/adobe/spacecat-shared/issues/88)) ([ac6a5ba](https://github.com/adobe/spacecat-shared/commit/ac6a5bab9ee45a2840681f291a13f23a3eb97e25))
* **deps:** update aws-sdk-js-v3 monorepo ([#16](https://github.com/adobe/spacecat-shared/issues/16)) ([e60296a](https://github.com/adobe/spacecat-shared/commit/e60296a78105079527e80c802c60de5d28ebd207))
* **deps:** update aws-sdk-js-v3 monorepo to v3.465.0 ([#19](https://github.com/adobe/spacecat-shared/issues/19)) ([612c257](https://github.com/adobe/spacecat-shared/commit/612c257870dc171d32c4ca5f8c2e48f9f77f8198))
* **deps:** update aws-sdk-js-v3 monorepo to v3.477.0 ([#68](https://github.com/adobe/spacecat-shared/issues/68)) ([492913f](https://github.com/adobe/spacecat-shared/commit/492913f0011d557b7c91ba631c13ced171bc2ce9))
* **deps:** update dependency uuid to v9 ([#22](https://github.com/adobe/spacecat-shared/issues/22)) ([456bfe8](https://github.com/adobe/spacecat-shared/commit/456bfe8e253d3589304624ba2281d51a4c9e4d22))
* **deps:** update external fixes ([#71](https://github.com/adobe/spacecat-shared/issues/71)) ([b9a6679](https://github.com/adobe/spacecat-shared/commit/b9a667966e7b0f013f46c62f6cc4a85f80623c61))
* **deps:** update external fixes ([#76](https://github.com/adobe/spacecat-shared/issues/76)) ([5b74623](https://github.com/adobe/spacecat-shared/commit/5b74623a4accfb601b607170f9bd67fb380f5c84))
* **deps:** update external fixes ([#81](https://github.com/adobe/spacecat-shared/issues/81)) ([67cf21c](https://github.com/adobe/spacecat-shared/commit/67cf21c548d036de45221e118ff3bc0e7b26a692))
* **deps:** update external fixes ([#90](https://github.com/adobe/spacecat-shared/issues/90)) ([df8161e](https://github.com/adobe/spacecat-shared/commit/df8161e4be87a5a3035729ce94388a8ccaf1630b))
* distinguish lhs-mobile vs lhs-desktop ([#27](https://github.com/adobe/spacecat-shared/issues/27)) ([18fd1b1](https://github.com/adobe/spacecat-shared/commit/18fd1b18ae400c32bbb3a175f7d6a6cde104f4a1))
* export getLatestAuditsForSite ([#39](https://github.com/adobe/spacecat-shared/issues/39)) ([e9c9130](https://github.com/adobe/spacecat-shared/commit/e9c9130b940122714be76e3df6e96e44bbde5348))
* export rumapiclient as default ([#52](https://github.com/adobe/spacecat-shared/issues/52)) ([7c5d2f5](https://github.com/adobe/spacecat-shared/commit/7c5d2f56a5822ed93d63c894ded766924905c797))
* get audit no query ([#34](https://github.com/adobe/spacecat-shared/issues/34)) ([8fadd0a](https://github.com/adobe/spacecat-shared/commit/8fadd0a21a1e0cc232a06ccf805d1ac5c946b8be))
* get latest audits with delivery type ([#80](https://github.com/adobe/spacecat-shared/issues/80)) ([d823773](https://github.com/adobe/spacecat-shared/commit/d823773d738ebddf2790356750827ae74e66b052))
* getSitesByDeliveryType signature ([#78](https://github.com/adobe/spacecat-shared/issues/78)) ([2b6c0fd](https://github.com/adobe/spacecat-shared/commit/2b6c0fd3e603eb3c688a45ae9ab78baf88a508ef))
* github org ([02f86c3](https://github.com/adobe/spacecat-shared/commit/02f86c351b2b1ab99ce5aca7fd5e6af2246c0efd))
* github semantic plugin config ([db5a14a](https://github.com/adobe/spacecat-shared/commit/db5a14af6d09333cea10af8624e07454bbeac838))
* github token reference ([8ac46cf](https://github.com/adobe/spacecat-shared/commit/8ac46cfa7dd8e0e2cc7b8bfa2f07e186055ce417))
* GSI sort key when error ([#62](https://github.com/adobe/spacecat-shared/issues/62)) ([dbb6a91](https://github.com/adobe/spacecat-shared/commit/dbb6a91f75fa9492a621de7b258cbebe38fe3ac7))
* include audit ref and audited at ([#75](https://github.com/adobe/spacecat-shared/issues/75)) ([e573c90](https://github.com/adobe/spacecat-shared/commit/e573c903851d88c7293caa5e5a9af763987edb3a))
* initialize scores as an empty object (SITES-18417) ([b43b96d](https://github.com/adobe/spacecat-shared/commit/b43b96d5636e5f91bd08ef81d22f2372b02d2809))
* initialize scores as an empty object (SITES-18417) ([#87](https://github.com/adobe/spacecat-shared/issues/87)) ([eb38e32](https://github.com/adobe/spacecat-shared/commit/eb38e3298228edb1d996fa633bff4af4dcbf69db))
* key validation ([#7](https://github.com/adobe/spacecat-shared/issues/7)) ([4283e14](https://github.com/adobe/spacecat-shared/commit/4283e1418f78b8d610637b90bd504e47ae3bc8ee))
* latest-audits sort key ([#33](https://github.com/adobe/spacecat-shared/issues/33)) ([21dc14e](https://github.com/adobe/spacecat-shared/commit/21dc14e75e8aad641f1c99330243a3102e8de465))
* make RUMOptions optional ([6c2825b](https://github.com/adobe/spacecat-shared/commit/6c2825b49977ce50bc998258e9f23c73cc822b22))
* missing module releaserc ([0ec70ba](https://github.com/adobe/spacecat-shared/commit/0ec70ba171edd66f4aa4e3770cc9b2a3e29d752c))
* move to main.yml ([89a8c69](https://github.com/adobe/spacecat-shared/commit/89a8c6969a576b17544345e0975d97b52c3c8ebc))
* no undefined for putItem ([#43](https://github.com/adobe/spacecat-shared/issues/43)) ([283f229](https://github.com/adobe/spacecat-shared/commit/283f2299956c53ea77206a973210c3ecc9475180))
* npm token (again) ([9934572](https://github.com/adobe/spacecat-shared/commit/99345729cc40e48dd5789ec54c30acca69c57516))
* npm token renovate ([b6656e7](https://github.com/adobe/spacecat-shared/commit/b6656e7d32b5b9432b72944fa5aef44d1cd82259))
* npmToken for renovate ([155a5f3](https://github.com/adobe/spacecat-shared/commit/155a5f333dfe95eb729f5fa271d351b5f5493405))
* package name to "adobe" ([475434e](https://github.com/adobe/spacecat-shared/commit/475434e6619c2128ba1a8308a4eed23cf3d40691))
* pass ascending param ([#42](https://github.com/adobe/spacecat-shared/issues/42)) ([930ae6b](https://github.com/adobe/spacecat-shared/commit/930ae6b09825cf37de90db0a4331eebe5f58a70e))
* re-set node 20 ([ef24765](https://github.com/adobe/spacecat-shared/commit/ef2476591d7eed34f2d6726c60faab285c3706e2))
* reduce log output of putitem ([#31](https://github.com/adobe/spacecat-shared/issues/31)) ([29d1496](https://github.com/adobe/spacecat-shared/commit/29d149661c56f2cef0c7d02d39bc8aad89475afa))
* remove .keep ([4f9319f](https://github.com/adobe/spacecat-shared/commit/4f9319fe77138684d2a81ac29a1bdfa34575d238))
* remove unneeded import (force release) ([49964f9](https://github.com/adobe/spacecat-shared/commit/49964f99906d5a0fafeb68b460cb19f98a51fc86))
* remove unsupported codeql workflow ([467bd3b](https://github.com/adobe/spacecat-shared/commit/467bd3b47c35280f6dc2e6bd897ec61976df0169))
* rename circle ci ([c12906e](https://github.com/adobe/spacecat-shared/commit/c12906ee6a9e572e2763babe60c276dd49310d17))
* rename NPM token ([fb23bf1](https://github.com/adobe/spacecat-shared/commit/fb23bf1f17ca393cbef1faaadfc42b4526b30589))
* renovate ([1a16980](https://github.com/adobe/spacecat-shared/commit/1a16980d5c78530a10dfbd7513ce3b338ffb5e7a))
* repo reference ([881487d](https://github.com/adobe/spacecat-shared/commit/881487dce4c840ac2bf02a285f17cac511d39c88))
* roll-back esm monorepo ([ab77518](https://github.com/adobe/spacecat-shared/commit/ab775187dc79a7f2cdb0ca4fa31198202be78143))
* roll-back node 20 for github workflow ([876e26c](https://github.com/adobe/spacecat-shared/commit/876e26c343fbf5121bcfed0827e551f0973c1b83))
* rollback test change for node 18 ([ff981fb](https://github.com/adobe/spacecat-shared/commit/ff981fbb658cba611a188a57a1b1c79f1ba8e89a))
* rum domain key env var ([b52ead5](https://github.com/adobe/spacecat-shared/commit/b52ead5217f20cb48f2026bf86d04d72671f81c5))
* semantic-release scripts ([6078334](https://github.com/adobe/spacecat-shared/commit/607833457210c50342712fb8a90c2b711915ffec))
* set default organization ([#92](https://github.com/adobe/spacecat-shared/issues/92)) ([ac7e70c](https://github.com/adobe/spacecat-shared/commit/ac7e70c65f643c2f52730c3d5da4a0c4be282632))
* set github_token correctly ([cf6a8aa](https://github.com/adobe/spacecat-shared/commit/cf6a8aa75a17fbc82a3f3cd9499f26cbb945c8aa))
* set package version to semantic, remove dev deps ([bf62c5f](https://github.com/adobe/spacecat-shared/commit/bf62c5fe013dbbb7425eb21cffa23e7f01322aee))
* set pre-commit hook executable ([3ce9a6c](https://github.com/adobe/spacecat-shared/commit/3ce9a6ccfa2950c7401c11a8846b38f2ab4baadb))
* set to semantic-release versioning ([9209799](https://github.com/adobe/spacecat-shared/commit/92097995b657207996dd6a35277fdfcd3f3e8fb9))
* sort order sites with latest audits ([#46](https://github.com/adobe/spacecat-shared/issues/46)) ([8da2bf1](https://github.com/adobe/spacecat-shared/commit/8da2bf16b904ced6787d8c56ba2b4b72678687a0))
* switch defaults to dev (force release) ([b85d54c](https://github.com/adobe/spacecat-shared/commit/b85d54ca7430a4e54b49d112429242c81ff55714))
* type def / jsdoc ([#61](https://github.com/adobe/spacecat-shared/issues/61)) ([078f9e6](https://github.com/adobe/spacecat-shared/commit/078f9e6855d3f475f3a746561758aaefb5cb3c79))
* typo ([9167cf3](https://github.com/adobe/spacecat-shared/commit/9167cf3ac70a998aa92aaef24e080cd8147a70e9))
* update dynamo client ([#65](https://github.com/adobe/spacecat-shared/issues/65)) ([cc09041](https://github.com/adobe/spacecat-shared/commit/cc09041200dfe23c0a83c384fc9695ac972564e9))
* update node to lts/20, semantic release, misc ([#91](https://github.com/adobe/spacecat-shared/issues/91)) ([099662a](https://github.com/adobe/spacecat-shared/commit/099662af314866852313e250cecead2404e52f42))
* use correct doc client ([#9](https://github.com/adobe/spacecat-shared/issues/9)) ([d052b16](https://github.com/adobe/spacecat-shared/commit/d052b16dc6baf65efe83e34fe82d50265f6ae751))
* use getItem for latest audit ([#35](https://github.com/adobe/spacecat-shared/issues/35)) ([6e4a87e](https://github.com/adobe/spacecat-shared/commit/6e4a87ea2d515f632b34278a8cc1ffd51d692a16))
* use new aem datadesk ui for the backlinks ([#79](https://github.com/adobe/spacecat-shared/issues/79)) ([526b69c](https://github.com/adobe/spacecat-shared/commit/526b69cc8067f883f2ce0ab10c712b8ca094c81d))
* variouss ([ea9d44f](https://github.com/adobe/spacecat-shared/commit/ea9d44f6071c1a53d2c31515966e7cdf44be7ae9))
* wrap scores ([#28](https://github.com/adobe/spacecat-shared/issues/28)) ([4733a93](https://github.com/adobe/spacecat-shared/commit/4733a93d2db087dd57f94955a2101e5a4bb74ce2))


### Features

* add audit config ([#59](https://github.com/adobe/spacecat-shared/issues/59)) ([f851862](https://github.com/adobe/spacecat-shared/commit/f8518623a8b8e4e337b3c44a16b65724a953596a))
* add broken-backlinks audit type (SITES-18417) ([#86](https://github.com/adobe/spacecat-shared/issues/86)) ([b16c366](https://github.com/adobe/spacecat-shared/commit/b16c3667808221958ff4a526512cb89c3cd0bbcb))
* add data access module ([#11](https://github.com/adobe/spacecat-shared/issues/11)) ([cdbfff3](https://github.com/adobe/spacecat-shared/commit/cdbfff3961cbfc5702b832c386e3ccfd8572b439))
* add dynamo and utils modules ([#3](https://github.com/adobe/spacecat-shared/issues/3)) ([5e2e605](https://github.com/adobe/spacecat-shared/commit/5e2e6059648f4f554168dabeab737f6a09d8a050))
* add guards and use spacecat-shared-utils ([#6](https://github.com/adobe/spacecat-shared/issues/6)) ([27143cf](https://github.com/adobe/spacecat-shared/commit/27143cf2d4a439f1b5904e62756e59e501b3f67d))
* add isArray function ([eeb45a6](https://github.com/adobe/spacecat-shared/commit/eeb45a6784c6406403d0a59b65ba873a107c654c))
* add rum api calls to shared ([56cccd0](https://github.com/adobe/spacecat-shared/commit/56cccd0f498eaca6a4bb35a6b64d5f0dbe68a096))
* add support for 404 report backlink ([0d622de](https://github.com/adobe/spacecat-shared/commit/0d622de241b51f0df625679591dd5168b5b070a7))
* allow configuration from ctx / add missing fields ([#24](https://github.com/adobe/spacecat-shared/issues/24)) ([6959f89](https://github.com/adobe/spacecat-shared/commit/6959f895ed9b167f421b201f856ef871bd2a335c))
* data model for organizations ([944be83](https://github.com/adobe/spacecat-shared/commit/944be83c9f19e3acee9bb17352b3058fe6578a69))
* http utils package ([#51](https://github.com/adobe/spacecat-shared/issues/51)) ([84cd91a](https://github.com/adobe/spacecat-shared/commit/84cd91ae4225455327116169f5b040cc9adc1c2e))
* http-utils functions ([#49](https://github.com/adobe/spacecat-shared/issues/49)) ([20e98fa](https://github.com/adobe/spacecat-shared/commit/20e98faa75d2f439ea5e671937f78bea706ec5d7))
* introduce getSiteByID ([#36](https://github.com/adobe/spacecat-shared/issues/36)) ([5677f76](https://github.com/adobe/spacecat-shared/commit/5677f76d11d97f2a2afd878e0ada7cad22fd1f03))
* resolve secrets name ([#44](https://github.com/adobe/spacecat-shared/issues/44)) ([8c7604d](https://github.com/adobe/spacecat-shared/commit/8c7604da6b36f450a9054fa93c6c469c1f47319b))
* rum api client ([#48](https://github.com/adobe/spacecat-shared/issues/48)) ([ccfa187](https://github.com/adobe/spacecat-shared/commit/ccfa187a45f35e57085ac241ff156c0b9418592d))
* set isLiveToggledAt ([#85](https://github.com/adobe/spacecat-shared/issues/85)) ([cefc093](https://github.com/adobe/spacecat-shared/commit/cefc0938385b9fa079d24c24f03b21651a0999cc))
* site delivery type ([#77](https://github.com/adobe/spacecat-shared/issues/77)) ([005bc38](https://github.com/adobe/spacecat-shared/commit/005bc388ed6ab0f82c8b0f562d4c1f4c0d1e2894))
* store previous latest audit result ([#74](https://github.com/adobe/spacecat-shared/issues/74)) ([4663c43](https://github.com/adobe/spacecat-shared/commit/4663c4344e260f85c4e64691e0685260d36629e5))
* test ([bd3cc5d](https://github.com/adobe/spacecat-shared/commit/bd3cc5df89ccde75b86b000e8495893f4b099b5b))
* update audit config ([#63](https://github.com/adobe/spacecat-shared/issues/63)) ([00a468e](https://github.com/adobe/spacecat-shared/commit/00a468e9404676212ec9441c8a7fccf1a93c636f))


### Reverts

* Revert "fix: allow use of index for getItem (#10)" (#15) ([ad03176](https://github.com/adobe/spacecat-shared/commit/ad0317625074a26a4600d7e464a53c3b6dd78fe4)), closes [#10](https://github.com/adobe/spacecat-shared/issues/10) [#15](https://github.com/adobe/spacecat-shared/issues/15)

# [@adobe/spacecat-shared-data-access-v1.9.5](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.9.4...@adobe/spacecat-shared-data-access-v1.9.5) (2024-01-22)


### Bug Fixes

* set default organization ([#92](https://github.com/adobe/spacecat-shared/issues/92)) ([ac7e70c](https://github.com/adobe/spacecat-shared/commit/ac7e70c65f643c2f52730c3d5da4a0c4be282632))

# [@adobe/spacecat-shared-data-access-v1.9.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.9.3...@adobe/spacecat-shared-data-access-v1.9.4) (2024-01-20)


### Bug Fixes

* **deps:** update external fixes ([#90](https://github.com/adobe/spacecat-shared/issues/90)) ([df8161e](https://github.com/adobe/spacecat-shared/commit/df8161e4be87a5a3035729ce94388a8ccaf1630b))

# [@adobe/spacecat-shared-data-access-v1.9.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.9.2...@adobe/spacecat-shared-data-access-v1.9.3) (2024-01-19)


### Bug Fixes

* audit result scores init, test ([#89](https://github.com/adobe/spacecat-shared/issues/89)) ([96f829c](https://github.com/adobe/spacecat-shared/commit/96f829c908e38b2e5f303eee83da2488f8076a0b))

# [@adobe/spacecat-shared-data-access-v1.9.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.9.1...@adobe/spacecat-shared-data-access-v1.9.2) (2024-01-19)


### Bug Fixes

* createdAt test ([#88](https://github.com/adobe/spacecat-shared/issues/88)) ([ac6a5ba](https://github.com/adobe/spacecat-shared/commit/ac6a5bab9ee45a2840681f291a13f23a3eb97e25))

# [@adobe/spacecat-shared-data-access-v1.9.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.9.0...@adobe/spacecat-shared-data-access-v1.9.1) (2024-01-18)


### Bug Fixes

* initialize scores as an empty object (SITES-18417) ([#87](https://github.com/adobe/spacecat-shared/issues/87)) ([eb38e32](https://github.com/adobe/spacecat-shared/commit/eb38e3298228edb1d996fa633bff4af4dcbf69db))

# [@adobe/spacecat-shared-data-access-v1.9.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.8.0...@adobe/spacecat-shared-data-access-v1.9.0) (2024-01-18)


### Features

* data model for organizations ([944be83](https://github.com/adobe/spacecat-shared/commit/944be83c9f19e3acee9bb17352b3058fe6578a69))

# [@adobe/spacecat-shared-data-access-v1.8.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.7.0...@adobe/spacecat-shared-data-access-v1.8.0) (2024-01-18)


### Features

* add broken-backlinks audit type (SITES-18417) ([#86](https://github.com/adobe/spacecat-shared/issues/86)) ([b16c366](https://github.com/adobe/spacecat-shared/commit/b16c3667808221958ff4a526512cb89c3cd0bbcb))

# [@adobe/spacecat-shared-data-access-v1.7.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.6.4...@adobe/spacecat-shared-data-access-v1.7.0) (2024-01-18)


### Features

* set isLiveToggledAt ([#85](https://github.com/adobe/spacecat-shared/issues/85)) ([cefc093](https://github.com/adobe/spacecat-shared/commit/cefc0938385b9fa079d24c24f03b21651a0999cc))

# [@adobe/spacecat-shared-data-access-v1.6.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.6.3...@adobe/spacecat-shared-data-access-v1.6.4) (2024-01-13)


### Bug Fixes

* **deps:** update external fixes ([#81](https://github.com/adobe/spacecat-shared/issues/81)) ([67cf21c](https://github.com/adobe/spacecat-shared/commit/67cf21c548d036de45221e118ff3bc0e7b26a692))

# [@adobe/spacecat-shared-data-access-v1.6.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.6.2...@adobe/spacecat-shared-data-access-v1.6.3) (2024-01-12)


### Bug Fixes

* get latest audits with delivery type ([#80](https://github.com/adobe/spacecat-shared/issues/80)) ([d823773](https://github.com/adobe/spacecat-shared/commit/d823773d738ebddf2790356750827ae74e66b052))

# [@adobe/spacecat-shared-data-access-v1.6.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.6.1...@adobe/spacecat-shared-data-access-v1.6.2) (2024-01-12)


### Bug Fixes

* getSitesByDeliveryType signature ([#78](https://github.com/adobe/spacecat-shared/issues/78)) ([2b6c0fd](https://github.com/adobe/spacecat-shared/commit/2b6c0fd3e603eb3c688a45ae9ab78baf88a508ef))

# [@adobe/spacecat-shared-data-access-v1.6.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.6.0...@adobe/spacecat-shared-data-access-v1.6.1) (2024-01-12)


### Bug Fixes

* github org ([02f86c3](https://github.com/adobe/spacecat-shared/commit/02f86c351b2b1ab99ce5aca7fd5e6af2246c0efd))

<<<<<<< Updated upstream
# [@adobe/spacecat-shared-data-access-v1.6.0](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.5.2...@adobe/spacecat-shared-data-access-v1.6.0) (2024-01-12)


### Features

* site delivery type ([#77](https://github.com/adobe-rnd/spacecat-shared/issues/77)) ([005bc38](https://github.com/adobe-rnd/spacecat-shared/commit/005bc388ed6ab0f82c8b0f562d4c1f4c0d1e2894))

# [@adobe/spacecat-shared-data-access-v1.5.2](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.5.1...@adobe/spacecat-shared-data-access-v1.5.2) (2023-12-30)
=======
# [@adobe/spacecat-shared-data-access-v1.5.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.5.1...@adobe/spacecat-shared-data-access-v1.5.2) (2023-12-30)
>>>>>>> Stashed changes


### Bug Fixes

* **deps:** update external fixes ([#76](https://github.com/adobe/spacecat-shared/issues/76)) ([5b74623](https://github.com/adobe/spacecat-shared/commit/5b74623a4accfb601b607170f9bd67fb380f5c84))

# [@adobe/spacecat-shared-data-access-v1.5.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.5.0...@adobe/spacecat-shared-data-access-v1.5.1) (2023-12-27)


### Bug Fixes

* include audit ref and audited at ([#75](https://github.com/adobe/spacecat-shared/issues/75)) ([e573c90](https://github.com/adobe/spacecat-shared/commit/e573c903851d88c7293caa5e5a9af763987edb3a))

# [@adobe/spacecat-shared-data-access-v1.5.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.4.4...@adobe/spacecat-shared-data-access-v1.5.0) (2023-12-26)


### Features

* store previous latest audit result ([#74](https://github.com/adobe/spacecat-shared/issues/74)) ([4663c43](https://github.com/adobe/spacecat-shared/commit/4663c4344e260f85c4e64691e0685260d36629e5))

# [@adobe/spacecat-shared-data-access-v1.4.4](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.4.3...@adobe/spacecat-shared-data-access-v1.4.4) (2023-12-25)


### Bug Fixes

* add missing pattern to interface ([#72](https://github.com/adobe/spacecat-shared/issues/72)) ([0eacbff](https://github.com/adobe/spacecat-shared/commit/0eacbff39dbc12d604e40ae94285533f7804ca0a))

# [@adobe/spacecat-shared-data-access-v1.4.3](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.4.2...@adobe/spacecat-shared-data-access-v1.4.3) (2023-12-23)


### Bug Fixes

* **deps:** update external fixes ([#71](https://github.com/adobe/spacecat-shared/issues/71)) ([b9a6679](https://github.com/adobe/spacecat-shared/commit/b9a667966e7b0f013f46c62f6cc4a85f80623c61))

# [@adobe/spacecat-shared-data-access-v1.4.2](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.4.1...@adobe/spacecat-shared-data-access-v1.4.2) (2023-12-20)


### Bug Fixes

* **deps:** update aws-sdk-js-v3 monorepo to v3.477.0 ([#68](https://github.com/adobe/spacecat-shared/issues/68)) ([492913f](https://github.com/adobe/spacecat-shared/commit/492913f0011d557b7c91ba631c13ced171bc2ce9))

# [@adobe/spacecat-shared-data-access-v1.4.1](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.4.0...@adobe/spacecat-shared-data-access-v1.4.1) (2023-12-18)


### Bug Fixes

* update dynamo client ([#65](https://github.com/adobe/spacecat-shared/issues/65)) ([cc09041](https://github.com/adobe/spacecat-shared/commit/cc09041200dfe23c0a83c384fc9695ac972564e9))

# [@adobe/spacecat-shared-data-access-v1.4.0](https://github.com/adobe/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.3.2...@adobe/spacecat-shared-data-access-v1.4.0) (2023-12-16)


### Features

* update audit config ([#63](https://github.com/adobe/spacecat-shared/issues/63)) ([00a468e](https://github.com/adobe-rnd/spacecat-shared/commit/00a468e9404676212ec9441c8a7fccf1a93c636f))

# [@adobe/spacecat-shared-data-access-v1.3.2](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.3.1...@adobe/spacecat-shared-data-access-v1.3.2) (2023-12-16)


### Bug Fixes

* GSI sort key when error ([#62](https://github.com/adobe-rnd/spacecat-shared/issues/62)) ([dbb6a91](https://github.com/adobe-rnd/spacecat-shared/commit/dbb6a91f75fa9492a621de7b258cbebe38fe3ac7))

# [@adobe/spacecat-shared-data-access-v1.3.1](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.3.0...@adobe/spacecat-shared-data-access-v1.3.1) (2023-12-16)


### Bug Fixes

* type def / jsdoc ([#61](https://github.com/adobe-rnd/spacecat-shared/issues/61)) ([078f9e6](https://github.com/adobe-rnd/spacecat-shared/commit/078f9e6855d3f475f3a746561758aaefb5cb3c79))

# [@adobe/spacecat-shared-data-access-v1.3.0](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.2.7...@adobe/spacecat-shared-data-access-v1.3.0) (2023-12-16)


### Features

* add audit config ([#59](https://github.com/adobe-rnd/spacecat-shared/issues/59)) ([f851862](https://github.com/adobe-rnd/spacecat-shared/commit/f8518623a8b8e4e337b3c44a16b65724a953596a))

# [@adobe/spacecat-shared-data-access-v1.2.7](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.2.6...@adobe/spacecat-shared-data-access-v1.2.7) (2023-12-11)


### Bug Fixes

* sort order sites with latest audits ([#46](https://github.com/adobe-rnd/spacecat-shared/issues/46)) ([8da2bf1](https://github.com/adobe-rnd/spacecat-shared/commit/8da2bf16b904ced6787d8c56ba2b4b72678687a0))

# [@adobe/spacecat-shared-data-access-v1.2.6](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.2.5...@adobe/spacecat-shared-data-access-v1.2.6) (2023-12-11)


### Bug Fixes

* include sites without latest audits ([#45](https://github.com/adobe-rnd/spacecat-shared/issues/45)) ([b843190](https://github.com/adobe-rnd/spacecat-shared/commit/b843190da09916832a743d6fc4bf83e804b61912))

# [@adobe/spacecat-shared-data-access-v1.2.5](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.2.4...@adobe/spacecat-shared-data-access-v1.2.5) (2023-12-10)


### Bug Fixes

* no undefined for putItem ([#43](https://github.com/adobe-rnd/spacecat-shared/issues/43)) ([283f229](https://github.com/adobe-rnd/spacecat-shared/commit/283f2299956c53ea77206a973210c3ecc9475180))

# [@adobe/spacecat-shared-data-access-v1.2.4](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.2.3...@adobe/spacecat-shared-data-access-v1.2.4) (2023-12-10)


### Bug Fixes

* pass ascending param ([#42](https://github.com/adobe-rnd/spacecat-shared/issues/42)) ([930ae6b](https://github.com/adobe-rnd/spacecat-shared/commit/930ae6b09825cf37de90db0a4331eebe5f58a70e))

# [@adobe/spacecat-shared-data-access-v1.2.3](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.2.2...@adobe/spacecat-shared-data-access-v1.2.3) (2023-12-10)


### Bug Fixes

* allow sorting for get audits for site ([#41](https://github.com/adobe-rnd/spacecat-shared/issues/41)) ([3664c97](https://github.com/adobe-rnd/spacecat-shared/commit/3664c97bd63d4f10e260582455e3763da60399dd))

# [@adobe/spacecat-shared-data-access-v1.2.2](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.2.1...@adobe/spacecat-shared-data-access-v1.2.2) (2023-12-08)


### Bug Fixes

* allow update of github URL ([#40](https://github.com/adobe-rnd/spacecat-shared/issues/40)) ([21da989](https://github.com/adobe-rnd/spacecat-shared/commit/21da9893fcb9c971c1c6a4e1271133188351c155))

# [@adobe/spacecat-shared-data-access-v1.2.1](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.2.0...@adobe/spacecat-shared-data-access-v1.2.1) (2023-12-07)


### Bug Fixes

* export getLatestAuditsForSite ([#39](https://github.com/adobe-rnd/spacecat-shared/issues/39)) ([e9c9130](https://github.com/adobe-rnd/spacecat-shared/commit/e9c9130b940122714be76e3df6e96e44bbde5348))

# [@adobe/spacecat-shared-data-access-v1.2.0](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.1.6...@adobe/spacecat-shared-data-access-v1.2.0) (2023-12-05)


### Features

* introduce getSiteByID ([#36](https://github.com/adobe-rnd/spacecat-shared/issues/36)) ([5677f76](https://github.com/adobe-rnd/spacecat-shared/commit/5677f76d11d97f2a2afd878e0ada7cad22fd1f03))

# [@adobe/spacecat-shared-data-access-v1.1.6](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.1.5...@adobe/spacecat-shared-data-access-v1.1.6) (2023-12-05)


### Bug Fixes

* use getItem for latest audit ([#35](https://github.com/adobe-rnd/spacecat-shared/issues/35)) ([6e4a87e](https://github.com/adobe-rnd/spacecat-shared/commit/6e4a87ea2d515f632b34278a8cc1ffd51d692a16))

# [@adobe/spacecat-shared-data-access-v1.1.5](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.1.4...@adobe/spacecat-shared-data-access-v1.1.5) (2023-12-05)


### Bug Fixes

* get audit no query ([#34](https://github.com/adobe-rnd/spacecat-shared/issues/34)) ([8fadd0a](https://github.com/adobe-rnd/spacecat-shared/commit/8fadd0a21a1e0cc232a06ccf805d1ac5c946b8be))

# [@adobe/spacecat-shared-data-access-v1.1.4](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.1.3...@adobe/spacecat-shared-data-access-v1.1.4) (2023-12-05)


### Bug Fixes

* latest-audits sort key ([#33](https://github.com/adobe-rnd/spacecat-shared/issues/33)) ([21dc14e](https://github.com/adobe-rnd/spacecat-shared/commit/21dc14e75e8aad641f1c99330243a3102e8de465))

# [@adobe/spacecat-shared-data-access-v1.1.3](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.1.2...@adobe/spacecat-shared-data-access-v1.1.3) (2023-12-05)


### Bug Fixes

* switch defaults to dev (force release) ([b85d54c](https://github.com/adobe-rnd/spacecat-shared/commit/b85d54ca7430a4e54b49d112429242c81ff55714))

# [@adobe/spacecat-shared-data-access-v1.1.2](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.1.1...@adobe/spacecat-shared-data-access-v1.1.2) (2023-12-02)


### Bug Fixes

* wrap scores ([#28](https://github.com/adobe-rnd/spacecat-shared/issues/28)) ([4733a93](https://github.com/adobe-rnd/spacecat-shared/commit/4733a93d2db087dd57f94955a2101e5a4bb74ce2))

# [@adobe/spacecat-shared-data-access-v1.1.1](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.1.0...@adobe/spacecat-shared-data-access-v1.1.1) (2023-12-02)


### Bug Fixes

* distinguish lhs-mobile vs lhs-desktop ([#27](https://github.com/adobe-rnd/spacecat-shared/issues/27)) ([18fd1b1](https://github.com/adobe-rnd/spacecat-shared/commit/18fd1b18ae400c32bbb3a175f7d6a6cde104f4a1))

# [@adobe/spacecat-shared-data-access-v1.1.0](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.0.2...@adobe/spacecat-shared-data-access-v1.1.0) (2023-12-02)


### Features

* allow configuration from ctx / add missing fields ([#24](https://github.com/adobe-rnd/spacecat-shared/issues/24)) ([6959f89](https://github.com/adobe-rnd/spacecat-shared/commit/6959f895ed9b167f421b201f856ef871bd2a335c))

# [@adobe/spacecat-shared-data-access-v1.0.2](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.0.1...@adobe/spacecat-shared-data-access-v1.0.2) (2023-12-02)


### Bug Fixes

* **deps:** update aws-sdk-js-v3 monorepo to v3.465.0 ([#19](https://github.com/adobe-rnd/spacecat-shared/issues/19)) ([612c257](https://github.com/adobe-rnd/spacecat-shared/commit/612c257870dc171d32c4ca5f8c2e48f9f77f8198))

# [@adobe/spacecat-shared-data-access-v1.0.1](https://github.com/adobe-rnd/spacecat-shared/compare/@adobe/spacecat-shared-data-access-v1.0.0...@adobe/spacecat-shared-data-access-v1.0.1) (2023-12-01)


### Bug Fixes

* **deps:** update aws-sdk-js-v3 monorepo ([#16](https://github.com/adobe-rnd/spacecat-shared/issues/16)) ([e60296a](https://github.com/adobe-rnd/spacecat-shared/commit/e60296a78105079527e80c802c60de5d28ebd207))

# @adobe/spacecat-shared-data-access-v1.0.0 (2023-12-01)


### Features

* add data access module ([#11](https://github.com/adobe-rnd/spacecat-shared/issues/11)) ([cdbfff3](https://github.com/adobe-rnd/spacecat-shared/commit/cdbfff3961cbfc5702b832c386e3ccfd8572b439))
