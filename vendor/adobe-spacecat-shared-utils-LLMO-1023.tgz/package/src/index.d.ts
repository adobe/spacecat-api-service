/*
 * Copyright 2023 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

import { Request, RequestOptions, Response } from '@adobe/fetch';
import type { ISOCalendarWeek } from './calendar-week-helper.js';

export { AUTHORING_TYPES, DELIVERY_TYPES } from './aem.js';

export { OPPORTUNITY_TYPES } from './constants.js';

export const DEFAULT_CPC_VALUE: number;

/** UTILITY FUNCTIONS */
export function arrayEquals<T>(a: T[], b: T[]): boolean;

export function hasText(str: string): boolean;

export function isBoolean(value: unknown): boolean;

export function isInteger(value: unknown): boolean;

export function isValidDate(value: unknown): boolean;

export function isValidEmail(email: string): boolean;

export function isIsoDate(str: string): boolean;

export function isIsoTimeOffsetsDate(str: string): boolean;

export function isNumber(value: unknown): boolean;

export function isObject(value: unknown): boolean;

export function isArray(value: unknown): boolean;

export function isNonEmptyArray(value: unknown): boolean;

export function isNonEmptyObject(value: unknown): boolean;

export function isString(value: unknown): boolean;

export function toBoolean(value: unknown): boolean;

export function isValidUrl(urlString: string): boolean;

export function isValidHelixPreviewUrl(urlString: string): boolean;

export function isValidUUID(uuid: string): boolean;

export function isValidIMSOrgId(imsOrgId: string): boolean;

export function dateAfterDays(days: number, dateString: string): Date;

export function deepEqual(a: unknown, b: unknown): boolean;

export function sqsWrapper(fn: (message: object, context: object) => Promise<Response>):
  (request: object, context: object) => Promise<Response>;

export function sqsEventAdapter(fn: (message: object, context: object) => Promise<Response>):
  (request: object, context: object) => Promise<Response>;

/**
 * A higher-order function that wraps a given function and enhances logging by appending
 * a `jobId` and `traceId` to log messages when available.
 * @param fn - The original function to be wrapped
 * @returns A wrapped function that enhances logging
 */
export function logWrapper(fn: (message: object, context: object) => Promise<Response>):
  (message: object, context: object) => Promise<Response>;

/**
 * Instruments an AWS SDK v3 client with X-Ray tracing when running in AWS Lambda.
 * @param client - The AWS SDK v3 client to instrument
 * @returns The instrumented client (or original client if not in Lambda)
 */
export function instrumentAWSClient<T>(client: T): T;

/**
 * Extracts the trace ID from the current AWS X-Ray segment.
 * @returns The trace ID if available, or null if not in AWS Lambda or no segment found
 */
export function getTraceId(): string | null;

/**
 * Adds the x-trace-id header to a headers object if a trace ID is available.
 * @param headers - The headers object to augment
 * @param context - The context object that may contain traceId
 * @returns The headers object with x-trace-id added if available
 */
export function addTraceIdHeader(headers?: Record<string, string>, context?: object): Record<string, string>;

/**
 * Prepends 'https://' schema to the URL if it's not already present.
 * @param url - The URL to modify.
 * @returns The URL with 'https://' schema prepended.
 */
export declare function prependSchema(url: string): string;

/**
 * Strips the port number from the end of the URL.
 * @param url - The URL to modify.
 * @returns The URL with the port removed.
 */
export declare function stripPort(url: string): string;

/**
 * Strips the trailing dot from the end of the URL.
 * @param url - The URL to modify.
 * @returns The URL with the trailing dot removed.
 */
export declare function stripTrailingDot(url: string): string;

/**
 * Strips the trailing slash from the end of the URL.
 * @param url - The URL to modify.
 * @returns The URL with the trailing slash removed.
 */
export declare function stripTrailingSlash(url: string): string;

/**
 * Strips 'www.' from the beginning of the URL if present.
 * @param url - The URL to modify.
 * @returns The URL with 'www.' removed.
 */
export declare function stripWWW(url: string): string;

/**
 * Canonicalizes a URL by removing protocol, www prefix, and trailing slash
 * for comparison and matching purposes.
 * Optionally strips query parameters and fragments.
 * @param url - URL to canonicalize
 * @param options - Canonicalization options
 * @param options.stripQuery - Whether to strip query parameters and fragments
 * @returns Canonicalized URL
 */
export declare function canonicalizeUrl(
  url: string,
  options?: { stripQuery?: boolean }
): string;

/**
 * Composes a base URL by applying a series of transformations to the given domain.
 * @param domain - The domain to compose the base URL from.
 * @returns The composed base URL.
 */
export declare function composeBaseURL(domain: string): string;

/**
 * Composes an audit URL by applying a series of transformations to the given url.
 * @param {string} url - The url to compose the audit URL from.
 * @param {string} [userAgent] - Optional user agent to use in the audit URL.
 * @returns a promise that resolves the composed audit URL.
 */
export declare function composeAuditURL(url: string, userAgent?: string): Promise<string>;

/**
 * Resolves the name of the secret based on the function version.
 * @param {Object} opts - The options object, not used in this implementation.
 * @param {Object} ctx - The context object containing the function version.
 * @param {string} defaultPath - The default path for the secret.
 * @returns {string} - The resolved secret name.
 */
export declare function resolveSecretsName(opts: object, ctx: object, defaultPath: string): string;

/**
 * Resolves the name of the customer secrets based on the baseURL.
 * @param {string} baseURL - The base URL to resolve the customer secrets name from.
 * @param {Object} ctx - The context object containing the function version.
 * @returns {string} - The resolved secret name.
 */
export declare function resolveCustomerSecretsName(baseURL: string, ctx: object): string;

/**
 * Retrieves the RUM domain key for the specified base URL from the customer secrets.
 *
 * @param {string} baseURL - The base URL for which the RUM domain key is to be retrieved.
 * @param {object} ctx - Helix Universal Context. See https://github.com/adobe/helix-universal/blob/main/src/adapter.d.ts#L120
 * @returns {Promise<string>} - A promise that resolves to the RUM domain key.
 * @throws {Error} Throws an error if no domain key is found for the specified base URL.
 */
export declare function getRUMDomainKey(baseURL: string, ctx: object): Promise<string>;

/**
 * Generates a CSV file from the provided JSON data.
 *
 * Each key-value pair in the JSON objects
 * corresponds to a column and its value in the CSV. The output is a UTF-8
 * encoded Buffer that represents the CSV file content.
 *
 * @param {Object[]} data - An array of JSON objects to be converted into CSV format.
 * @returns {Buffer} A Buffer containing the CSV formatted data, encoded in UTF-8.
 */
export declare function generateCSVFile(data: object[]): Buffer;

/**
 * Replaces placeholders in the prompt content with their corresponding values.
 *
 * @param {string} content - The prompt content with placeholders.
 * @param {Object} placeholders - The placeholders and their values.
 * @returns {string} - The content with placeholders replaced.
 */
export declare function replacePlaceholders(content: string, placeholders: object): string;

/**
 * Function to support reading static file
 * and replace placeholder strings with values.
 *
 * @param {Object} placeholders - A JSON object containing values to replace in the prompt content.
 * @param {String} filename - The path of the prompt file.
 * @returns {Promise<string|null>} - A promise that resolves to a string with the prompt content.
 */
export declare function getStaticContent(placeholders: object, filename: string):
  Promise<string | null>;

/**
 * Reads the content of a prompt file asynchronously and replaces any placeholders
 * with the corresponding values. Logs the error and returns null in case of an error.
 *
 * @param {Object} placeholders - A JSON object containing values to replace in the prompt content.
 * @param {String} filename - The filename of the prompt file.
 * @param {Object} log - The logger
 * @returns {Promise<string|null>} - A promise that resolves to a string with the prompt content,
 * or null if an error occurs.
 */
export declare function getPrompt(placeholders: object, filename: string, log: object):
  Promise<string | null>;

/**
 * Reads the content of a query file asynchronously and replaces any placeholders
 * with the corresponding values. Logs the error and returns null in case of an error.
 *
 * @param {Object} placeholders - A JSON object containing values to replace in the query content.
 * @param {String} filename - The filename of the query file.
 * @param {Object} log - The logger
 * @returns {Promise<string|null>} - A promise that resolves to a string with the query content,
 * or null if an error occurs.
 */
export declare function getQuery(placeholders: object, filename: string, log: object):
  Promise<string | null>;

/**
 * Retrieves the high-form-view-low-form-conversion metrics from the provided array of form vitals.
 * @param {Object[]} formVitals - An array of form vitals.
 * @returns {Object[]} - An array of high-form-view-low-form-conversion metrics.
 */
export declare function getHighFormViewsLowConversionMetrics(formVitals: object[]):
  object[];

/**
 * Retrieves the high-page-view-low-form-view metrics from the provided array of form vitals.
 * @param {Object[]} formVitals - An array of form vitals.
 * @returns {Object[]} - An array of high-page-view-low-form-view metrics.
 */
export declare function getHighPageViewsLowFormViewsMetrics(formVitals: object[]):
  object[];

/**
 * Retrieves the high-page-view-low-form-ctr metrics from the provided array of form vitals.
 * @param {Object[]} formVitals - An array of form vitals.
 * @returns {Object[]} - An array of high-page-view-low-form-ctr metrics.
 */
export declare function getHighPageViewsLowFormCtrMetrics(formVitals: object[]):
  object[];

/**
 * Retrieves stored metrics from S3.
 * @param config - Configuration object
 * @param config.siteId - The site ID.
 * @param config.source - The source of the metrics.
 * @param config.metric - The metric name.
 * @param context - Context object
 * @param context.log - Logger
 * @param context.s3 - S3 configuration
 * @param context.s3.s3Client - S3 client
 * @param context.s3.s3Bucket - S3 bucket name
 * @returns {Promise<any|*[]>} - The stored metrics
 */
export function getStoredMetrics(config: object, context: object):
  Promise<Array<object>>;

/**
 * Stores metrics in S3.
 * @param content - The metrics to store
 * @param config - Configuration object
 * @param config.siteId - The site ID
 * @param config.source - The source of the metrics
 * @param config.metric - The metric name
 * @param context - Context object
 * @param context.log - Logger
 * @param context.s3 - S3 configuration
 * @param context.s3.s3Client - S3 client
 * @param context.s3.s3Bucket - S3 bucket name
 * @returns {Promise<string>} - The path where the metrics are stored
 */
export function storeMetrics(content: object, config: object, context: object): Promise<string>;

/**
 * Retrieves an object from S3 by its key and returns its JSON parsed content.
 * If the object is not JSON, returns the raw body.
 * If the object is not found, returns null.
 * @param s3Client - The S3 client
 * @param bucketName - The name of the S3 bucket
 * @param key - The key of the S3 object
 * @param log - A logger instance
 * @returns The content of the S3 object or null if not found
 */
export function getObjectFromKey(
  s3Client: any,
  bucketName: string,
  key: string,
  log: any
): Promise<any | null>;

/**
 * Fetches the organic traffic data for a site from S3 and calculates the CPC value
 * @param context - Context object
 * @param context.env - Environment variables
 * @param context.env.S3_IMPORTER_BUCKET_NAME - S3 importer bucket name
 * @param context.s3Client - S3 client
 * @param context.log - Logger
 * @param siteId - The site ID
 * @returns CPC value in dollars
 */
export function calculateCPCValue(context: object, siteId: string): Promise<number>;

export function s3Wrapper(fn: (request: object, context: object) => Promise<Response>):
  (request: object, context: object) => Promise<Response>;

export function fetch(url: string | Request, options?: RequestOptions): Promise<Response>;

export function tracingFetch(url: string | Request, options?: RequestOptions): Promise<Response>;

export const SPACECAT_USER_AGENT: string;

export function prettifyLogForwardingConfig(payload: object): object;

export function isoCalendarWeek(date: Date): ISOCalendarWeek;

export function isoCalendarWeekSunday(date: Date): Date;

export function isoCalendarWeekMonday(date: Date): Date;

/**
 * Extracts URLs from a suggestion based on the opportunity type.
 * @param opts - Options object
 * @param opts.opportunity - The opportunity object
 * @param opts.suggestion - The suggestion object
 * @returns A promise that resolves to an array of extracted URLs
 */
export function extractUrlsFromSuggestion(opts: {
  opportunity: any;
  suggestion: any;
}): Promise<string[]>;

/**
 * Extracts URLs from an opportunity based on the opportunity type.
 * @param opts - Options object
 * @param opts.opportunity - The opportunity object
 * @returns An array of extracted URLs
 */
export function extractUrlsFromOpportunity(opts: {
  opportunity: any;
}): string[];

/** Token grant entry: tokens per cycle and cycle format (e.g. YYYY-MM). */
export interface TokenGrantEntry {
  tokensPerCycle: number;
  cycleFormat: string;
}

/** Per-opportunity grant config keyed by opportunity name. */
export const OPPORTUNITY_GRANT_CONFIG: Record<string, TokenGrantEntry>;

/** Cumulative token grant config keyed by token type. */
export const TOKEN_GRANT_CONFIG: Record<string, TokenGrantEntry>;

/**
 * Converts an opportunity name to its token type key.
 * @param opportunityName - e.g. "broken-backlinks".
 * @returns e.g. "grant_broken_backlinks".
 */
export function getTokenTypeForOpportunity(
  opportunityName: string
): string;

/**
 * Returns the grant config for a token type.
 * @param tokenType - e.g. "grant_cwv".
 */
export function getTokenGrantConfig(
  tokenType: string
): (TokenGrantEntry & { currentCycle: string }) | undefined;

/**
 * Returns the grant config for an opportunity name.
 * @param opportunityName - e.g. "broken-backlinks".
 */
export function getTokenGrantConfigByOpportunity(
  opportunityName: string
): (TokenGrantEntry & { currentCycle: string; tokenType: string }) | undefined;

/**
 * Computes the current cycle string for a given cycleFormat
 * using UTC time.
 * Supported placeholders: YYYY (4-digit year), MM (zero-padded month).
 */
export function getCurrentCycle(cycleFormat: string): string;

export * as llmoConfig from './llmo-config.js';
export * as llmoStrategy from './llmo-strategy.js';
export * as schemas from './schemas.js';

export { type detectLocale } from './locale-detect/index.js';
export { type detectBotBlocker } from './bot-blocker-detect/index.js';
